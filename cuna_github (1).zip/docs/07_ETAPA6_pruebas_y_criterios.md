# Etapa 6: pruebas y criterios de aceptación

Fecha: 25 de noviembre de 2026.
Versión del firmware: 0.3.0.
Contrato: CONTRATO.md versión 1. Todo PROPUESTO. Nada está aprobado por Jan Carlo.

## 1. Resumen honesto

El software está terminado y probado contra hardware falso y un servidor simulado. 229 pruebas pasan. Ninguna prueba corrió en una Pico. No hay ningún resultado de hardware en este documento, porque no lo tengo. La sección 4 es el plan para obtenerlo.

Nada de lo que sigue demuestra que la luz se vea, que el sonido se oiga o que el micrófono capte voz. Eso solo se sabe con el hardware armado.

## 2. Pruebas automáticas

Se corren en tu PC con Python 3.10 o más nuevo.

    cd cuna
    python3 -m unittest discover -s tests -t . -v

| Área | Archivos | Pruebas |
| --- | --- | --- |
| Luz y su protocolo | test_luz, test_integracion | 24 |
| Nanas y audio | test_audio, test_integracion_audio | 33 |
| Micrófono | test_mic | 17 |
| Voz | test_voz, test_integracion_voz | 30 |
| Formato de mensajes | test_mensajes | 7 |
| Eventos, sesión y reconexión | test_eventos, test_sesion | 33 |
| Módulos juntos y escenarios | test_modulos, test_escenarios | 11 |
| Servidor, SCRUM-44 y 45 | test_servidor_kit | 41 |
| Compatibilidad con la biblioteca websockets | test_interop | 7 |
| Salida por tonos, cancelación de tareas y preparar la Pico | test_tonos, test_tareas, test_preparar_pico | 26 |
| Total | | 229 |

El resultado de la última corrida fue 229 pruebas, todas bien, en 79 segundos. La prueba de compatibilidad se salta si la biblioteca websockets no está instalada. Con ella instalada imprime un aviso de cierre de esa biblioteca. Es ruido de la biblioteca y no cambia el resultado.

Verifiqué que las pruebas detectan fallos. En las etapas 5 y 6 rompí el código a propósito en siete lugares. Seis roturas fueron detectadas desde el principio. Una pasó sin detectarse y escribí una prueba nueva para ella.

Qué NO cubren. Todas usan un PWM falso, una salida de audio falsa, un ADC falso, un temporizador falso y un servidor simulado. No cubren el código viper, el comportamiento real del I2S en el RP2350, la velocidad real del ADC, el Wi-Fi real ni el reloj NTP.

## 3. Criterios de aceptación

Las clases son las del prompt maestro.

### SCRUM-29, luz de noche regulable

| Criterio | Estado |
| --- | --- |
| CA1. La intensidad se ajusta por PWM y se controla desde la app | IMPLEMENTADO NO PROBADO EN HARDWARE. El protocolo y la lógica están VALIDADOS SOLO CON SIMULADOR. El botón en la app es de Jan Carlo |
| CA2. El cambio se refleja en la cuna y en las demás cuentas vinculadas | PENDIENTE DE INTEGRACIÓN EXTERNA. La cuna manda light.state. Jan Carlo lo reparte a las cuentas |

### SCRUM-30, nanas

| Criterio | Estado |
| --- | --- |
| CA1. La app elige un audio y controla el volumen | IMPLEMENTADO NO PROBADO EN HARDWARE. Protocolo VALIDADO SOLO CON SIMULADOR. La pantalla de la app es de Jan Carlo |
| CA2. Los audios están en la memoria local o en el servidor y suenan por el altavoz de la cuna | IMPLEMENTADO NO PROBADO EN HARDWARE. Las dos nanas locales y la canción por red funcionan contra el simulador. Que suenen por el parlante no está probado |

### SCRUM-31 parte A, voz bidireccional

| Criterio | Estado |
| --- | --- |
| CA1. Un botón de la app inicia la voz | PENDIENTE DE INTEGRACIÓN EXTERNA. La cuna entiende voice.start. El botón y el servidor son de Jan Carlo |
| CA2. La transmisión es bidireccional entre la app y el altavoz y micrófono de la cuna, por WebRTC o WebSockets | IMPLEMENTADO NO PROBADO EN HARDWARE. Se usa WebSocket, que Jira permite. Va por turnos y no a la vez. Cumple el criterio solo en parte. Si Jira exige las dos direcciones al mismo tiempo, falta trabajo |

### SCRUM-44, notificación silenciosa, lado servidor

| Criterio | Estado |
| --- | --- |
| CA1. El kit no emite sonido en la habitación | NO IMPLEMENTADO. Es un requisito de hardware del kit de seguridad, de SCRUM-42 |
| CA2. La notificación llega en modo silencioso con enlace o vista previa de la foto | VALIDADO SOLO CON SIMULADOR. Los mensajes salen con disable_notification verdadero y no se mandó nada a Telegram. Que el teléfono quede en silencio es PENDIENTE DE INTEGRACIÓN EXTERNA |

### SCRUM-45, ventanas horarias, lado servidor

| Criterio | Estado |
| --- | --- |
| CA1. La interfaz define rangos horarios | VALIDADO SOLO CON SIMULADOR la validación y la lógica. La pantalla es PENDIENTE DE INTEGRACIÓN EXTERNA |
| CA2. Fuera del rango no hay capturas ni alertas | VALIDADO SOLO CON SIMULADOR las alertas. Que el kit no tome la foto es PENDIENTE DE INTEGRACIÓN EXTERNA |
| CA3. Un botón activa o desactiva el kit al instante | VALIDADO SOLO CON SIMULADOR la lógica. El botón es PENDIENTE DE INTEGRACIÓN EXTERNA |

### Piezas técnicas

| Pieza | Estado |
| --- | --- |
| Conexión, hello, token y welcome | VALIDADO SOLO CON SIMULADOR |
| Reconexión con esperas, latido y silencio de 95 segundos | VALIDADO SOLO CON SIMULADOR. Perro guardián: IMPLEMENTADO NO PROBADO EN HARDWARE |
| Búfer de 50 eventos y envío en orden | VALIDADO SOLO CON SIMULADOR |
| Cliente WebSocket en la Pico | IMPLEMENTADO NO PROBADO EN HARDWARE |
| Reloj con NTP y hashlib.sha1 | IMPLEMENTADO NO PROBADO EN HARDWARE |
| Escalado de volumen y cálculo del micrófono con viper | IMPLEMENTADO NO PROBADO EN HARDWARE |
| I2S con el PCM5102A en la Pico 2 W | IMPLEMENTADO NO PROBADO EN HARDWARE |
| Modo tonos: lógica, rechazo de canciones del servidor y caps | VALIDADO SOLO CON SIMULADOR |
| Modo tonos: PWM como audio en la Pico con el PAM8403 | IMPLEMENTADO NO PROBADO EN HARDWARE |
| Voz de la app y canciones del servidor en modo tonos | NO IMPLEMENTADO |
| Lectura del ADC a 8 kHz con Wi-Fi activo | IMPLEMENTADO NO PROBADO EN HARDWARE. Es el mayor riesgo |
| Lectura de rssi | NO IMPLEMENTADO. Se reporta null |
| Circuito del micrófono | PROPUESTO, sin armar ni probar |
| Integración con el servidor de Jan Carlo | PENDIENTE DE INTEGRACIÓN EXTERNA |

## 4. Plan de pruebas en hardware

Nada de esto se ha ejecutado. La columna de resultado va vacía a propósito. Se hace en este orden, porque cada paso necesita el anterior.

| N | Prueba | Cómo | Resultado esperado | Resultado real |
| --- | --- | --- | --- | --- |
| 1 | Arranca y conecta | Pico con la luz armada, Wi-Fi y simulador en tu PC | El simulador imprime hello con fw 0.3.0 | |
| 2 | Luz | on 40, luego off | El LED sube y baja en unos 0,3 s sin escalones raros | |
| 3 | Memoria libre | Leer free_ram en el status | Anotar el valor. Si es menor de 60000 hay que reducir las colas | |
| 4 | Espacio en la flash | os.statvfs en la Pico | Cabe 576 kB de nanas más el programa | |
| 5 | Nana local | Con volumen 20, play local nana-1 | Se oye la melodía sin cortes. Anotar el ruido al abrir y cerrar | |
| 6 | Volumen | vol 20, vol 50 | El volumen cambia sin chasquidos fuertes | |
| 7 | Canción por red | play server assets/nana-1.pcm | Suena completa. Anotar los eventos AUDIO_UNDERRUN | |
| 8 | Micrófono, ritmo | voz start | Anotar mic_hz_real. Debe estar cerca de 8000 | |
| 9 | Micrófono, calidad | voz start, hablar, voz stop | Escuchar voz_cuna.wav en el PC. La voz se entiende | |
| 10 | Voz de la app | voz start, voz turno app, voz decir | La voz suena en el parlante sin cortes | |
| 11 | Voz corta nana | play local nana-1, luego voz start | La nana calla y no vuelve sola | |
| 12 | Reconexión | Apagar el simulador y volver a prenderlo | La cuna reconecta sola. La luz no parpadea | |
| 13 | Escenario completo | python3 -m simulador.servidor_sim --host 0.0.0.0 --escenario con-corte | 13 pasos PASS | |
| 14 | Aguante | Dejar la cuna conectada una hora con latido | Sin reinicios del perro guardián | |

Si la prueba 8 da un valor lejano de 8000, hay tres caminos, ya descritos en la Etapa 4. Bajar MIC_RATE_HZ en config.py, cambiar a un micrófono digital INMP441 o mejorar la señal con un módulo MAX4466.

Los umbrales de las pruebas 3 y 8 son propuestas mías. No salen de ninguna documentación.

## 5. Riesgos que siguen abiertos

1. El ADC a 8 kHz con Wi-Fi. Si falla, la voz de la cuna hacia la app no sirve.
2. El cliente WebSocket escrito a mano no está probado en la Pico.
3. La RAM. Las colas de audio y voz se miden en la prueba 3.
4. La flash. Se mide en la prueba 4.
5. La voz va por turnos y Jira dice bidireccional.
6. El circuito del micrófono es una propuesta sin probar.
7. Jan Carlo debe aprobar los cambios al contrato. Sin eso, la integración real puede fallar aunque todo pase con el simulador.

## 6. Fuentes

- Instalación de MicroPython 1.29.0 para Pico 2 W: https://micropython.org/download/RPI_PICO2_W/
- mpremote: https://docs.micropython.org/en/latest/reference/mpremote.html
- Telegram Bot API: https://core.telegram.org/bots/api
