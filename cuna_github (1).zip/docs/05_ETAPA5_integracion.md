# Etapa 5: integración y simulador del servidor

Fecha: 25 de noviembre de 2026.
Contrato: CONTRATO.md versión 1. Esta etapa no cambió el contrato. Todo sigue PROPUESTO y nada está aprobado por Jan Carlo.
Versión del firmware: 0.3.0.

## 1. Qué se hizo

Luz, nanas y voz ya trabajan juntas en un solo programa. Hay una sola conexión WebSocket, un solo lugar que reconecta y un solo registro de eventos. El simulador del servidor ahora usa solo la biblioteca estándar de Python. No hay que instalar nada para correrlo.

| Archivo | Para qué sirve |
| --- | --- |
| servicios/sesion.py | Una sesión completa: conecta, saluda, manda el estado, el latido y los eventos, y limpia todo al caerse |
| servicios/supervisor.py | Repite las sesiones con las esperas del contrato: 1, 2, 4, 8, 16 y 30 segundos |
| servicios/eventos.py | Guarda hasta 50 eventos sin conexión y los manda en orden al volver |
| main.py | Arma todo para la Pico |
| simulador/ws_servidor.py | Servidor WebSocket hecho a mano con asyncio |
| simulador/validar.py | Revisa cada mensaje contra el contrato, en los dos sentidos |
| simulador/escenarios.py | Pruebas automáticas con PASS y FAIL |
| simulador/cuna_software.py | Cuna sin hardware para ver el simulador funcionar |
| simulador/README.md | Cómo correrlo y los comandos |
| tests/ | 162 pruebas en total, 51 nuevas en esta etapa |

## 2. Decisiones técnicas

Una sesión limpia siempre. Al caerse la conexión, por cualquier motivo, la sesión apaga el micrófono, cierra la voz y avisa al gestor de audio. Una canción del servidor se vacía y se calla. Una nana local sigue sonando, porque no depende de la red. La luz no se toca. Esto lo comprueban las pruebas de reconexión.

La cuenta de esperas vuelve a cero solo cuando llega welcome. Con un token malo la espera sigue creciendo. Así la cuna no martilla al servidor.

Los eventos no se pierden en silencio. Si un envío falla a la mitad, el evento sigue pendiente y sale al reconectar. Si hay más de 50, se descartan los más viejos y dropped_before dice cuántos.

El simulador valida todo. Cada mensaje que manda la cuna se revisa contra el contrato. Cada mensaje que manda el propio simulador también. Cada prueba de integración termina comprobando que la lista de problemas está vacía.

Cambié el simulador a un servidor propio sin dependencias. Antes usaba la biblioteca websockets. Dejé una prueba de compatibilidad con esa biblioteca, que se salta si no está instalada. Esa prueba encontró un error real. La cuna no respondía al cierre del servidor y esperaba 10 segundos. Ya está corregido.

## 3. Lo que NO es el simulador

No tiene base de datos, ni cuentas, ni autenticación propia. Solo compara un token fijo. Todo eso es del servidor de Jan Carlo. El simulador solo sirve para probar la cuna.

## 4. Cómo probar

En tu PC.

    cd cuna
    python3 -m unittest discover -s tests -t . -v

Sin la Pico, con las dos terminales.

    python3 -m simulador.servidor_sim --puerto 8080 --escenario con-corte
    python3 -m simulador.cuna_software --puerto 8080

Con la Pico. Pon la IP de tu PC y el token en secrets.py. Corre el simulador con --host 0.0.0.0 y el escenario completo. Las órdenes de la consola están en simulador/README.md.

## 5. Resultados

| Qué | Resultado |
| --- | --- |
| Suite completa | 162 pruebas, todas pasan, 64 segundos |
| Escenario con-corte, cuna de software | 13 de 13 pasos pasan |
| Pruebas de sesión y reconexión | 21 |
| Pruebas de interferencia entre módulos | 8 |
| Pruebas de eventos | 12 |

Revisé que las pruebas detecten fallos. Rompí el código a propósito en tres lugares. Dos pruebas lo detectaron. La tercera ruptura pasó sin que nadie la notara, así que escribí una prueba nueva que sí la detecta.

Una prueba de interop imprime un aviso de cierre de la biblioteca websockets. Es ruido de esa biblioteca y no cambia el resultado.

## 6. Estado de los criterios

| Criterio | Estado |
| --- | --- |
| Luz, nanas y voz juntas sin estorbarse | VALIDADO SOLO CON SIMULADOR |
| Reconexión con esperas del contrato | VALIDADO SOLO CON SIMULADOR |
| Confirmación de cada orden con ack o error | VALIDADO SOLO CON SIMULADOR |
| Estados reportados iguales a los reales | VALIDADO SOLO CON SIMULADOR |
| Eventos guardados sin conexión y enviados en orden | VALIDADO SOLO CON SIMULADOR |
| Formatos del contrato | VALIDADO SOLO CON SIMULADOR |
| Cliente WebSocket en la Pico | IMPLEMENTADO NO PROBADO EN HARDWARE |
| Sincronización con ntptime y hashlib.sha1 | IMPLEMENTADO NO PROBADO EN HARDWARE |
| Lectura de rssi | NO IMPLEMENTADO. Se reporta null |
| Integración con el servidor de Jan Carlo | PENDIENTE DE INTEGRACIÓN EXTERNA |
| Eventos SCRUM-22 y alertas SCRUM-25 en el servidor | PENDIENTE DE INTEGRACIÓN EXTERNA |
| SCRUM-44 y SCRUM-45 | NO IMPLEMENTADO. Sigue en el servidor, después de esta etapa |

Prueba con simulador no es integración real. Que el simulador pase significa que la cuna cumple el contrato como yo lo escribí. No significa que el servidor de Jan Carlo lo entienda igual. Hay que repetir los pasos con su servidor.

## 7. Qué debe repetir Jan Carlo con su servidor

1. Aceptar hello con el token de la cuna y responder welcome.
2. Aceptar los cambios propuestos: trama vacía tipo 3 como fin de canción, los campos extra de audio.state, el código NO_SESSION, el voice.state periódico, el campo voice en caps y los eventos siempre con severidad info.
3. Guardar los eventos con su event_id y su ts original.
4. Correr el escenario completo contra su servidor y comparar con el simulador.

## 8. Riesgos

El cliente WebSocket es mío y no está probado en la Pico. Si falla, el plan B es aiohttp o una biblioteca del proyecto micropython-lib.

La memoria. Las colas de audio y voz ocupan RAM de una Pico con 520 kB. No medí cuánta queda libre. El status la reporta en free_ram, mídela.

El archivo de las dos nanas pesa 576 kB. Hay que ver si cabe en la flash junto con el resto.

El Wi-Fi puede no alcanzar para voz y canciones a la vez con el ADC leyendo a 8 kHz. Es el riesgo ya anotado en la Etapa 4.

La voz sigue siendo por turnos. Jira dice bidireccional. Está anotado desde la Etapa 4.

## 9. Qué necesito de ti

El valor de mic_hz_real y de free_ram cuando corras la cuna en la Pico.
Si las dos nanas caben en la flash.
La aprobación de Jan Carlo sobre los cambios al contrato.
Los datos pendientes de antes: serigrafía y puentes del PCM5102A, modelo del transistor, si tienes cautín y qué resistencias tienes.

## 10. Fuentes

Esta etapa no usó fuentes nuevas. Se apoya en las de las etapas 2, 3 y 4. El protocolo WebSocket sigue el RFC 6455: https://www.rfc-editor.org/rfc/rfc6455
