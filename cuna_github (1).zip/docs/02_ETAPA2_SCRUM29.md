# Etapa 2: SCRUM-29 Luz de noche

Fecha: 25 de noviembre de 2026.
Contrato usado: CONTRATO.md versión 1, estado PROPUESTO.

## 1. Qué se hizo

Se programó la luz de noche, la conexión al servidor y un simulador del servidor para probar sin hardware. No se tocó audio ni voz. Esos mensajes responden UNSUPPORTED hasta las etapas 3 y 4.

| Archivo | Para qué sirve |
| --- | --- |
| config.py | Valores fijos: pin, frecuencia, tiempos |
| secrets_example.py | Plantilla de Wi-Fi, servidor, UUID y token. secrets.py va en .gitignore |
| hal/luz.py | Brillo por PWM con curva y transición suave |
| protocolo/mensajes.py | Lectura y armado de los mensajes JSON |
| servicios/luz_servicio.py | Atiende light.set y light.get |
| servicios/ws_cliente.py | Cliente WebSocket propio sobre asyncio |
| servicios/reloj.py | Hora por NTP, o la del servidor si NTP falla |
| servicios/cuna_app.py | Une todo y reparte los mensajes |
| main.py | Arranque, Wi-Fi, reconexión, latido y perro guardián |
| simulador/servidor_sim.py | Servidor falso para tu PC |
| tests/ | 31 pruebas automáticas |

## 2. Decisiones técnicas

Cliente WebSocket propio. Sirve para no depender de aiohttp, que tiene reportes de caídas con envíos sostenidos y que no pude probar. Solo usa open_connection, readline, readexactly, write y drain, que están en la documentación de asyncio de MicroPython. Descarté aiohttp. Limitaciones: sin TLS y sin mensajes fragmentados.

Curva del brillo con exponente 2,2. Sirve para que el 50 por ciento se vea a medio camino y no casi al máximo. Descarté el duty lineal. Limitación: el exponente es una estimación y se ajusta mirando el LED real.

Frecuencia PWM de 1000 Hz. Está dentro del rango de 8 Hz a 62,5 MHz que documenta MicroPython. Se puede ajustar si el LED parpadea.

Transición suave en pasos de 20 ms. Una orden nueva corta la anterior y parte desde el brillo real en ese momento.

La luz vive aparte de la conexión. Si cae el Wi-Fi, la luz conserva su estado. Esto sigue el contrato.

Perro guardián de 8000 ms. El máximo documentado en rp2 es 8388 ms. Si asyncio se traba, la Pico se reinicia.

Reglas que quedaron explícitas y que el contrato no decía. Encender con brillo 0 deja la luz apagada y reporta on falso. Apagada se reporta con brillo 0, aunque se recuerda el último brillo para la próxima vez. Una orden inválida no gasta su seq.

## 3. Conexión del circuito

Se arma en la protoboard. Todo con la Pico apagada.

| De | A |
| --- | --- |
| GP18, pin 24 | Resistencia de 1 kΩ, luego base del 2N3904 |
| Emisor del 2N3904 | GND de la Pico, por ejemplo pin 23 |
| VBUS, pin 40 | Resistencia de 220 Ω, luego ánodo del LED |
| Cátodo del LED | Colector del 2N3904 |

El 2N3904 de frente, con la parte plana hacia ti, tiene de izquierda a derecha emisor, base y colector. Eso aplica al encapsulado TO-92 de la mayoría de los fabricantes. Revisa la hoja del tuyo, porque otros transistores sustitutos tienen otro orden.

Cuando la compra llegue, dime qué transistor es y lo confirmo.

## 4. Cómo correr las pruebas

En tu PC con Python 3.

```
pip install websockets
cd cuna
python3 -m unittest discover -s tests -t . -v
```

Resultado en mi entorno: 31 pruebas pasan.

## 5. Cómo instalar en la Pico

1. Instala MicroPython 1.29.0 para RPI_PICO2_W desde la página oficial.
2. Copia la carpeta cuna a la Pico, sin la carpeta tests ni simulador. Thonny o mpremote sirven.
3. Copia secrets_example.py como secrets.py y llena Wi-Fi, IP del servidor, UUID y token.
4. En tu PC corre el simulador con la IP de tu red:
   `python3 simulador/servidor_sim.py --host 0.0.0.0 --puerto 8080 --token EL_MISMO_TOKEN`
5. Reinicia la Pico. En la consola del simulador escribe on 40, off o get.

## 6. Estado de los criterios

| Criterio | Estado |
| --- | --- |
| SCRUM-29 CA1: brillo por PWM desde la app | IMPLEMENTADO NO PROBADO EN HARDWARE. El protocolo y la lógica están VALIDADOS SOLO CON SIMULADOR |
| SCRUM-29 CA2: cambio reflejado en las cuentas vinculadas | PENDIENTE DE INTEGRACIÓN EXTERNA. La cuna manda light.state. Jan Carlo lo reparte |
| Conexión, hello, welcome y token | VALIDADO SOLO CON SIMULADOR |
| Reconexión con esperas, latido y perro guardián | IMPLEMENTADO NO PROBADO EN HARDWARE. Sin prueba ni siquiera en simulador |
| NTP y reloj en la Pico | IMPLEMENTADO NO PROBADO EN HARDWARE |
| Eventos y búfer de 50 eventos de SCRUM-22 | NO IMPLEMENTADO. Queda para una etapa posterior |
| Audio y voz | NO IMPLEMENTADO |

Honestidad sobre las pruebas. Las 31 pruebas corren en Python normal en mi entorno, con un PWM falso y un servidor falso. No hay ninguna prueba en una Pico. No sé todavía si el LED se ve bien con la curva, si el cliente WebSocket aguanta en la Pico ni si ntptime funciona con tu red.

## 7. Qué no pude confirmar en la documentación

La lectura del rssi del Wi-Fi. Por eso status manda rssi en null por ahora.

El módulo ntptime. Está en el código dentro de un try, así que si no existe, la cuna usa la hora del servidor.

hashlib.sha1 en la Pico. Si no existe, el cliente se salta la verificación de Sec-WebSocket-Accept.

## 8. Dos respuestas que me pediste

SCRUM-44 y SCRUM-45 los pongo del lado del servidor, como módulo de Python en una carpeta servidor, aparte del firmware. La razón es que el bot de Telegram de SCRUM-24, el disparo de SCRUM-25 y la base de datos de rangos horarios ya están allá. El kit de seguridad solo recibe el mensaje kit.armed. Así Jan Carlo lo enchufa sin cambiar tu firmware. Lo programo después de la etapa 5, con pruebas y sin mandar nada real a Telegram.

Tu PAM8403 tiene almohadillas con hueco, sin pines y sin bornes de tornillo. En las fotos se leen L, tierra y R para la entrada, 5V y menos para la alimentación, y L-OUT y R-OUT para el parlante. Hay que soldar cables o pines. Sin soldador no es confiable. Se necesita en la etapa 3.

## 9. Fuentes

- I2S y asyncio: https://docs.micropython.org/en/latest/library/asyncio.html
- Perro guardián: https://docs.micropython.org/en/v1.25.0/_sources/library/machine.WDT.rst.txt
- PWM, rp2: https://docs.micropython.org/en/v1.25.0/_sources/rp2/quickref.rst.txt
- Pines: https://pico2w.pinout.xyz/
