# Guía de instalación de la cuna

Para la Raspberry Pi Pico 2 W con MicroPython 1.29.0. Todo el circuito es propuesta y falta probarlo. Arma de a poco y prueba cada parte antes de pasar a la siguiente.

## 1. Qué necesitas

En tu PC: Python 3.10 o más nuevo, mpremote y un cable USB con datos. Se instala con pip install mpremote. Thonny también sirve.

En la mesa: la Pico 2 W con pines soldados, protoboard, jumpers, el LED con su resistencia de 220 Ω, una resistencia de 1 kΩ, un 2N3904 y el módulo PCM5102A. También el PAM8403 con cables soldados a sus almohadillas, un parlante, y las piezas del micrófono.

Estado de las compras. El PCM5102A, el 2N3904 y el MCP6002 estaban pendientes de compra. El PAM8403 ya lo tienes, pero sus almohadillas necesitan soldadura.

## 2. Instalar MicroPython

1. Baja el archivo RPI_PICO2_W-20260824-v1.29.0.uf2 de https://micropython.org/download/RPI_PICO2_W/. Es la versión estable que vi en la página el 25 de noviembre de 2026.
2. Mantén apretado el botón BOOTSEL de la Pico y conéctala al USB.
3. Aparece una unidad de disco. Copia el archivo uf2 ahí.
4. La Pico se reinicia sola y queda lista.

## 3. Copiar el programa

Desde la carpeta cuna de tu PC, con la Pico conectada.

    mpremote cp -r hal :
    mpremote cp -r protocolo :
    mpremote cp -r servicios :
    mpremote cp -r assets :
    mpremote cp config.py :
    mpremote cp main.py :

No copies tests, simulador, servidor ni tools. Esas carpetas son solo para tu PC.

Antes de copiar, mira el espacio libre. En la Pico abre el REPL con mpremote repl y escribe lo siguiente.

    import os
    s = os.statvfs("/")
    print(s[0] * s[3])

El número son los bytes libres. Las dos nanas pesan 576 000. Si no caben, copia solo una y avísame.

## 4. Secretos

En tu PC copia secrets_example.py como secrets.py. Llena el nombre y la clave del Wi-Fi, la IP de tu PC, el puerto 8080, el UUID de la cuna y el token. Luego.

    mpremote cp secrets.py :

El archivo secrets.py nunca se sube a un repositorio. Ya está en .gitignore. La Pico solo usa Wi-Fi de 2,4 GHz.

## 5. Armar el circuito por partes

Todo con la Pico desconectada del USB.

### 5.1 Luz

| De | A |
| --- | --- |
| GP18, pin 24 | Resistencia de 1 kΩ, luego base del 2N3904 |
| Emisor del 2N3904 | GND, por ejemplo pin 23 |
| VBUS, pin 40 | Resistencia de 220 Ω, luego ánodo del LED |
| Cátodo del LED | Colector del 2N3904 |

Con el TO-92 de frente y la parte plana hacia ti, de izquierda a derecha suelen ir emisor, base y colector. Revisa la hoja de tu transistor, porque algunos sustitutos tienen otro orden.

### 5.2 Audio

| De | A |
| --- | --- |
| GP10, pin 14 | BCK del PCM5102A |
| GP11, pin 15 | LRCK del PCM5102A |
| GP12, pin 16 | DIN del PCM5102A |
| 3V3, pin 36 | VIN del PCM5102A |
| GND | GND del PCM5102A |
| Salida L del PCM5102A | Entrada L del PAM8403 |
| VBUS, pin 40 | 5V del PAM8403 |
| GND de la Pico | Tierra del PAM8403 |
| Parlante | Entre las dos almohadillas de L-OUT |

El parlante no va a tierra. Las salidas del PAM8403 son diferenciales. Pon un condensador de 100 nF y uno de 10 µF entre 5V y tierra del PAM8403, lo más cerca posible.

Mira la serigrafía de tu PCM5102A. Muchos módulos traen puentes de soldadura con nombres como SCK, FMT y XSMT que hay que dejar en cierta posición. No pude confirmarlo en la hoja del chip. Mándame una foto antes de energizar. También falta confirmar que tu módulo acepte 3,3 V en VIN.

### 5.2b Audio sin DAC, modo tonos

Si no tienes el PCM5102A, usa este modo. Es el que viene por defecto en config.py. No armes el bloque 5.2 con el DAC. Arma el bloque B del diagrama versión 4. GP12, pin 16, va a una resistencia de 10 kΩ y de ahí a L IN del PAM8403. De L IN sale una resistencia de 1 kΩ a tierra. El parlante va entre L-OUT más y L-OUT menos. Empieza con volumen bajo.

En este modo suenan las nanas guardadas en la cuna. No suena la voz de la app ni las canciones del servidor. Para volver al DAC, cambia AUDIO_SALIDA a "i2s" en config.py y arma el bloque 5.2.

### 5.3 Micrófono

El circuito completo con sus valores está en ETAPA4_SCRUM31.md, sección 4. Es una propuesta sin probar. Arma el micrófono al final, cuando la luz y el audio ya funcionen.

## 6. Primera prueba, en este orden

1. En tu PC corre el simulador.

        python3 -m simulador.servidor_sim --host 0.0.0.0 --puerto 8080 --token EL_MISMO_TOKEN

   Si tu PC tiene firewall, deja pasar el puerto 8080.
2. Conecta la Pico. Corre main.py con mpremote run main.py o reiniciándola. El simulador debe imprimir un mensaje hello.
3. Escribe on 40 y luego off. Prueba la luz.
4. Pon el volumen en 20 con vol 20. Escribe play local nana-1. Empieza bajo y sube de a poco.
5. Cuando el audio funcione, prueba voz start.
6. Al final corre el escenario automático de ETAPA6_pruebas_y_criterios.md, prueba 13.

Anota los resultados en la tabla de la sección 4 de ETAPA6_pruebas_y_criterios.md.

## 7. Si algo falla

| Síntoma | Qué mirar |
| --- | --- |
| La Pico no conecta | Wi-Fi de 2,4 GHz, nombre y clave en secrets.py, que la IP sea la de tu PC |
| Conecta y se cae cada rato | El simulador debe seguir corriendo. Mira el mensaje de error en el REPL |
| El token se rechaza | El token de secrets.py y el de --token deben ser idénticos |
| La luz no enciende | Orden de las patas del transistor y la polaridad del LED |
| No suena | Que el parlante esté entre las dos almohadillas de L-OUT. Mira los puentes del PCM5102A |
| Suena con cortes | Mira los eventos AUDIO_UNDERRUN. Prueba una nana local, que no depende de la red |
| La voz suena rara | Mira mic_hz_real. Si está lejos de 8000, baja MIC_RATE_HZ |
| La Pico se reinicia sola | Es el perro guardián. Algo se trabó más de 8 segundos |

## 8. Después, con el servidor de Jan Carlo

Cambia SERVIDOR_HOST y SERVIDOR_PUERTO en secrets.py. Corre otra vez las pruebas 1, 2, 5, 7, 10 y 12 de la sección 4 del documento de pruebas. Que todo funcione con el simulador no garantiza que funcione con su servidor.

## 9. Fuentes

- Descarga e instalación de MicroPython para la Pico 2 W: https://micropython.org/download/RPI_PICO2_W/
- Copiar carpetas y correr scripts con mpremote: https://docs.micropython.org/en/latest/reference/mpremote.html
