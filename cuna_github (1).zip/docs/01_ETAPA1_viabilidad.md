# Etapa 1: verificación técnica y contrato de integración

Proyecto: Cuna Inteligente, Ecosistema IoT Infantil.
Historias: SCRUM-29, SCRUM-30, SCRUM-31 parte A, SCRUM-44 y SCRUM-45.
Fecha: 25 de noviembre de 2026.
Estado: no hay código funcional. Esta etapa solo verifica y propone.

## 1. Arquitectura propuesta

La cuna es un cliente. Se conecta al servidor por un solo WebSocket. Por ahí van los mensajes JSON de control y el audio binario. No hay broker MQTT.

Dentro de la Pico hay tareas de asyncio. Una maneja la conexión. Una maneja la luz. Una maneja el gestor de audio. Una captura el micrófono. Una manda el latido. Todas comparten un solo gestor de audio, que deja sonar una fuente a la vez.

Por qué un solo WebSocket: Jira pide WebRTC o WebSockets de baja latencia. La Pico no puede hacer WebRTC. Un solo canal es más simple de depurar y gasta menos memoria.

Alternativa descartada: MQTT para el control y otro canal para el audio. Descarté esto porque exige dos conexiones en una Pico con 520 kB de RAM.

Limitación: un solo canal mezcla control y audio. Si el audio satura la red, el control se retrasa. Se mitiga con tramas pequeñas de 20 ms.

### Estructura de carpetas propuesta

```
cuna/
  main.py
  config.py
  secrets_example.py
  .gitignore
  hal/
    luz.py
    audio_out.py
    mic.py
  servicios/
    red.py
    ws_cliente.py
    gestor_audio.py
    eventos.py
  protocolo/
    mensajes.py
    audio_frames.py
  assets/
    nana-1.pcm
    nana-2.pcm
  tests/
  simulador/
    servidor_sim.py
```

secrets.py nunca se sube. Va en .gitignore. Solo se sube secrets_example.py con valores falsos.

## 2. Matriz de trazabilidad

| Historia | Criterio | Requisito | Pieza | Estado |
| --- | --- | --- | --- | --- |
| SCRUM-29 | CA1 brillo por PWM desde la app | LUZ-01 a LUZ-11 | hal/luz.py, mensajes light.set | NO IMPLEMENTADO |
| SCRUM-29 | CA2 cambio visible en cuentas vinculadas | LUZ y GEN | light.state al servidor | PENDIENTE DE INTEGRACIÓN EXTERNA |
| SCRUM-30 | CA1 elegir audio y controlar volumen | NAN-01 a NAN-11 | gestor_audio.py, audio.play, audio.volume | NO IMPLEMENTADO |
| SCRUM-30 | CA2 audio local o del servidor, suena en la cuna | NAN | audio_out.py, canciones en flash | NO IMPLEMENTADO |
| SCRUM-31 A | CA1 botón de la app inicia la voz | VOZ | voice.start | PENDIENTE DE INTEGRACIÓN EXTERNA |
| SCRUM-31 A | CA2 voz en los dos sentidos | VOZ-01 a VOZ-10 | mic.py, audio_out.py, tramas tipo 1 y 2 | NO IMPLEMENTADO, por turnos |
| SCRUM-44 | CA1 el kit no hace ruido | ALR | requisito para el kit | PENDIENTE, dueño del módulo por decidir |
| SCRUM-44 | CA2 notificación silenciosa con enlace o foto | ALR-01 a ALR-06 | envío con disable_notification | NO IMPLEMENTADO |
| SCRUM-45 | CA1 definir rangos horarios | HOR | servidor y app | NO IMPLEMENTADO |
| SCRUM-45 | CA2 sin capturas ni alertas fuera del rango | HOR | estado kit.armed | NO IMPLEMENTADO |
| SCRUM-45 | CA3 botón manual | HOR | kit.manual | NO IMPLEMENTADO |
| SCRUM-32 | Alimentación | Sin software | Fuera de alcance | No aplica |

Nota sobre SCRUM-31 CA2. Jira dice bidireccional. La maqueta hace turnos. Esto cumple el criterio solo en parte y debe declararse así en la defensa.

## 3. Hardware y pines

Estado del hardware: confirmado es lo que ya tienes. Propuesto es lo que elegí. Pendiente de compra es lo que falta.

| Función | Pin GPIO | Pin físico | Estado |
| --- | --- | --- | --- |
| PWM de la luz, canal PWM1 A | GP18 | 24 | Propuesto |
| I2S reloj de bit BCK | GP10 | 14 | Propuesto |
| I2S reloj de palabra LRCK | GP11 | 15 | Propuesto |
| I2S datos | GP12 | 16 | Propuesto |
| Entrada del micrófono, ADC | GP26 | 31 | Propuesto |
| Tierra analógica | AGND | 33 | Propuesto |
| Referencia ADC | ADC_VREF | 35 | Propuesto |
| 3,3 V | 3V3 | 36 | Propuesto |
| 5 V del USB | VBUS | 40 | Propuesto |

Regla verificada: en el rp2, el pin ws debe ser el pin sck más uno. Con sck en GP10 y ws en GP11 se cumple. Los pines de datos pueden ser otros.

GP10 a GP12 y GP18 y GP26 también tienen funciones SPI o I2C. No las usamos, así que no hay choque. El Wi-Fi usa GPIO23, 24, 25 y 29, que no tocamos.

| Componente | Estado |
| --- | --- |
| Raspberry Pi Pico 2 W con pines soldados | Confirmado |
| Protoboard y jumpers | Confirmado |
| LED de 5 mm y resistencias de 220 Ω, 1 kΩ y 4,7 kΩ | Confirmado, en lista aparte |
| Condensadores 2 de 100 nF y 1 de 10 µF | Confirmado |
| PAM8403 | Confirmado. Falta saber si tiene pines o bornes |
| Parlante de audífonos viejos | Confirmado |
| Cápsula de micrófono de audífonos viejos | Confirmado. Falta hallar la tierra por continuidad |
| Transistor 2N3904 | Pendiente de compra. Sirven 2N2222, PN2222, BC547 o BC337 |
| DAC PCM5102A | Pendiente de compra |
| Amplificador MCP6002 | Pendiente de compra. Sirven MCP6001, MCP6004 o LMV358, o un módulo MAX4466 o MAX9814, o un micrófono digital INMP441 |

## 4. Dependencias de software

| Dependencia | Para qué | Estado |
| --- | --- | --- |
| MicroPython 1.29.0 para RPI_PICO2_W | Firmware base | Verificado en la página de descargas |
| machine.PWM, machine.ADC, machine.I2S, machine.Timer | Luz, micrófono y audio | Documentados |
| network.WLAN | Wi-Fi | Documentado |
| asyncio | Tareas concurrentes | Documentado |
| aiohttp de micropython-lib | Cliente WebSocket | Existe, sin prueba en nuestra Pico |
| micropython-async-websocket-client | Alternativa de cliente | Existe, sin prueba |
| Python 3 con websockets o aiohttp | Simulador de servidor en tu PC | Se define en la etapa 5 |

No uso ninguna función que no esté en la documentación. Si una clase no existe en la versión instalada, lo diré y no la inventaré.

## 5. Viabilidad y riesgos

| Riesgo | Gravedad | Qué se verificó | Qué falta |
| --- | --- | --- | --- |
| Captura del micrófono a 8 kHz con Wi-Fi e I2S activos | Alta | El ADC es de 12 bits y 500 ksps, pero MicroPython no usa DMA para el ADC | Medir en la Pico. El firmware reportará la frecuencia real |
| I2S en RP2350 con MicroPython 1.29.0 | Media | I2S existe desde la 1.19 y usa PIO con DMA. Hay reportes de fallos de PIO en RP2350 con máquinas de estado 8 a 11, y de cuelgues al combinar I2S con bitstream | Probar en la Pico real. Nuestro uso no toca esos casos conocidos |
| Estabilidad del cliente WebSocket | Alta | Hay un reporte de caídas TLS con envíos sostenidos en ESP32 | Probar tramas binarias sostenidas durante varios minutos |
| Memoria de 520 kB | Media | Dato del datasheet | Medir RAM libre durante la voz |
| Módulo PCM5102A | Media | El chip acepta I2S de 16 bits y genera su reloj interno desde BCK | Revisar los puentes de soldadura del módulo que compres |
| Corriente por USB | Media | El 3V3 de la Pico da menos de 300 mA | Medir con el parlante a volumen alto. Ver el límite de volumen |
| Voz por turnos contra la palabra bidireccional | Media | Es decisión tuya | Declararlo en la defensa |
| Dos núcleos con _thread | Baja | Hay un reporte de que las IRQ de pines no funcionan en el núcleo 1 | No usamos el segundo núcleo |
| Máximo de corriente por pin GPIO | Baja | El datasheet fetched no lo indica | Por eso la luz va con transistor y no directa |

Qué es seguro y qué no. Las funciones y parámetros de la tabla de dependencias están en la documentación. Lo que dice cada riesgo como "falta" no está probado. No tengo resultados de pruebas físicas y no voy a inventarlos.

## 6. Decisiones técnicas

Un solo WebSocket. Sirve para unir control y audio. Descarté MQTT y WebRTC. La limitación es que mezcla los dos tipos de tráfico.

Voz a 8 kHz hacia el servidor. Sirve para bajar la carga del ADC y del Wi-Fi. Descarté 16 kHz porque el ADC no tiene DMA. La limitación es voz de calidad telefónica.

Salida a 16 kHz para voz y nanas. Sirve para configurar el I2S una sola vez. Descarté dos formatos distintos. La limitación es que el servidor debe convertir el audio de la app.

PCM5102A más PAM8403. Sirve para tener audio digital limpio sin PWM de audio. Descarté PWM como audio por ruido. La limitación es que hay que comprar el DAC.

Luz con transistor 2N3904. Sirve para no depender del límite de corriente del pin, que el datasheet no da. Descarté el LED directo al pin. La limitación es una pieza más.

Volumen por software con tope. Sirve para cuidar el parlante pequeño. Se usa un desplazamiento de bits o multiplicación de muestras con rampa corta. Descarté el volumen por hardware porque no tienes potenciómetro.

Micrófono apagado por defecto. Sirve para la privacidad del bebé y la familia. Solo se activa con una orden autenticada.

Dos nanas en flash como respaldo. Sirve para que suenen aunque caiga el Wi-Fi. La limitación es el espacio de flash.

## 7. Qué cambia en tu documento de requerimientos

Ya no se usan los temas MQTT de la sección Interfaz con Jan Carlo. Esa sección debe reemplazarse por el contrato de CONTRATO.md. Dime si quieres que lo actualice.

## 8. Decisiones pendientes

1. Dónde y con qué se programan SCRUM-44 y SCRUM-45. Eres la dueña, pero el bot de Telegram y la alerta están en el servidor de otros compañeros.
2. Si tu PAM8403 tiene pines o bornes.
3. Aprobación de Jan Carlo sobre el contrato, sobre todo ruta, puerto, token, catálogo de canciones y voz por turnos.
4. Si todos los eventos de la cuna pueden ir con severidad info, por la regla de SCRUM-25.

Ninguna de estas bloquea la etapa 2 de SCRUM-29, salvo la aprobación de la ruta y el token, que se pueden poner en secrets.py mientras tanto.

## 9. Fuentes

- Descargas de MicroPython: https://www.micropython.org/download/?mcu=rp2350
- Datasheet de la Pico 2 W: https://pip-assets.raspberrypi.com/categories/1088-raspberry-pi-pico-2-w/documents/RP-008304-DS-2-pico-2-w-datasheet.pdf
- Guía rápida de rp2: https://docs.micropython.org/en/v1.25.0/_sources/rp2/quickref.rst.txt
- machine.I2S: https://docs.micropython.org/en/v1.21.0/_sources/library/machine.I2S.rst.txt
- Pines de la Pico 2 W: https://pico2w.pinout.xyz/
- asyncio de MicroPython: https://docs.micropython.org/en/latest/library/asyncio.html
- PCM5102A: https://www.ti.com/product/PCM5102A/datasheet
- PAM8403: https://datasheetq.com/pdf-html/765152/ETC/9page/PAM8403.html
- MCP6002: https://www.lcsc.com/product-detail/C2652308.html
- Cliente aiohttp de micropython-lib: https://github.com/micropython/micropython-lib/pull/941
- Problema de WebSocket con TLS: https://github.com/micropython/micropython-lib/issues/851
- Telegram sendPhoto: https://core.telegram.org/bots/api/methods/sendphoto.md
