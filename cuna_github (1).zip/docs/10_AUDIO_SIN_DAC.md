# Audio sin DAC: modo tonos

Este cambio deja que la cuna suene sin el PCM5102A. El audio sale por PWM en GP12 hacia el PAM8403. Todo es propuesta. No se probó en una Pico.

## Qué suena y qué no

Las nanas guardadas en la cuna suenan como notas. Cada nana es una melodía hecha de seno y un segundo armónico. La cuna mide la frecuencia de cada trozo de 20 ms y pone el PWM en esa nota. El volumen sale del tamaño de la onda, con un tope de la mitad del ciclo de trabajo.

No suena la voz que llega de la app. No suenan canciones que manda el servidor. El micrófono de la cuna hacia la app sigue igual.

Esto debilita el criterio de voz de SCRUM-31 en lo que toca al sentido app hacia cuna. Dilo así en la defensa. El sentido cuna hacia app no cambia.

## Qué cambió en el código

| Archivo | Cambio |
| --- | --- |
| hal/audio_tonos.py | Nuevo. Estima la nota de cada trozo y maneja el PWM en GP12 |
| config.py | AUDIO_SALIDA igual a "tonos" por defecto, y siete valores del modo |
| main.py | Elige la salida por tonos o la I2S según AUDIO_SALIDA |
| servicios/gestor_audio.py | Una canción del servidor recibe UNSUPPORTED. La voz de la app se descarta |
| servicios/cuna_app.py | El hello agrega audio_out_mode, voice_playback y server_songs |
| servicios/tareas.py | Nuevo. Ver la sección del error encontrado |
| tests/test_tonos.py, tests/test_tareas.py | 18 y 3 pruebas nuevas |

Para volver al I2S cuando llegue el DAC, cambia AUDIO_SALIDA a "i2s" en config.py. El código I2S no se tocó.

## Error encontrado en las pruebas

Una prueba de extremo a extremo se quedaba colgada al cerrar. La causa era real. Tres funciones esperaban una tarea hija dentro de un try que tragaba CancelledError. Si cancelaban a quien llamaba justo en esa espera, la cancelación se perdía y la sesión nunca terminaba. Pasaba en voz.terminar, en _parar_ya y en _detener_voz_tarea del gestor de audio.

El arreglo es la función cancelar_y_esperar. No espera la tarea con await. Revisa cada 5 ms si ya terminó. La prueba nueva falla con el código viejo.

No lo pude probar en MicroPython. Uso Task.done(), que creo que existe, pero no lo confirmé en la documentación de MicroPython 1.29.0.

## Pruebas

La suite completa tiene 229 pruebas y pasan todas, en CPython 3.13 con salida y servidor falsos. Revisé con mutaciones cuatro cosas: el rechazo de canciones del servidor, el descarte de la voz de la app, el tope del ciclo de trabajo y la bandera solo_tonos. Las cuatro se detectan.

Las dos nanas reales dan sus notas dentro del 3 por ciento con el estimador.

## Estado de los criterios

| Pieza | Estado |
| --- | --- |
| Lógica del modo tonos, rechazos y caps | VALIDADO SOLO CON SIMULADOR |
| PWM como audio en la Pico y el PAM8403 | IMPLEMENTADO NO PROBADO EN HARDWARE |
| Cuánto cambia la frecuencia de GP12 al cambiar GP12 solo | IMPLEMENTADO NO PROBADO EN HARDWARE. La documentación de machine.PWM para RP2 no da el rango de frecuencia |
| Voz de la app hacia la cuna | NO IMPLEMENTADO en este modo |
| Canciones del servidor | NO IMPLEMENTADO en este modo |
| Campos nuevos de caps | PROPUESTO. Pendiente de que Jan Carlo los apruebe |

## Circuito

Está en el bloque B del diagrama versión 4. GP12, pin 16, pasa por 10 kΩ hacia L IN del PAM8403. L IN lleva 1 kΩ a tierra. Los valores son una propuesta para bajar los 3,3 V. No los probé. El parlante va igual que antes, entre L-OUT más y L-OUT menos.

## Qué necesito de ti

Los valores reales de tus resistencias. Si tienes un parlante de 8 Ω. Y cómo suena en la prueba: si el PWM se oye muy ruidoso, el plan es comprar el PCM5102A en otra tienda.

Fuente: https://docs.micropython.org/en/latest/library/machine.PWM.html
