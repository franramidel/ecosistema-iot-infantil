# Contrato de comunicación de la cuna

Estado: PROPUESTO. Falta la aprobación de Jan Carlo.
Versión del protocolo: 1.
Fecha: 25 de noviembre de 2026.

## 1. Estado de los contratos

La copia del repositorio que revisé solo tiene archivos README. No tiene código ni contratos. Por eso no hay contratos existentes que respetar.

| Tipo | Contenido |
| --- | --- |
| Existentes | Ninguno encontrado. |
| Propuestos | Todo lo que aparece en este archivo. |
| Aprobados | Ninguno. |

Todo nombre de ruta, campo o código de error es una propuesta. Todavía no existe en el servidor.

## 2. Conexión

Una sola conexión WebSocket por cuna. Los mensajes de texto llevan JSON de control. Los mensajes binarios llevan audio.

| Aspecto | Propuesta |
| --- | --- |
| Protocolo | WebSocket sin cifrado en la maqueta, con ws://. TLS queda opcional. |
| Dirección | La que ponga Jan Carlo en el archivo secrets.py de la cuna. |
| Puerto | Se define en secrets.py. Ejemplo: 8080. |
| Ruta | /ws/cuna, pendiente de aprobación. |
| Autenticación | La cuna manda su token en el primer mensaje, hello. El servidor lo valida antes de aceptar cualquier otro mensaje. |
| Reconexión | La cuna reintenta con esperas de 1, 2, 4, 8, 16 y 30 segundos. Después sigue cada 30. Al conectar, la cuenta vuelve a empezar. |
| Latido | La cuna manda status cada 30 segundos. El servidor la marca desconectada si pasan 90 segundos sin ningún mensaje. |
| Confirmación | Toda orden recibe un ack o un error. |

## 3. Identificación de los mensajes

| Campo | Significado |
| --- | --- |
| v | Versión del protocolo. Hoy es 1. |
| type | Tipo de mensaje. |
| device_id | UUID de la cuna. Debe ser el Device_ID que registra la plataforma. |
| baby_id | Lo agrega el servidor. La cuna no lo conoce. |
| id | Identificador de solicitud. Lo pone quien manda la orden. |
| ref | En una respuesta, repite el id de la orden. |
| seq | Número de la orden. Lo asigna el servidor. Es uno por cuna y siempre crece. |
| ts | Hora en milisegundos desde 1970. Ver la sección de la hora. |

### La hora

La cuna intenta sincronizar la hora por NTP al conectarse al Wi-Fi. Si falla, usa la hora que manda el servidor en el mensaje welcome. Calcula la diferencia con su reloj interno y la usa en todos los mensajes. Si no logra ninguna de las dos, marca synced en falso y manda también uptime_ms. El servidor decide qué hacer con esas horas.

## 4. Apertura de la conexión

La cuna manda hello al conectar.

```json
{
  "v": 1,
  "type": "hello",
  "device_id": "3f2a9c1e-5b7d-4e8a-9c21-7d4e5f6a8b90",
  "token": "TOKEN_DE_EJEMPLO",
  "fw": "0.1.0",
  "caps": {
    "light": true,
    "audio_out_hz": 16000,
    "audio_in_hz": 8000,
    "local_songs": ["nana-1", "nana-2"]
  },
  "uptime_ms": 1200
}
```

El servidor responde con welcome.

```json
{
  "v": 1,
  "type": "welcome",
  "server_time_ms": 1795600000000,
  "heartbeat_s": 30
}
```

Si el token es inválido, el servidor manda un error UNAUTHORIZED y cierra la conexión.

Después de welcome, la cuna manda su estado completo: light.state, audio.state y status. Así el servidor y las cuentas quedan al día.

## 5. Luz de noche, SCRUM-29

| Mensaje | Sentido | Campos |
| --- | --- | --- |
| light.set | servidor a cuna | seq, on, brightness opcional, fade_ms opcional |
| light.get | servidor a cuna | id |
| light.state | cuna a servidor | seq, on, brightness, cause, ts |
| ack | cuna a servidor | ref, ok, ignored opcional |
| error | cuna a servidor | ref, code, detail |

Reglas:

1. brightness va de 0 a 100. Un valor fuera de rango recibe el error INVALID_RANGE y la luz no cambia.
2. Si on es verdadero y no viene brightness, la cuna usa el último brillo. Si no hay ninguno, usa 30.
3. Si on es falso, la luz se apaga y la cuna recuerda el brillo.
4. fade_ms es la duración del cambio. Por defecto es 1000. Va de 0 a 10000.
5. La cuna guarda el último seq aplicado. Si llega una orden con seq igual o menor, no la aplica. Responde ack con ignored igual a old_seq y manda su estado actual.
6. cause puede ser command, boot o local.
7. La cuna manda light.state cuando termina el cambio y cuando se reconecta.

Ejemplo de orden:

```json
{"v": 1, "type": "light.set", "id": "r-101", "seq": 57, "on": true, "brightness": 40, "fade_ms": 1000}
```

Respuesta inmediata:

```json
{"v": 1, "type": "ack", "ref": "r-101", "ok": true}
```

Estado después del cambio:

```json
{"v": 1, "type": "light.state", "seq": 57, "on": true, "brightness": 40, "cause": "command", "ts": 1795600001000}
```

Ejemplo de error:

```json
{"v": 1, "type": "error", "ref": "r-103", "code": "INVALID_RANGE", "detail": "brightness debe estar entre 0 y 100"}
```

## 6. Nanas, SCRUM-30

El servidor tiene el catálogo de canciones y lo muestra en la app. La cuna solo declara en hello qué canciones tiene guardadas en su memoria, en caps.local_songs.

| Mensaje | Sentido | Campos |
| --- | --- | --- |
| audio.play | servidor a cuna | seq, song_id, source, que es server o local |
| audio.stop | servidor a cuna | seq |
| audio.volume | servidor a cuna | seq, volume de 0 a 100 |
| audio.get | servidor a cuna | id |
| audio.state | cuna a servidor | mode, song_id, source, volume, seq, ts |
| audio.ended | cuna a servidor | song_id, ts |

Reglas:

0. Cambios de la etapa 3, siguen PROPUESTOS. audio.state lleva dos campos extra, underruns y dropped_frames. El servidor avisa el final de una canción con una trama binaria de tipo 3 sin audio, solo la cabecera de 8 bytes. La cuna espera 8 tramas, 160 ms, antes de empezar. Si en 5 segundos no llegan, vuelve a idle sin mandar audio.ended. El audio de cada trama no pasa de 1280 bytes. Una orden audio.play con otra canción sonando reemplaza a la anterior.

1. mode puede ser idle, song o voice.
2. volume es un porcentaje del volumen máximo que permite la cuna. El máximo lo fija la cuna en su configuración, para cuidar el parlante. Pedir 100 no pasa de ese límite.
3. Con source igual a server, la cuna responde ack y el servidor empieza a mandar tramas binarias de tipo 3.
4. Con source igual a local, la cuna lee el archivo de su memoria. Si el song_id no existe, responde UNKNOWN_SONG.
5. Al terminar la canción, la cuna manda audio.ended y después audio.state con mode igual a idle.
6. Una orden audio.play durante una sesión de voz recibe el error BUSY.

Ejemplo:

```json
{"v": 1, "type": "audio.play", "id": "r-201", "seq": 12, "song_id": "nana-1", "source": "server"}
```

```json
{"v": 1, "type": "audio.state", "mode": "song", "song_id": "nana-1", "source": "server", "volume": 30, "seq": 12, "ts": 1795600005000}
```

## 7. Voz, SCRUM-31 parte A

La voz va por turnos. En cada momento habla solo uno: la cuna o la app. Esta es una limitación de la maqueta, porque el micrófono y el parlante están muy cerca y se produciría eco. Jira pide voz bidireccional, así que el criterio se cumple en parte.

| Mensaje | Sentido | Campos |
| --- | --- | --- |
| voice.start | servidor a cuna | id, session_id, turn opcional |
| voice.turn | servidor a cuna | id, session_id, turn |
| voice.stop | servidor a cuna | id, session_id |
| voice.state | cuna a servidor | session_id, active, turn, mic_active, mic_hz_real, dropped_frames, ts |

turn puede ser cradle o app. Si voice.start no trae turn, empieza en cradle.

1. En el turno cradle, el micrófono está activo y la cuna manda tramas de tipo 1. El parlante está en silencio.
2. En el turno app, el micrófono está apagado y la cuna reproduce las tramas de tipo 2.
3. Una sesión empieza normalmente con turn igual a cradle. Así el padre escucha el cuarto primero.
4. Al pasar al turno cradle, la cuna vacía su búfer de reproducción y espera 200 milisegundos antes de abrir el micrófono. Ese valor es una propuesta y se ajusta con pruebas. Al pasar al turno app, el micrófono se apaga de inmediato.
5. Las tramas que llegan fuera de turno se descartan y se cuentan en dropped_frames.
6. El micrófono está apagado por defecto. Solo se enciende con voice.start. Se apaga con voice.stop, si se pierde la conexión o si la cuna se reinicia.
7. voice.start detiene la canción que esté sonando, con una bajada corta de volumen. Al terminar la voz, las nanas quedan detenidas. No se reanudan solas.
8. mic_hz_real es la cantidad de lecturas por segundo que el ADC hizo de verdad desde que se encendió el micrófono. Debe estar cerca de 8000. Si está lejos, el audio sonará mal y hay que bajar la frecuencia.
9. dropped_frames suma las tramas de la app que se descartaron en la cuna y las tramas del micrófono que se perdieron por no alcanzar a enviarse.
10. La cuna manda voice.state al iniciar, al cambiar de turno, al terminar y cada 5 segundos mientras la sesión esté activa. También lo manda al conectarse, con active en falso.

Cambios de la etapa 4, siguen PROPUESTOS.

1. voice.start con una sesión activa de otro session_id recibe BUSY. Con el mismo session_id recibe ack con ignored igual a already_active.
2. voice.turn y voice.stop con un session_id que no coincide reciben el error NO_SESSION, que se agrega a la lista de errores.
3. voice.stop sin sesión activa recibe ack y no cambia nada.
4. Si el micrófono no responde al iniciar, la cuna manda MIC_UNAVAILABLE y no se abre la sesión. Si falla al volver al turno cradle, manda MIC_UNAVAILABLE y la sesión sigue con el micrófono apagado.
5. caps lleva el campo voice, verdadero si la cuna tiene voz. Si es falso, voice.start recibe UNSUPPORTED.

### Modo de salida por tonos (propuesta)

Si la cuna no tiene el DAC, puede sonar por PWM. Entonces solo toca las nanas guardadas en su memoria, como notas. En ese modo el hello agrega tres campos en caps, y los tres son parte de la propuesta y están sin aprobar:

```json
"audio_out_mode": "tones",
"voice_playback": false,
"server_songs": false
```

Con salida I2S esos campos no van. Reglas en modo tonos:

1. audio.play con source igual a server recibe error UNSUPPORTED. La nana local suena normal.
2. La voz de la app no suena. Las tramas de tipo 2 se descartan. El micrófono de la cuna hacia la app sigue funcionando.
3. La app debe leer estos campos para no ofrecer canciones del servidor ni voz hacia la cuna cuando vengan en falso.

Ejemplo:

```json
{"v": 1, "type": "voice.start", "id": "r-301", "session_id": "s-77", "turn": "cradle"}
```

```json
{"v": 1, "type": "voice.state", "session_id": "s-77", "active": true, "turn": "cradle", "mic_active": true, "mic_hz_real": 7980, "dropped_frames": 0, "ts": 1795600010000}
```

Cambio de turno:

```json
{"v": 1, "type": "voice.turn", "id": "r-302", "session_id": "s-77", "turn": "app"}
```

## 8. Datos de audio

Los mensajes binarios del WebSocket llevan audio. No se manda audio dentro de JSON.

Cada mensaje tiene una cabecera de 8 bytes y después el audio.

| Bytes | Campo | Valor |
| --- | --- | --- |
| 0 | versión del formato | 1 |
| 1 | tipo | 1 voz de la cuna a la app, 2 voz de la app a la cuna, 3 canción del servidor a la cuna |
| 2 y 3 | secuencia | entero de 16 bits, big endian. Vuelve a 0 después de 65535 |
| 4 a 7 | marca de tiempo | milisegundos, 32 bits, big endian |
| 8 en adelante | audio | PCM de 16 bits con signo, mono, little endian |

| Tipo | Frecuencia | Trama de 20 ms |
| --- | --- | --- |
| 1 | 8000 Hz | 160 muestras, 320 bytes de audio |
| 2 | 16000 Hz | 320 muestras, 640 bytes de audio |
| 3 | 16000 Hz | 320 muestras, 640 bytes de audio |

Reglas para el servidor:

1. Debe convertir el audio de la app a 16000 Hz mono antes de mandarlo a la cuna.
2. Debe mandar las canciones de tipo 3 a ritmo real. Puede adelantar hasta 500 ms al empezar. No debe mandar más rápido, porque la Pico no puede guardar más audio.
3. Debe reconstruir el audio de tipo 1 usando la secuencia y tratar las tramas perdidas como silencio.

## 9. Estado y eventos

### status

La cuna lo manda cada 30 segundos y después de conectar.

```json
{"v": 1, "type": "status", "uptime_s": 3600, "rssi": -58, "free_ram": 182000, "fw": "0.1.0", "synced": true}
```

### event

Cada cambio importante de la cuna se manda como evento. El servidor los guarda en la tabla de auditoría de SCRUM-20 y le agrega el baby_id.

```json
{
  "v": 1,
  "type": "event",
  "event_id": "e-9001",
  "event_type": "LIGHT_CHANGED",
  "severity": "info",
  "detail": "on=true brightness=40 cause=command",
  "ts": 1795600001000,
  "uptime_ms": 5000,
  "synced": true,
  "dropped_before": 0
}
```

Tipos de evento propuestos: DEVICE_BOOT, LIGHT_CHANGED, SONG_STARTED, SONG_STOPPED, VOICE_STARTED, VOICE_STOPPED, AUDIO_UNDERRUN y DEVICE_ERROR. El nombre no pasa de 50 caracteres, como pide SCRUM-20.

Si no hay conexión, la cuna guarda hasta 50 eventos en memoria. Al reconectar los manda en orden, con su hora original, como pide SCRUM-22. Si el búfer se llena, descarta los más viejos y dropped_before cuenta cuántos perdió.

Atención con severity. SCRUM-25 dispara una alerta en Telegram con cualquier evento de severidad warning o critical. Por eso la cuna manda todo como info. Si se necesita avisar una falla de la cuna, hay que acordar un evento específico.

## 10. Errores

| Código | Cuándo |
| --- | --- |
| BAD_JSON | El mensaje no se pudo leer. |
| BAD_VERSION | La versión del protocolo no es compatible. |
| UNAUTHORIZED | El token es inválido. |
| INVALID_RANGE | Un valor está fuera de rango. |
| UNKNOWN_SONG | La canción no existe en la cuna. |
| BUSY | La orden choca con el estado actual, por ejemplo audio.play durante una sesión de voz. |
| UNSUPPORTED | La cuna no sabe hacer lo que se pide. |
| AUDIO_UNDERRUN | El búfer de audio se vació. Se reporta como evento. |
| MIC_UNAVAILABLE | El micrófono no responde. |
| NO_SESSION | voice.turn o voice.stop con un session_id que no es el de la sesión activa. |
| INTERNAL | Falla interna de la cuna. |

## 11. Qué hace la cuna si se pierde la conexión

| Función | Comportamiento |
| --- | --- |
| Luz | Mantiene su último estado. No se apaga ni parpadea. |
| Canción del servidor | Reproduce lo que tenga en el búfer, después queda en silencio y pasa a idle. |
| Canción local | Sigue sonando. |
| Voz | Detiene la captura, apaga el micrófono, vacía los búferes y cierra la sesión. |
| Eventos | Los guarda en un búfer de 50. |
| Reconexión | Sigue los tiempos de la sección 2 y manda hello otra vez. |

## 12. Salida de audio compartida

1. Una sola fuente suena a la vez: reposo, canción o voz.
2. voice.start detiene la canción. Al terminar la voz, las nanas quedan detenidas.
3. audio.play durante una sesión de voz recibe BUSY.
4. En cada turno solo se reproduce o transmite lo que corresponde. Las tramas fuera de turno se descartan.

## 13. SCRUM-44 Notificación silenciosa

Este módulo no es firmware de la cuna. Vive en el lado del servidor, junto a las alertas de SCRUM-24 y SCRUM-25. Está pendiente definir dónde se programa.

Entrada: el evento de alerta que dispara SCRUM-25. Campos propuestos.

```json
{
  "event_id": "e-5001",
  "event_type": "DOOR_OPENED",
  "severity": "critical",
  "occurred_at": "2026-11-25T02:14:08-06:00",
  "baby_id": "UUID_DEL_BEBE",
  "device_id": "UUID_DEL_DISPOSITIVO",
  "photo": {
    "url_signed": "https://ejemplo.invalid/foto?firma=EJEMPLO",
    "expires_at": "2026-11-25T02:24:08-06:00"
  }
}
```

photo puede ser null si la foto aún no está lista.

Salida: un mensaje de Telegram enviado con el parámetro disable_notification en verdadero. Según la documentación del bot de Telegram, el usuario recibe una notificación sin sonido. Con foto se usa sendPhoto. Sin foto se usa sendMessage y el enlace va en el texto.

Reglas:

1. La alerta debe salir en menos de 2 segundos, como pide SCRUM-25. Si la foto no está lista, se manda primero el mensaje. Cuando la foto esté lista, se manda un segundo mensaje, también silencioso.
2. Se reutiliza el bot de SCRUM-24. No se crea otro.
3. El kit de seguridad no debe llevar zumbador ni parlante. Eso es un requisito para el módulo de SCRUM-42, no se implementa aquí.
4. El silencio en el teléfono depende del teléfono y de la aplicación de Telegram. El servidor solo puede pedir que el mensaje sea silencioso.

## 14. SCRUM-45 Ventanas horarias y control manual

Este módulo tampoco es firmware de la cuna. Vive en el servidor y en la app. El kit de seguridad solo recibe el estado.

Quién administra qué:

| Dato | Quién lo administra |
| --- | --- |
| La hora | El servidor. Zona America/Costa_Rica, UTC-6, sin horario de verano. |
| Los rangos horarios | El servidor, en la base de datos. |
| Los cambios manuales | El servidor. El botón de la app le manda la orden. |
| La decisión de capturar y alertar | El kit, con el estado que le manda el servidor. |

Rango horario propuesto:

```json
{
  "schedule_id": "h-1",
  "days": [1, 2, 3, 4, 5, 6, 7],
  "start": "20:00",
  "end": "06:00",
  "enabled": true
}
```

days usa 1 para lunes y 7 para domingo.

Reglas:

1. Un rango con inicio mayor que el fin cruza la medianoche. El día que cuenta es el de inicio. El rango del lunes de 20:00 a 06:00 va del lunes a las 20:00 hasta el martes a las 06:00.
2. La hora de inicio entra en el rango. La hora de fin no entra.
3. Los rangos que se solapan se rechazan con el error SCHEDULE_OVERLAP.
4. Sin rangos definidos, el kit queda inactivo.
5. El botón manual activa o desactiva el kit al instante. La orden manual manda hasta el siguiente cambio de rango, es decir, hasta que empiece o termine una ventana. Si no hay rangos, manda hasta que alguien la cambie.
6. Fuera del rango activo no se generan capturas ni alertas. El kit no debe tomar la foto.

Mensaje del servidor al kit. El kit es de otro integrante, así que este mensaje se acuerda con él.

```json
{"v": 1, "type": "kit.armed", "armed": true, "reason": "schedule", "seq": 31, "ts": 1795600020000}
```

reason puede ser schedule, manual o none.

Orden manual desde la app al servidor:

```json
{"v": 1, "type": "kit.manual", "action": "disarm"}
```

action puede ser arm o disarm.

## 15. Qué debe hacer Jan Carlo

1. Servidor WebSocket en la ruta acordada, con validación de token en hello.
2. Asignar el seq de cada orden y guardar el estado de cada cuna como fuente de verdad.
3. Sincronizar el estado entre las cuentas vinculadas, con los light.state, audio.state y voice.state que manda la cuna.
4. Mandar el audio de tipo 3 a ritmo real, y convertir el audio de la app a 16000 Hz mono.
5. Reconstruir el audio de tipo 1 y entregarlo a la app.
6. Implementar los turnos de voz en la app y el botón que inicia la voz.
7. Guardar los eventos en la tabla de auditoría con el baby_id del bebé activo.
8. Marcar la cuna como desconectada si pasan 90 segundos sin mensajes.

## 16. Pendientes de aprobación

1. Ruta, puerto y forma de entregar el token a cada cuna.
2. Si el servidor tiene el catálogo y los archivos de las canciones.
3. Si Jan Carlo acepta la voz por turnos.
4. Si todos los eventos de la cuna pueden ir con severidad info.
5. Dónde se programan SCRUM-44 y SCRUM-45. Decisión de la cuna: del lado del servidor, como módulo aparte.
6. El mensaje kit.armed, con el integrante que haga el firmware del kit.
7. La trama de tipo 3 sin audio como fin de canción, y los campos extra de audio.state.
8. Los cambios de la etapa 4 en la sección de voz: NO_SESSION, ack ignored already_active, voice.state periódico y el campo voice en caps.
9. Los campos audio_out_mode, voice_playback y server_songs en caps, para la salida por tonos.
