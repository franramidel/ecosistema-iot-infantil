# Guía de defensa del proyecto

Para Claudia. Sirve para presentar la parte de la cuna y contestar preguntas. Está escrita para que no digas nada que no puedas respaldar.

## 1. La idea en un minuto

La cuna es una maqueta funcional hecha con piezas baratas. Una Raspberry Pi Pico 2 W controla una luz de noche, reproduce nanas por un parlante y puede hablar con la app por voz. Todo se manda por una sola conexión WebSocket a un servidor. Yo hice el lado de la cuna. Jan Carlo hace la app y el servidor.

Mis historias son SCRUM-29, luz de noche, SCRUM-30, nanas, y SCRUM-31 parte A, voz. También SCRUM-44 y SCRUM-45, que viven en el servidor.

## 2. Qué decir que está terminado

El código de la cuna está completo para luz, nanas y voz. Tiene 229 pruebas automáticas que pasan. Reconecta sola si se cae el Wi-Fi. Guarda hasta 50 eventos sin conexión y los manda en orden al volver. Hay un simulador del servidor que valida cada mensaje contra el contrato, y un escenario automático que lo prueba de punta a punta.

El módulo de SCRUM-44 y SCRUM-45 está hecho y probado. Valida horarios, maneja el botón manual y arma alertas silenciosas de Telegram.

## 3. Qué NO decir

No digas que la cuna funciona en hardware. Todo lo probado fue con piezas falsas. Di que está implementada y validada con simulador, y que las pruebas en la Pico siguen pendientes.

No digas que está integrada con el servidor. El contrato es una propuesta mía. Jan Carlo no lo ha aprobado.

No digas que la voz es bidireccional en tiempo real. Va por turnos, no a la vez.

No digas que la voz de la app suena en la cuna si usas el modo tonos. En ese modo solo suenan las nanas guardadas, como notas por PWM. La voz de la cuna hacia la app sí funciona. Si llega el DAC, se cambia AUDIO_SALIDA a i2s y la voz vuelve a sonar, pero eso tampoco está probado en hardware.

No digas que se mandó una alerta a Telegram. Nunca se mandó nada real.

No digas que el kit no hace ruido. Eso es un requisito de hardware de otra historia.

## 4. Demostración

Con hardware, si ya lo probaste. Corre el simulador, conecta la cuna, escribe on 40, play local nana-1 y voz start. Muestra cada reacción.

Sin hardware, o si algo falla. Corre estos dos comandos en dos terminales y muestra el escenario con sus PASS.

    python3 -m simulador.servidor_sim --puerto 8080 --escenario con-corte
    python3 -m simulador.cuna_software --puerto 8080

Di con claridad que ahí corre una cuna de software, no la Pico.

Muestra también las pruebas.

    python3 -m unittest discover -s tests -t .

## 5. Decisiones que debes poder explicar

Un solo WebSocket en vez de MQTT. Jira permite WebSocket para la voz. Con un solo canal van los mensajes de control en JSON y el audio en tramas binarias. Es más simple de mantener en una Pico.

Voz por turnos. La Pico tiene poca memoria y un parlante y un micrófono pegados en una maqueta producen eco. Por turnos se evita el eco y se simplifica. El costo es que no es simultánea.

La voz corta la nana y la nana no vuelve sola. Fue tu decisión. Un padre que habla no quiere que la nana siga después.

Micrófono apagado por defecto. Solo se enciende con una orden explícita. Es una decisión de privacidad.

Cliente WebSocket escrito a mano. La biblioteca aiohttp tenía reportes de inestabilidad en MicroPython. Escribir el cliente cuesta más pruebas, pero se controla todo.

Volumen con tope. El volumen 100 solo llega a la mitad de la ganancia posible. Es un valor inicial y se ajusta escuchando. Los cambios de volumen y los paros usan rampas cortas para evitar chasquidos.

Un simulador sin base de datos. El simulador no es un segundo backend. Solo valida el contrato.

## 6. Preguntas probables

**¿Por qué no usaron WebRTC?** Jira acepta WebRTC o WebSockets. WebRTC en una Pico no es realista. WebSocket sí cabe.

**¿Por qué una Pico y no un ESP32?** Porque ya tenías la Pico con los pines soldados y la Pico 2 W trae Wi-Fi. Es una maqueta de bajo costo.

**¿Cómo saben que funciona si no lo probaron en la Pico?** Se probó la lógica completa con hardware falso y un servidor simulado. Eso demuestra el protocolo y el manejo de errores. No demuestra el audio ni el micrófono reales. Hay un plan de 14 pruebas para eso.

**¿Qué pasa si se cae el Wi-Fi?** La luz queda como estaba. Una nana local sigue sonando. Una canción del servidor se vacía y se calla. La voz se cierra y el micrófono se apaga. La cuna reconecta con esperas de 1, 2, 4, 8, 16 y 30 segundos.

**¿Qué pasa si se llena el búfer de eventos?** Se descartan los más viejos y un contador dice cuántos se perdieron.

**¿Cómo se protege la conexión?** Con un token propio por cuna que se valida en el primer mensaje. En la maqueta la conexión no va cifrada. En producción habría que usar TLS. No lo probé.

**¿Qué es lo más riesgoso?** El micrófono. MicroPython no ofrece lectura del ADC por DMA. Se lee con un temporizador a 8 kHz y no sé si la Pico llega a esa velocidad con el Wi-Fi activo. La cuna mide el ritmo real y lo reporta en mic_hz_real.

**¿Cómo funciona el silencio de las alertas?** El servidor manda el mensaje a Telegram con disable_notification en verdadero. La documentación dice que así llega sin sonido. Si el teléfono suena o no depende del teléfono.

**¿Y si el horario cruza la medianoche?** Un rango de 20:00 a 06:00 que empieza el lunes termina el martes a las 06:00. La hora de inicio entra y la de fin no. Hay pruebas para esos bordes.

**¿Qué falta?** La integración con el servidor de Jan Carlo, la app, las pruebas en la Pico, y que el kit de seguridad acepte el mensaje kit.armed.

**¿Qué haría distinto?** Probar el hardware antes. Y pedir el contrato aprobado desde el inicio, no al final.

## 7. Reparto del trabajo

Yo hice el firmware de la cuna, el simulador, el contrato propuesto y el módulo de SCRUM-44 y SCRUM-45. Jan Carlo hace la app, el servidor y la base de datos. No toqué módulos de otros compañeros.

## 8. Estado en una tabla para tener a mano

| Parte | Estado |
| --- | --- |
| Luz, nanas y voz en la cuna | IMPLEMENTADO NO PROBADO EN HARDWARE, VALIDADO CON SIMULADOR |
| Reconexión, eventos, latido | VALIDADO SOLO CON SIMULADOR |
| SCRUM-44 y 45, lógica del servidor | VALIDADO SOLO CON SIMULADOR |
| App y servidor real | PENDIENTE DE INTEGRACIÓN EXTERNA |
| Kit sin zumbador | NO IMPLEMENTADO, es de SCRUM-42 |
