# Etapa 4: micrófono y voz, SCRUM-31 parte A

Fecha: 25 de noviembre de 2026.
Contrato: CONTRATO.md versión 1, con los cambios de la etapa 4 marcados como PROPUESTOS.

## 1. Qué se hizo

La cuna ya puede captar voz con el micrófono y mandarla al servidor. También puede reproducir la voz que llega de la app. Va por turnos: o habla la cuna o habla la app. El micrófono está apagado por defecto y solo se enciende con una orden voice.start. Esa parte de la app y del servidor es de Jan Carlo.

| Archivo | Para qué sirve |
| --- | --- |
| hal/mic.py | Lee el ADC con un temporizador, quita el nivel de continua y entrega tramas de 20 ms |
| servicios/voz.py | Maneja la sesión de voz, los turnos y el envío del micrófono |
| servicios/gestor_audio.py | Se amplió con el modo voz. Sigue sonando una sola fuente a la vez |
| servicios/enlace.py | Ahora también manda audio binario |
| simulador/servidor_sim.py | Ahora maneja voz y guarda en voz_cuna.wav lo que oyó la cuna |
| tests/ | 111 pruebas en total, 47 nuevas de micrófono y voz |

## 2. Decisiones técnicas

Lectura del micrófono con un temporizador a 8000 Hz. MicroPython no ofrece ADC por DMA, así que la lectura depende del temporizador. La documentación de Timer dice que la frecuencia máxima depende del puerto y no da un valor. La de ADC no da la velocidad de muestreo. Por eso no sé si la Pico alcanza los 8 kHz con el Wi-Fi activo. Descarté leer en un bucle de asyncio, porque bloquearía todo lo demás. Limitación: es la parte de más riesgo de toda la cuna.

El callback del temporizador es mínimo. La documentación dice que no se puede pedir memoria dentro de un manejador de interrupción. Por eso el callback solo guarda un número en un búfer ya creado, suma contadores y avisa con ThreadSafeFlag, que la documentación indica para interrupciones.

La cuna mide cuántas lecturas hizo de verdad y lo reporta en mic_hz_real. Sirve para saber si el audio sonará mal sin tener que adivinar. Si el número queda lejos de 8000, hay que bajar MIC_RATE_HZ en config.py y avisar al servidor, que lee la frecuencia en caps.audio_in_hz.

Anillo de 6 tramas, 120 ms. Si el Wi-Fi no deja enviar a tiempo y el anillo se llena, se pierde la trama nueva y se cuenta en dropped_frames. Descarté acumular sin límite porque la RAM es de 520 kB.

Nivel de continua con promedio lento. El micrófono con su amplificador queda centrado a la mitad de la escala del ADC. El código resta ese centro y lo sigue con una constante de tiempo de unos 64 ms. Después multiplica por una ganancia fija de 4 y recorta sin dar la vuelta. La ganancia es un valor inicial y se ajusta escuchando.

Cálculo con viper, igual que el volumen. La documentación no dice si ptr16 tiene signo, así que el código lo maneja a mano. No tengo MicroPython aquí, así que la versión viper no está probada. Lo probado es el mismo cálculo en Python normal.

Turnos. Al pasar al turno de la cuna, se vacía el búfer de reproducción, se espera 200 ms y se abre el micrófono. Al pasar al turno de la app, el micrófono se apaga de inmediato y empieza a sonar la voz que llegue. El volumen de la voz entra directo, sin la subida gradual de las nanas, para no comerse las primeras palabras.

Si se cae la conexión, el micrófono se apaga siempre. Si el envío falla en medio de la sesión, el micrófono también se apaga.

La voz corta la nana con una bajada de volumen de 60 ms y la nana no se reanuda sola. Es lo que tú decidiste.

## 3. Cambios propuestos al contrato

Están en CONTRATO.md, sección 7, y son estos. Un voice.start con otra sesión activa recibe BUSY. Con la misma sesión recibe ack con ignored igual a already_active. Hay un error nuevo, NO_SESSION. La cuna manda voice.state cada 5 segundos durante la sesión. caps lleva un campo voice. Jan Carlo debe aprobarlos.

## 4. Circuito del micrófono

Todo esto es una propuesta. No la probé. Los valores salen de fórmulas estándar y no de una hoja de datos. Revisa antes de armar y avísame si algo no cuadra con las piezas que tienes.

Cápsula de electret con polarización. 3V3 a una resistencia de 4,7 kΩ, y de ahí a la patilla positiva de la cápsula. La otra patilla va a tierra. Esa es la que encuentras por continuidad con la carcasa.

Acople. Del punto de la cápsula, un condensador electrolítico de 10 µF, con el positivo hacia la cápsula, y de ahí una resistencia de 10 kΩ hacia la entrada inversora del MCP6002.

Referencia a mitad de escala. Dos resistencias de 10 kΩ en divisor entre 3V3 y tierra. El punto medio va a la entrada no inversora del MCP6002 y a un condensador de 100 nF a tierra. Ahí quedan 1,65 V.

Ganancia. Una resistencia de 100 kΩ entre la salida y la entrada inversora. La ganancia es 100 kΩ entre 10 kΩ, o sea 10 veces. Si la señal sale muy débil o muy fuerte, se cambia esa resistencia.

Filtro. De la salida del MCP6002 a GP26 va una resistencia de 470 Ω, y de GP26 a tierra un condensador de 100 nF. Corta cerca de 3,4 kHz. Sirve para que los ruidos más agudos no se cuelen al muestrear a 8 kHz. Si no tienes los 470 Ω, con 1 kΩ corta cerca de 1,6 kHz y la voz suena más apagada.

Alimentación. El MCP6002 va a 3V3, pin 36, y su tierra a AGND, pin 33. Un condensador de 100 nF entre su alimentación y su tierra, lo más cerca posible.

El MCP6002 acepta 1,8 a 6 V y es riel a riel, así que sirve a 3,3 V. Eso lo vi en la ficha de un vendedor, no en la hoja del fabricante.

Mantén el micrófono lejos del parlante. Los turnos evitan el eco, pero un parlante pegado a un micrófono genera ruido por vibración.

## 5. Cómo probar

En tu PC.

```
cd cuna
python3 -m unittest discover -s tests -t . -v
```

En la Pico, con el simulador en tu PC, y en este orden.

1. Con la cuna conectada, mira el mensaje voice.state. Debe decir active falso y mic_active falso.
2. Escribe voz start. Habla cerca del micrófono unos segundos.
3. Mira mic_hz_real en los voice.state. Lo importante es que esté cerca de 8000.
4. Escribe voz stop. El simulador guarda voz_cuna.wav. Escúchalo en tu PC.
5. Para probar el otro sentido, escribe voz start, luego voz turno app y luego voz decir assets/nana-1.pcm. La nana debe sonar por el parlante de la cuna.

Empieza con volumen bajo.

## 6. Estado de los criterios

| Criterio | Estado |
| --- | --- |
| SCRUM-31 CA1: botón de la app inicia la voz | PENDIENTE DE INTEGRACIÓN EXTERNA. La cuna entiende voice.start. El botón y el servidor son de Jan Carlo |
| SCRUM-31 CA2: voz en los dos sentidos con micrófono y parlante de la cuna | IMPLEMENTADO NO PROBADO EN HARDWARE, por turnos. Cumple el criterio solo en parte |
| Protocolo, turnos y apagado del micrófono | VALIDADO SOLO CON SIMULADOR |
| Lectura del ADC a 8 kHz con Wi-Fi activo | IMPLEMENTADO NO PROBADO EN HARDWARE. Es el mayor riesgo |
| Cálculo con viper del micrófono | IMPLEMENTADO NO PROBADO EN HARDWARE |
| Transporte WebRTC | NO IMPLEMENTADO. Se usa WebSocket, que Jira permite |
| Eventos de SCRUM-22 | NO IMPLEMENTADO |

Honestidad sobre las pruebas. Las 111 pruebas pasan en mi entorno con un ADC falso, un temporizador falso, un micrófono falso y una salida falsa. No hay ninguna prueba en una Pico. No sé si el temporizador llega a 8 kHz, si el Wi-Fi alcanza para subir y bajar audio, si la voz se entiende, ni si el circuito que propuse funciona.

## 7. Riesgos nuevos

El ADC a 8 kHz. Si el temporizador no alcanza, hay tres caminos. Bajar la frecuencia a 4000 o 6000 Hz, que suena más apagado pero sirve para voz. Cambiar a un micrófono digital INMP441, que usa I2S y no depende del ADC. O comprar un módulo MAX4466, que no resuelve el muestreo pero mejora la señal. Decidimos cuando midas mic_hz_real.

Al apagarse el micrófono por un fallo, la sesión sigue activa. La app lo ve en mic_active falso. Está bien para la maqueta.

El ruido del 3V3 de la Pico. El Wi-Fi mete ruido en esa línea. Por eso propuse AGND para la parte analógica. Si hay mucho zumbido, hay que filtrar más.

## 8. Qué necesito de ti

El valor de mic_hz_real cuando lo midas.
El resultado de buscar la tierra de la cápsula por continuidad.
Qué resistencias tienes además de la de 4,7 kΩ, para cerrar el circuito.
La aprobación de Jan Carlo sobre los cambios de la sección 7 del contrato.

## 9. Fuentes

- Timer, reglas del callback: https://docs.micropython.org/en/v1.25.0/_sources/library/machine.Timer.rst.txt
- ADC: https://docs.micropython.org/en/v1.25.0/_sources/library/machine.ADC.rst.txt
- ThreadSafeFlag y Lock: https://docs.micropython.org/en/latest/library/asyncio.html
- Viper: https://docs.micropython.org/en/latest/reference/speed_python.html
- Pines de la Pico 2 W: https://pico2w.pinout.xyz/
- MCP6002: https://www.lcsc.com/product-detail/C2652308.html
