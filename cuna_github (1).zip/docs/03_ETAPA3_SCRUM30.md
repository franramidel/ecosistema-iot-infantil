# Etapa 3: salida de audio y nanas, SCRUM-30

Fecha: 25 de noviembre de 2026.
Contrato: CONTRATO.md versión 1, con cambios nuevos marcados como PROPUESTOS.

## 1. Qué se hizo

La cuna ya sabe reproducir una nana por el DAC. La nana puede venir del servidor por la red o de la memoria de la cuna. El volumen se controla desde la app. No se tocó el micrófono ni la voz. Esa parte es de la etapa 4.

| Archivo | Para qué sirve |
| --- | --- |
| hal/audio_out.py | Salida I2S hacia el PCM5102A. Se abre al sonar y se cierra al terminar |
| servicios/volumen.py | Volumen por software con curva y tope |
| servicios/gestor_audio.py | Gestor de una sola fuente a la vez. Atiende audio.play, stop, volume y get |
| servicios/enlace.py | Deja vivos el audio y la luz aunque la conexión caiga |
| tools/generar_nanas.py | Genera las dos nanas originales de assets |
| assets/nana-1.pcm y nana-2.pcm | Dos nanas cortas. Pesan 272 kB y 304 kB |
| tests/ | 64 pruebas en total, 33 nuevas de audio |

Las nanas las inventé como melodías simples de una escala pentatónica. No copian ninguna canción.

## 2. Decisiones técnicas

La salida I2S se abre al empezar y se cierra al terminar. Sirve porque la hoja del PCM5102A dice que entra en ahorro de energía si BCK y LRCK se detienen, y porque la documentación de MicroPython no dice qué pasa con la salida cuando el búfer se vacía. Descarté dejar el I2S corriendo sin datos. Limitación: abrir y cerrar mete un pequeño retardo al empezar.

I2S en modo MONO, 16 bits, 16 kHz, con pines BCK en GP10 y LRCK en GP11. La regla de que LRCK sea el pin siguiente a BCK está en la guía de rp2. Los datos van en GP12.

Escritura con asyncio.StreamWriter y drain. Es el patrón que muestra la documentación de machine.I2S. Descarté el modo con callback porque es más difícil de seguir.

Volumen por software con curva cuadrática y tope. El volumen 100 de la app deja la señal a la mitad, según AUDIO_GANANCIA_MAX. Sirve para cuidar el parlante. Descarté I2S.shift porque solo cambia de 6 dB en 6 dB, que es muy brusco. Limitación: el tope y la curva son valores iniciales y se ajustan escuchando.

Escalado de muestras con viper. Es la forma que documenta MicroPython para código rápido. La documentación no dice si ptr16 es con o sin signo. Por eso el código convierte a signo a mano y sirve en los dos casos. Limitación: no tengo MicroPython aquí. La versión viper no está probada. Lo que probé es el mismo cálculo en Python normal.

Subida y bajada de volumen gradual. Un cambio tarda 16 tramas, 320 ms. Al parar, el volumen baja a cero en 3 tramas, 60 ms. Sirve para evitar clics. Limitación: el escalón es por trama, no por muestra, así que puede quedar un leve zumbido en cambios grandes.

Colchón de audio del servidor. La cuna espera 8 tramas, 160 ms, antes de empezar. Guarda hasta 40 tramas, 800 ms. Si el audio se acaba antes de tiempo, mete silencio y cuenta un underrun. Si el servidor manda de más, descarta y cuenta.

Una orden audio.play con otra canción sonando reemplaza la anterior. Parar no manda audio.ended. Terminar sola sí lo manda.

## 3. Cambios propuestos al contrato

El fin de una canción del servidor es una trama de tipo 3 sin audio, solo con la cabecera de 8 bytes. El contrato anterior no decía cómo avisar el final. Este cambio ya está en CONTRATO.md. Jan Carlo debe aprobarlo.

audio.state lleva dos campos extra, underruns y dropped_frames. Son opcionales. Un servidor que no los lea no se rompe.

## 4. Conexión del circuito

Todo con la Pico apagada. Lo que sigue es propuesta y falta confirmar con tus módulos.

| De | A |
| --- | --- |
| GP10, pin 14 | BCK del PCM5102A |
| GP11, pin 15 | LCK o LRCK del PCM5102A |
| GP12, pin 16 | DIN del PCM5102A |
| 3V3, pin 36 | VIN del PCM5102A. No confirmado que el módulo acepte 3,3 V en VIN |
| GND | GND del PCM5102A |
| Salida L del PCM5102A | Entrada L del PAM8403 |
| GND del DAC | Tierra del PAM8403 |
| VBUS, pin 40 | 5V del PAM8403 |
| GND de la Pico | Menos de la alimentación del PAM8403 |
| Parlante | Entre las dos almohadillas de L-OUT |

El parlante va entre las dos almohadillas de L-OUT, la positiva y la negativa. Ninguna de las dos va a tierra, porque las salidas del PAM8403 son diferenciales, según su hoja de datos.

Los módulos PCM5102A suelen traer puentes de soldadura o pines como SCK, FMT y XSMT que hay que dejar en cierta posición. La hoja del chip que revisé no lo confirmó. Mira la serigrafía de tu módulo y dime qué dice. No quiero que lo armes a ciegas.

Con tu PAM8403 hay que soldar cables o pines en las almohadillas. Los condensadores de 100 nF y de 10 µF van entre 5V y tierra del PAM8403, lo más cerca posible.

## 5. Cómo probar

En tu PC.

```
cd cuna
python3 -m unittest discover -s tests -t . -v
```

En la Pico, con el simulador corriendo en tu PC. Comandos en la consola del simulador.

```
play local nana-1
play server assets/nana-1.pcm
vol 40
stop
```

Primero prueba con volumen bajo. Sube de a poco.

## 6. Estado de los criterios

| Criterio | Estado |
| --- | --- |
| SCRUM-30 CA1: elegir un audio y controlar el volumen | IMPLEMENTADO NO PROBADO EN HARDWARE. Protocolo y lógica VALIDADOS SOLO CON SIMULADOR |
| SCRUM-30 CA2: audio en memoria local o en el servidor, suena en el parlante de la cuna | IMPLEMENTADO NO PROBADO EN HARDWARE. Que suene de verdad por el parlante no está probado |
| La app muestra el catálogo y manda el audio | PENDIENTE DE INTEGRACIÓN EXTERNA. Es de Jan Carlo |
| Escalado viper | IMPLEMENTADO NO PROBADO EN HARDWARE |
| I2S con el PCM5102A en la Pico 2 W | IMPLEMENTADO NO PROBADO EN HARDWARE |
| Voz y micrófono | NO IMPLEMENTADO |
| Eventos de SCRUM-22 | NO IMPLEMENTADO |

Honestidad sobre las pruebas. Las 64 pruebas pasan en mi entorno con una salida falsa y un servidor falso. En la salida falsa cada escritura tarda 20 ms para imitar el ritmo real. No probé nada en una Pico. No sé todavía si el I2S funciona bien con el RP2350, si el Wi-Fi alcanza para sostener la nana sin cortes, si el volumen por defecto se oye bien ni si el PCM5102A hace ruido al abrir y cerrar.

## 7. Riesgos nuevos

El espacio en flash. Las dos nanas pesan 576 kB. No sé cuánta flash libre te queda con MicroPython instalado. En la Pico, mira con os.statvfs antes de copiarlas. Si no caben, acorta o deja una sola.

La memoria. Cada trama del servidor se copia a un búfer nuevo de 640 bytes. Con la cola llena son unos 25 kB. Se puede optimizar con búferes fijos si la memoria libre baja de lo seguro. Eso se mide en la Pico.

La nana por Wi-Fi puede cortarse. Hay 160 ms de colchón al empezar y 800 ms como máximo. Si el Wi-Fi tiene tirones más largos, se oirá un corte. Para eso están las dos nanas locales.

## 8. Qué necesito de ti

La serigrafía y los puentes de tu módulo PCM5102A cuando llegue.
El modelo del transistor cuando llegue.
Si tienes soldador para el PAM8403.
La aprobación de Jan Carlo sobre la trama de fin de canción.

## 9. Fuentes

- I2S, shift y uso con asyncio: https://docs.micropython.org/en/v1.21.0/_sources/library/machine.I2S.rst.txt
- Viper: https://docs.micropython.org/en/latest/reference/speed_python.html
- Regla de pines I2S en rp2: https://docs.micropython.org/en/v1.25.0/_sources/rp2/quickref.rst.txt
- Clases de asyncio: https://docs.micropython.org/en/latest/library/asyncio.html
- PCM5102A: https://www.ti.com/product/PCM5102A/datasheet
- PAM8403: https://datasheetq.com/pdf-html/765152/ETC/9page/PAM8403.html
