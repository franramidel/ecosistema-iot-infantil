# SCRUM-44 y SCRUM-45: módulo del servidor

Fecha: 25 de noviembre de 2026.
Contrato: CONTRATO.md secciones 13 y 14. Todo PROPUESTO. Falta la aprobación de Jan Carlo y del integrante que hace el kit.

## 1. Qué se hizo

Un módulo de Python en la carpeta servidor. No es firmware de la cuna. Es lógica pura, sin base de datos, sin red y sin bot propio. Jan Carlo lo conecta a su servidor.

| Archivo | Qué hace |
| --- | --- |
| servidor/horarios.py | Valida los rangos horarios, detecta solapes y dice si una hora cae dentro de una ventana |
| servidor/kit.py | Decide si el kit está armado. Junta las ventanas con el botón manual y manda kit.armed |
| servidor/alertas.py | Arma el mensaje silencioso de Telegram y decide si se manda |
| tests/test_servidor_kit.py | 41 pruebas |

## 2. Cómo cumple cada criterio

SCRUM-44 CA1, que el kit no haga ruido. Del lado del servidor no hay nada que hacer. Es un requisito de hardware para el kit de seguridad, que no debe llevar zumbador. Queda anotado en el contrato y no está implementado aquí.

SCRUM-44 CA2, que la notificación llegue en silencio con el enlace de la foto. Cada mensaje sale con disable_notification en verdadero. La documentación de Telegram dice que así el usuario recibe el aviso sin sonido. Con foto se usa sendPhoto con el URL firmado. Sin foto se usa sendMessage. Si la foto llega después, sale un segundo mensaje, también silencioso. Un URL ya vencido o mal formado se trata como sin foto. El silencio real en el teléfono depende del teléfono y de la app de Telegram. El servidor solo puede pedirlo.

SCRUM-45 CA1, rangos horarios. La validación y la lógica están hechas. La pantalla para definirlos es de la app.

SCRUM-45 CA2, nada de capturas ni alertas fuera del rango. El módulo no manda la alerta si el kit está desarmado. Que el kit no tome la foto depende de su firmware, que recibe kit.armed.

SCRUM-45 CA3, botón manual inmediato. ControlKit.manual cambia el estado al instante y manda kit.armed.

## 3. Reglas que fijé donde el contrato dejaba dudas

Un rango con la misma hora de inicio y fin se rechaza. No se sabe si significa nada o todo el día.

La orden manual vence en el siguiente instante en que empieza o termina cualquier ventana, aunque el estado no cambie. Si dos ventanas se tocan, por ejemplo hasta las 22:00 y desde las 22:00, la orden manual vence a las 22:00. Es la lectura literal del contrato.

Si cambian los rangos mientras hay una orden manual, el vencimiento se recalcula con los rangos nuevos.

Los rangos desactivados no cuentan para los solapes.

Una alerta usa el estado del kit en el momento de procesarla, no el de la hora original del evento. Un evento que llegue tarde después de una desconexión, y fuera de ventana, se descarta. Hay que decidir esto con Jan Carlo.

El mismo event_id no alerta dos veces. Si Telegram falla, el evento no se marca como enviado y se puede reintentar.

## 4. Qué debe conectar Jan Carlo

1. Un enviar de Telegram que use el bot de SCRUM-24. Debe aceptar el nombre del método y los datos. No hay bot nuevo.
2. El chat_id de la cuenta vinculada.
3. Guardar los rangos y llamar a set_rangos al cargarlos o cambiarlos. Si lanza ErrorHorario, devolver su código a la app.
4. Llamar a revisar con un tick, por ejemplo cada 30 segundos, y con forzar al reconectar el kit.
5. Llamar a manual desde el botón de la app.
6. Llamar a procesar cuando entre un evento con severidad warning o critical, y a foto_lista cuando la foto termine de subir.
7. Acordar el mensaje kit.armed con quien haga el firmware del kit.

## 5. Estado

| Qué | Estado |
| --- | --- |
| Ventanas, solapes, cruce de medianoche, zona horaria | VALIDADO SOLO CON SIMULADOR |
| Botón manual y su vencimiento | VALIDADO SOLO CON SIMULADOR |
| Mensajes de Telegram silenciosos | VALIDADO SOLO CON SIMULADOR. No se mandó nada a Telegram |
| Que el teléfono quede en silencio | PENDIENTE DE INTEGRACIÓN EXTERNA |
| Que el kit no tome la foto fuera de ventana | PENDIENTE DE INTEGRACIÓN EXTERNA |
| Pantalla de rangos y botón en la app | PENDIENTE DE INTEGRACIÓN EXTERNA |
| Sin zumbador en el kit | NO IMPLEMENTADO. Es de SCRUM-42 |

Revisé las pruebas rompiendo el código a propósito en cuatro lugares. Las cuatro roturas fueron detectadas.

## 6. Fuente

Telegram Bot API, métodos sendMessage y sendPhoto: https://core.telegram.org/bots/api
