# Guía de Thonny para la Pico 2 W

Esta guía sube la cuna a la Pico con Thonny. Es el camino sin terminal. Todo lo que dice "sin probar" no se ha ejecutado en una Pico real.

## 1. Lo que necesitas

Una Pico 2 W con MicroPython 1.29.0, el programa Thonny y un cable USB que pase datos. Python 3.10 o más nuevo en el PC, para correr una herramienta de este repositorio.

Para instalar MicroPython en la Pico, baja el archivo RPI_PICO2_W-20260824-v1.29.0.uf2 de https://micropython.org/download/RPI_PICO2_W/. Deja pulsado el botón BOOTSEL, conecta la Pico y suelta el botón. Aparece como una unidad. Copia el archivo ahí y la Pico se reinicia sola. Thonny también tiene un botón para instalar MicroPython, que se abre desde la configuración del intérprete. Si lo usas, revisa después que la versión sea la 1.29.0.

## 2. Configurar Thonny

En Thonny entra a Run, luego Select interpreter, y elige MicroPython (Raspberry Pi Pico). Abre View, luego Files, y también View, luego Shell. En el panel Files verás dos listas: una del PC y otra de la Pico.

## 3. Preparar los archivos

No subas todo el repositorio a la Pico. Las pruebas, el simulador y el módulo del servidor son solo para el PC. Desde la raíz del repositorio corre esto.

    python3 tools/preparar_pico.py

Crea la carpeta pico_subir con solo lo que va a la Pico: main.py, config.py, secrets_example.py y las carpetas hal, protocolo, servicios y assets. Una prueba automática revisa que nada de lo que sube dependa de código del PC.

## 4. Subir los archivos

En el panel Files de Thonny, en la lista del PC, entra a la carpeta pico_subir. Selecciona todo menos main.py. Pulsa el botón derecho y elige Upload to. Thonny copia los archivos y las carpetas a la Pico. Los archivos de audio pesan unos 576 kB, así que tarda.

Deja main.py para el final. La razón está en la sección 7.

## 5. Crear secrets.py

La Pico necesita un secrets.py con tus datos. No lo subas desde el repositorio. En Thonny abre secrets_example.py, cambia estos valores y guárdalo con otro nombre en la Pico, no en el PC.

| Valor | Qué poner |
| --- | --- |
| WIFI_SSID y WIFI_CLAVE | La red Wi-Fi de 2,4 GHz a la que se conecta la Pico |
| SERVIDOR_HOST y SERVIDOR_PUERTO | La IP de tu PC y el puerto 8080, mientras uses el simulador |
| DEVICE_ID | Un UUID. Para el simulador sirve cualquiera |
| TOKEN | El mismo que le des al simulador con --token |

En el repositorio, secrets.py está en .gitignore. Si lo guardas ahí por error, git no lo sube.

## 6. Probar primero el hardware solo

Antes de correr la cuna completa, abre tools/prueba_hardware.py en Thonny y pulsa Run. No necesita Wi-Fi y no hay que subirlo. Hace cuatro cosas: imprime la RAM y la flash libres, sube y baja la luz, toca un tono de 440 Hz y otro de 880 Hz, y lee el micrófono durante un segundo. Copia lo que imprime y anota qué viste y oíste. Esos números son los que faltan en el plan de pruebas.

Empieza con el volumen bajo. El tono sale por PWM y es una onda cuadrada.

## 7. Correr la cuna

Ten cuidado con el perro guardián. main.py arranca un WDT de 8 segundos. La documentación de MicroPython dice que un WDT no se puede detener una vez iniciado. Por eso, si detienes el programa con el botón Stop, la Pico se reinicia sola unos 8 segundos después. Eso es normal.

Si subes main.py a la Pico, se ejecuta en cada arranque. Si algo falla ahí y la Pico se reinicia en bucle, es difícil volver a entrar. La documentación de MicroPython dice que Ctrl-C en el REPL puede detener un main.py, y que algunos puertos tienen un modo seguro. No confirmé si la Pico 2 W lo tiene. El camino seguro mientras pruebas es no subir main.py. En Thonny abre main.py desde el PC y pulsa Run. Así corre sin quedar guardado. Cuando todo funcione, súbelo.

Si ya quedó un main.py que reinicia en bucle, intenta detenerlo con Ctrl-C en el Shell apenas la Pico reinicie y bórralo desde el panel Files. Si no lo logras, hay que reinstalar MicroPython con el archivo UF2, y eso borra la flash.

En el PC corre el simulador, en la raíz del repositorio.

    python3 -m simulador.servidor_sim --host 0.0.0.0 --puerto 8080 --token TU_TOKEN --escenario con-corte

Tu PC y la Pico deben estar en la misma red. Revisa que el firewall deje pasar el puerto 8080. Cuando la cuna conecte, el simulador imprime el mensaje hello con la versión del firmware.

## 8. Qué probar y en qué orden

El plan completo de 14 pruebas está en docs/07_ETAPA6_pruebas_y_criterios.md, sección 4. Escribe los resultados reales ahí. Allí algunos comandos usan mpremote. Con Thonny haces lo mismo con el panel Files y el Shell. Por ejemplo, la prueba 4 usa os.statvfs, que puedes escribir en el Shell de Thonny.

## 9. Fuentes

- Thonny, soporte de MicroPython, menús Run y View, y subir archivos y carpetas con el menú del botón derecho: https://github.com/thonny/thonny/wiki/MicroPython
- Intérprete MicroPython (Raspberry Pi Pico) en Thonny: https://core-electronics.com.au/guides/how-to-setup-a-raspberry-pi-pico-and-code-with-thonny/
- Cómo corre Thonny el contenido del editor y sube archivos: https://docs.sunfounder.com/projects/euler-kit/en/latest/pyproject/python_start/download_add.html
- boot.py, main.py, Ctrl-C y modo seguro: https://docs.micropython.org/en/latest/reference/reset_boot.html
- WDT: https://docs.micropython.org/en/latest/library/machine.WDT.html
- ADC: https://docs.micropython.org/en/latest/library/machine.ADC.html
- MicroPython para Pico 2 W: https://micropython.org/download/RPI_PICO2_W/
