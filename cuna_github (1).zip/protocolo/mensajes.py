# Mensajes JSON del contrato. Ver CONTRATO.md, estado PROPUESTO.

import json

import config

V = config.VERSION_PROTOCOLO


def es_entero(x):
    # En Python bool es un entero. Aquí no queremos que True pase como número.
    return isinstance(x, int) and not isinstance(x, bool)


def parsear(texto):
    """Devuelve msg y None si todo bien. Devuelve None y un par codigo, detalle si falla."""
    try:
        msg = json.loads(texto)
    except ValueError:
        return None, ("BAD_JSON", "el mensaje no se pudo leer")
    if not isinstance(msg, dict) or "type" not in msg:
        return None, ("BAD_JSON", "falta el campo type")
    if msg.get("v") != V:
        return None, ("BAD_VERSION", "versión de protocolo no compatible")
    return msg, None


def codificar(msg):
    return json.dumps(msg)


def hello(device_id, token, fw, caps, uptime_ms):
    return {"v": V, "type": "hello", "device_id": device_id, "token": token,
            "fw": fw, "caps": caps, "uptime_ms": uptime_ms}


def ack(ref, ok=True, ignored=None):
    msg = {"v": V, "type": "ack", "ref": ref, "ok": ok}
    if ignored is not None:
        msg["ignored"] = ignored
    return msg


def error(ref, codigo, detalle):
    return {"v": V, "type": "error", "ref": ref, "code": codigo, "detail": detalle}


def light_state(seq, encendida, brillo, causa, ts):
    return {"v": V, "type": "light.state", "seq": seq, "on": encendida,
            "brightness": brillo, "cause": causa, "ts": ts}


def status(uptime_s, rssi, free_ram, fw, synced):
    return {"v": V, "type": "status", "uptime_s": uptime_s, "rssi": rssi,
            "free_ram": free_ram, "fw": fw, "synced": synced}


def audio_state(modo, song_id, source, volumen, seq, ts, underruns, descartadas):
    # underruns y dropped_frames son campos extra propuestos. Ver CONTRATO.md.
    return {"v": V, "type": "audio.state", "mode": modo, "song_id": song_id,
            "source": source, "volume": volumen, "seq": seq, "ts": ts,
            "underruns": underruns, "dropped_frames": descartadas}


def audio_ended(song_id, ts):
    return {"v": V, "type": "audio.ended", "song_id": song_id, "ts": ts}


def voice_state(session_id, activa, turno, mic_activo, mic_hz_real, dropped_frames, ts):
    return {"v": V, "type": "voice.state", "session_id": session_id, "active": activa,
            "turn": turno, "mic_active": mic_activo, "mic_hz_real": mic_hz_real,
            "dropped_frames": dropped_frames, "ts": ts}


def event(event_id, tipo, severidad, detalle, ts, uptime_ms, sincronizado, perdidos_antes):
    return {"v": V, "type": "event", "event_id": event_id, "event_type": tipo,
            "severity": severidad, "detail": detalle, "ts": ts, "uptime_ms": uptime_ms,
            "synced": sincronizado, "dropped_before": perdidos_antes}
