import asyncio
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config
from servicios.eventos import Registro
from simulador.validar import validar


class Reloj:
    def __init__(self):
        self.t = 1000
        self.sync = True

    def ahora(self):
        return 1795600000000 + self.t if self.sync else 0

    def uptime(self):
        return self.t


def nuevo(maximo=50, boot="ab12"):
    r = Reloj()
    return Registro(r.ahora, r.uptime, lambda: r.sync, boot_id=boot, maximo=maximo), r


class PruebasRegistro(unittest.IsolatedAsyncioTestCase):
    async def test_guarda_y_manda_en_orden_con_hora_original(self):
        reg, reloj = nuevo()
        for i in range(3):
            reloj.t += 10
            reg.registrar("LIGHT_CHANGED", "n=%d" % i)
        enviados = []

        async def enviar(msg):
            enviados.append(msg)
        await reg.vaciar(enviar)
        self.assertEqual([e["detail"] for e in enviados], ["n=0", "n=1", "n=2"])
        self.assertEqual([e["uptime_ms"] for e in enviados], [1010, 1020, 1030])
        self.assertEqual(enviados[0]["ts"], 1795600000000 + 1010)
        self.assertEqual(reg.pendientes(), 0)
        for e in enviados:
            self.assertEqual(validar(e, "cuna"), [])

    async def test_ids_unicos_y_severidad_siempre_info(self):
        reg, _ = nuevo()
        for _ in range(5):
            reg.registrar("X", "d")
        ids = [e["event_id"] for e in reg._buf]
        self.assertEqual(len(set(ids)), 5)
        self.assertTrue(all(i.startswith("ab12-") for i in ids))
        self.assertEqual({e["severity"] for e in reg._buf}, {"info"})

    async def test_sin_hora_confiable_se_marca_synced_falso(self):
        reg, reloj = nuevo()
        reloj.sync = False
        reg.registrar("DEVICE_BOOT", "fw")
        e = reg._buf[0]
        self.assertEqual((e["synced"], e["ts"]), (False, 0))
        self.assertEqual(e["uptime_ms"], 1000)             # El uptime sí sirve para ordenar.

    async def test_buffer_lleno_descarta_los_mas_viejos_y_los_cuenta(self):
        reg, _ = nuevo(maximo=5)
        for i in range(12):
            reg.registrar("X", "n=%d" % i)
        self.assertEqual(reg.pendientes(), 5)
        self.assertEqual([e["detail"] for e in reg._buf], ["n=7", "n=8", "n=9", "n=10", "n=11"])
        self.assertEqual(reg._buf[0]["dropped_before"], 7)
        self.assertEqual(sum(e["dropped_before"] for e in reg._buf), 7)
        self.assertEqual(reg.perdidos, 7)

    async def test_el_limite_normal_es_de_50(self):
        reg, _ = nuevo(maximo=config.EVENTOS_MAX)
        for i in range(60):
            reg.registrar("X", str(i))
        self.assertEqual(reg.pendientes(), 50)
        self.assertEqual(reg._buf[0]["dropped_before"], 10)

    async def test_si_falla_el_envio_el_evento_se_queda(self):
        reg, _ = nuevo()
        reg.registrar("A")
        reg.registrar("B")
        enviados = []

        async def enviar(msg):
            if msg["event_type"] == "B":
                raise ConnectionError("cae")
            enviados.append(msg["event_type"])
        with self.assertRaises(ConnectionError):
            await reg.vaciar(enviar)
        self.assertEqual(enviados, ["A"])
        self.assertEqual([e["event_type"] for e in reg._buf], ["B"])

    async def test_limite_de_frecuencia(self):
        reg, reloj = nuevo()
        self.assertTrue(reg.evento("AUDIO_UNDERRUN", "a", 5000))
        reloj.t += 1000
        self.assertFalse(reg.evento("AUDIO_UNDERRUN", "b", 5000))
        self.assertTrue(reg.evento("OTRO", "c", 5000))     # Cada tipo lleva su propia cuenta.
        reloj.t += 5000
        self.assertTrue(reg.evento("AUDIO_UNDERRUN", "d", 5000))
        self.assertEqual(reg.pendientes(), 3)

    async def test_recorta_textos_largos(self):
        reg, _ = nuevo()
        reg.registrar("T" * 80, "d" * 500)
        self.assertEqual(len(reg._buf[0]["event_type"]), 50)
        self.assertEqual(len(reg._buf[0]["detail"]), config.EVENTOS_DETALLE_MAX)

    async def test_el_emisor_manda_apenas_se_registra(self):
        reg, _ = nuevo()
        enviados = []

        async def enviar(msg):
            enviados.append(msg["event_type"])
        tarea = asyncio.create_task(reg.emisor(enviar))
        await asyncio.sleep(0.01)
        reg.registrar("UNO")
        await asyncio.sleep(0.02)
        reg.registrar("DOS")
        await asyncio.sleep(0.02)
        self.assertEqual(enviados, ["UNO", "DOS"])
        tarea.cancel()

    async def test_el_emisor_termina_si_cae_la_conexion_y_no_pierde_eventos(self):
        reg, _ = nuevo()

        async def roto(_m):
            raise ConnectionError("cae")
        tarea = asyncio.create_task(reg.emisor(roto))
        reg.registrar("UNO")
        await asyncio.wait_for(tarea, 1)
        self.assertEqual(reg.pendientes(), 1)

    async def test_pendiente_despierta_al_emisor_con_lo_acumulado(self):
        reg, _ = nuevo()
        reg.registrar("A")
        reg.registrar("B")           # Sin emisor corriendo, como cuando no hay conexión.
        enviados = []

        async def enviar(msg):
            enviados.append(msg["event_type"])
        tarea = asyncio.create_task(reg.emisor(enviar))
        reg.pendiente()
        await asyncio.sleep(0.02)
        self.assertEqual(enviados, ["A", "B"])
        tarea.cancel()

    async def test_tras_un_envio_fallido_hace_falta_pendiente_para_reintentar(self):
        reg, _ = nuevo()

        async def roto(_m):
            raise ConnectionError("cae")
        reg.registrar("A")
        await asyncio.wait_for(asyncio.create_task(reg.emisor(roto)), 1)   # Falla y se rinde.
        self.assertEqual(reg.pendientes(), 1)
        enviados = []

        async def bueno(msg):
            enviados.append(msg["event_type"])
        tarea = asyncio.create_task(reg.emisor(bueno))
        await asyncio.sleep(0.03)
        self.assertEqual(enviados, [])          # El aviso ya se había gastado. Nadie lo despierta.
        reg.pendiente()                         # Esto es lo que hace la sesión al conectar.
        await asyncio.sleep(0.03)
        self.assertEqual(enviados, ["A"])
        tarea.cancel()


if __name__ == "__main__":
    unittest.main()
