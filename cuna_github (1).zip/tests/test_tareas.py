import asyncio
import unittest

from servicios.tareas import cancelar_y_esperar


class PruebasCancelar(unittest.IsolatedAsyncioTestCase):
    async def test_cancela_la_tarea_hija(self):
        async def hija():
            await asyncio.sleep(10)
        t = asyncio.create_task(hija())
        await asyncio.sleep(0)
        await cancelar_y_esperar(t)
        self.assertTrue(t.cancelled())

    async def test_sin_tarea_no_hace_nada(self):
        await cancelar_y_esperar(None)

    async def test_si_cancelan_a_quien_llama_la_cancelacion_sigue_subiendo(self):
        async def hija():
            try:
                await asyncio.sleep(10)
            except asyncio.CancelledError:
                await asyncio.sleep(0.2)     # tarda en cerrar
                raise

        siguio = []

        async def padre():
            h = asyncio.create_task(hija())
            await asyncio.sleep(0)           # deja que la hija arranque
            await cancelar_y_esperar(h)
            siguio.append(True)              # si la cancelación se perdió, llega aquí
            await asyncio.sleep(10)

        p = asyncio.create_task(padre())
        await asyncio.sleep(0.05)            # el padre ya espera a la hija
        p.cancel()
        await asyncio.wait_for(asyncio.gather(p, return_exceptions=True), 2)
        self.assertTrue(p.cancelled())
        self.assertEqual(siguio, [])


if __name__ == "__main__":
    unittest.main()
