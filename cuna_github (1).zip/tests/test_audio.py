import asyncio
import os
import struct
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config
from servicios import gestor_audio as ga
from servicios.gestor_audio import GestorAudio
from servicios.volumen import escalar_pcm16, ganancia_para_volumen
from tests.utiles import ArchivosFalsos, SalidaFalsa, pcm_constante, trama

N = config.AUDIO_TRAMA_BYTES // 2   # Muestras por trama.


class PruebasVolumen(unittest.TestCase):
    def prueba(self, valores, ganancia):
        b = bytearray(struct.pack("<%dh" % len(valores), *valores))
        escalar_pcm16(b, len(valores), ganancia)
        return list(struct.unpack("<%dh" % len(valores), b))

    def test_ganancia_uno_no_cambia(self):
        self.assertEqual(self.prueba([1000, -1000, 32767, -32768], 256), [1000, -1000, 32767, -32768])

    def test_mitad_y_silencio(self):
        self.assertEqual(self.prueba([1000, -1000, 32767, -32768], 128), [500, -500, 16383, -16384])
        self.assertEqual(self.prueba([1000, -1000], 0), [0, 0])

    def test_nunca_se_sale_de_rango_con_ganancia_menor_a_uno(self):
        for g in range(0, 257, 7):
            for v in self.prueba([32767, -32768, 1, -1], g):
                self.assertTrue(-32768 <= v <= 32767)

    def test_curva_de_volumen(self):
        g = [ganancia_para_volumen(v) for v in range(0, 101)]
        self.assertEqual(g[0], 0)
        self.assertEqual(g, sorted(g))
        self.assertLessEqual(g[100], int(256 * config.AUDIO_GANANCIA_MAX))


class Base(unittest.IsolatedAsyncioTestCase):
    def preparar(self, canciones=None):
        self.salida = SalidaFalsa()
        self.enviados = []
        self.archivos = ArchivosFalsos(canciones or {})

        async def enviar(msg):
            self.enviados.append(msg)
        self.g = GestorAudio(self.salida, enviar, lambda: 1000,
                             self.archivos.abrir, self.archivos.listar)

    def de_tipo(self, tipo):
        return [x for x in self.enviados if x["type"] == tipo]

    def play(self, seq, sid, fuente):
        return {"v": 1, "type": "audio.play", "id": "p%d" % seq, "seq": seq,
                "song_id": sid, "source": fuente}


class PruebasLocal(Base):
    async def test_cancion_local_suena_completa_y_avisa(self):
        self.preparar({"nana-1": pcm_constante(20000, N * 30)})
        self.g.volumen = 100
        await self.g.manejar(self.play(1, "nana-1", "local"))
        self.assertEqual(self.de_tipo("ack")[0]["ok"], True)
        self.assertEqual(self.g.modo, "song")
        await self.g.esperar_fin()
        self.assertEqual(self.g.modo, "idle")
        self.assertEqual(len(self.salida.escrituras), 30)
        self.assertEqual(self.salida.aperturas, 1)
        self.assertFalse(self.salida.abierta)       # Se cierra al terminar.
        self.assertEqual(len(self.de_tipo("audio.ended")), 1)
        estados = self.de_tipo("audio.state")
        self.assertEqual([e["mode"] for e in estados], ["song", "idle"])
        self.assertIsNone(estados[-1]["song_id"])

    async def test_sube_suave_y_respeta_el_tope(self):
        self.preparar({"n": pcm_constante(20000, N * 30)})
        self.g.volumen = 100
        await self.g.manejar(self.play(1, "n", "local"))
        await self.g.esperar_fin()
        m = self.salida.muestras()
        primera, ultima = abs(m[0]), abs(m[-1])
        tope = 20000 * int(256 * config.AUDIO_GANANCIA_MAX) // 256
        self.assertLess(primera, tope / 2)        # Empieza bajo.
        self.assertEqual(ultima, tope)            # Llega al tope y no pasa.
        self.assertTrue(all(abs(x) <= tope for x in m))

    async def test_cancion_desconocida(self):
        self.preparar({"a": b"\0" * 640})
        await self.g.manejar(self.play(1, "no-existe", "local"))
        self.assertEqual(self.de_tipo("error")[0]["code"], "UNKNOWN_SONG")
        self.assertEqual(self.g.modo, "idle")
        self.assertEqual(self.g.ultimo_seq, 0)

    async def test_stop_baja_a_cero_antes_de_parar(self):
        self.preparar({"n": pcm_constante(20000, N * 500)})
        self.g.volumen = 100
        await self.g.manejar(self.play(1, "n", "local"))
        await asyncio.sleep(0.15)
        await self.g.manejar({"v": 1, "type": "audio.stop", "id": "s", "seq": 2})
        await self.g.esperar_fin()
        self.assertEqual(self.g.modo, "idle")
        self.assertEqual(len(self.de_tipo("audio.ended")), 0)   # Parar no es terminar.
        ultimas = self.salida.escrituras[-config.AUDIO_TRAMAS_FADE_OUT:]
        self.assertEqual(max(abs(x) for x in struct.unpack("<%dh" % N, ultimas[-1])), 0)
        self.assertLess(len(self.salida.escrituras), 500)
        self.assertFalse(self.salida.abierta)

    async def test_stop_sin_nada_sonando(self):
        self.preparar()
        await self.g.manejar({"v": 1, "type": "audio.stop", "id": "s", "seq": 1})
        self.assertTrue(self.de_tipo("ack")[0]["ok"])
        self.assertEqual(self.de_tipo("audio.state")[-1]["mode"], "idle")

    async def test_cambiar_de_cancion_reemplaza_la_anterior(self):
        self.preparar({"a": pcm_constante(1000, N * 500), "b": pcm_constante(2000, N * 20)})
        await self.g.manejar(self.play(1, "a", "local"))
        await asyncio.sleep(0.05)
        await self.g.manejar(self.play(2, "b", "local"))
        self.assertEqual(self.g.song_id, "b")
        await self.g.esperar_fin()
        self.assertEqual([e["song_id"] for e in self.de_tipo("audio.ended")], ["b"])

    async def test_volumen_valida_rango_y_tipo(self):
        self.preparar()
        await self.g.manejar({"v": 1, "type": "audio.volume", "id": "v", "seq": 1, "volume": 101})
        await self.g.manejar({"v": 1, "type": "audio.volume", "id": "v", "seq": 1, "volume": -1})
        await self.g.manejar({"v": 1, "type": "audio.volume", "id": "v", "seq": 1, "volume": "50"})
        await self.g.manejar({"v": 1, "type": "audio.volume", "id": "v", "seq": 1, "volume": True})
        self.assertEqual([e["code"] for e in self.de_tipo("error")],
                         ["INVALID_RANGE", "INVALID_RANGE", "BAD_JSON", "BAD_JSON"])
        self.assertEqual(self.g.volumen, config.AUDIO_VOLUMEN_DEFECTO)

    async def test_volumen_en_reposo_se_recuerda_y_se_reporta(self):
        self.preparar()
        await self.g.manejar({"v": 1, "type": "audio.volume", "id": "v", "seq": 3, "volume": 55})
        self.assertEqual(self.g.volumen, 55)
        self.assertEqual(self.de_tipo("audio.state")[-1]["volume"], 55)

    async def test_cambio_de_volumen_en_vivo_es_gradual(self):
        self.preparar({"n": pcm_constante(20000, N * 200)})
        self.g.volumen = 100
        await self.g.manejar(self.play(1, "n", "local"))
        await asyncio.sleep(0.12)
        n0 = len(self.salida.escrituras)
        await self.g.manejar({"v": 1, "type": "audio.volume", "id": "v", "seq": 2, "volume": 20})
        await self.g.esperar_fin()
        despues = self.salida.escrituras[n0:]
        picos = [max(abs(x) for x in struct.unpack("<%dh" % (len(t) // 2), t)) for t in despues]
        self.assertEqual(picos, sorted(picos, reverse=True))     # Solo baja.
        self.assertEqual(picos[-1], 20000 * ganancia_para_volumen(20) // 256)
        saltos = [picos[i] - picos[i + 1] for i in range(len(picos) - 1)]
        self.assertLess(max(saltos), 20000 * 20 // 256 + 1)       # Nunca un salto brusco.

    async def test_seq_viejo(self):
        self.preparar({"a": pcm_constante(1000, N * 3)})
        await self.g.manejar({"v": 1, "type": "audio.volume", "id": "v", "seq": 5, "volume": 40})
        await self.g.manejar({"v": 1, "type": "audio.volume", "id": "w", "seq": 5, "volume": 90})
        self.assertEqual(self.g.volumen, 40)
        self.assertEqual(self.de_tipo("ack")[-1].get("ignored"), "old_seq")

    async def test_source_invalido_y_song_id_invalido(self):
        self.preparar()
        await self.g.manejar(self.play(1, "a", "radio"))
        await self.g.manejar(self.play(1, "", "local"))
        await self.g.manejar(self.play(1, 7, "local"))
        self.assertEqual([e["code"] for e in self.de_tipo("error")],
                         ["INVALID_RANGE", "BAD_JSON", "BAD_JSON"])

    async def test_ocupado_por_voz(self):
        self.preparar({"a": b"\0" * 640})
        self.g.modo = ga.VOZ
        await self.g.manejar(self.play(1, "a", "local"))
        self.assertEqual(self.de_tipo("error")[0]["code"], "BUSY")
        self.assertEqual(self.g.modo, ga.VOZ)

    async def test_audio_get(self):
        self.preparar()
        await self.g.manejar({"v": 1, "type": "audio.get", "id": "g"})
        e = self.de_tipo("audio.state")[0]
        self.assertEqual((e["mode"], e["volume"], e["underruns"], e["dropped_frames"]),
                         ("idle", config.AUDIO_VOLUMEN_DEFECTO, 0, 0))


class PruebasServidor(Base):
    async def alimentar(self, n, desde=0, valor=10000):
        for i in range(n):
            self.g.recibir_trama(trama(desde + i, pcm_constante(valor, N)))

    async def test_cancion_del_servidor_espera_el_prebuffer(self):
        self.preparar()
        await self.g.manejar(self.play(1, "n", "server"))
        await asyncio.sleep(0.05)
        self.assertEqual(self.salida.aperturas, 0)           # Aún no hay suficiente audio.
        await self.alimentar(config.AUDIO_PREBUFFER)
        self.g.recibir_trama(trama(99, b""))                 # Fin.
        await self.g.esperar_fin()
        self.assertEqual(len(self.salida.escrituras), config.AUDIO_PREBUFFER)
        self.assertEqual(len(self.de_tipo("audio.ended")), 1)

    async def test_fin_corto_sin_llegar_al_prebuffer(self):
        self.preparar()
        await self.g.manejar(self.play(1, "n", "server"))
        await self.alimentar(2)
        self.g.recibir_trama(trama(2, b""))
        await self.g.esperar_fin()
        self.assertEqual(len(self.salida.escrituras), 2)

    async def test_underrun_se_cuenta_y_se_mete_silencio(self):
        self.preparar()
        await self.g.manejar(self.play(1, "n", "server"))
        await self.alimentar(config.AUDIO_PREBUFFER)
        await asyncio.sleep(0.15)                            # Se vacía la cola y falta audio.
        self.assertGreater(self.g.underruns, 0)
        silencios = [t for t in self.salida.escrituras if not any(t)]
        self.assertGreater(len(silencios), 0)
        self.g.recibir_trama(trama(50, b""))
        await self.g.esperar_fin()
        self.assertGreater(self.de_tipo("audio.state")[-1]["underruns"], 0)

    async def test_tramas_perdidas_y_cola_llena(self):
        self.preparar()
        await self.g.manejar(self.play(1, "n", "server"))
        self.g.recibir_trama(trama(0, pcm_constante(1, N)))
        self.g.recibir_trama(trama(3, pcm_constante(1, N)))   # Faltan la 1 y la 2.
        self.assertEqual(self.g.perdidas, 2)
        await self.alimentar(config.AUDIO_COLA_MAX + 5, desde=4)
        self.assertGreaterEqual(self.g.descartadas, 5)
        await self.g.manejar({"v": 1, "type": "audio.stop", "id": "s", "seq": 2})
        await self.g.esperar_fin()

    async def test_tramas_invalidas_se_descartan(self):
        self.preparar()
        await self.g.manejar(self.play(1, "n", "server"))
        self.g.recibir_trama(b"\x01\x03\x00")                             # Muy corta, se ignora.
        self.g.recibir_trama(struct.pack("!BBHI", 2, 3, 0, 0) + b"\0" * 640)   # Versión 2.
        self.g.recibir_trama(trama(0, b"\0" * 641))                       # Largo impar.
        self.g.recibir_trama(trama(0, b"\0" * 2000))                      # Demasiado grande.
        self.g.recibir_trama(trama(0, b"\0" * 640, tipo=1))               # Tipo de voz, aún no.
        self.assertEqual(len(self.g._cola), 0)
        self.assertEqual(self.g.descartadas, 2)
        await self.g.manejar({"v": 1, "type": "audio.stop", "id": "s", "seq": 2})
        await self.g.esperar_fin()

    async def test_tramas_sin_cancion_se_descartan(self):
        self.preparar()
        self.g.recibir_trama(trama(0, pcm_constante(1, N)))
        self.assertEqual(self.g.descartadas, 1)
        self.assertEqual(len(self.g._cola), 0)

    async def test_prebuffer_vencido_cierra_sin_sonar(self):
        self.preparar()
        viejo = config.AUDIO_TIMEOUT_PREBUFFER_S
        config.AUDIO_TIMEOUT_PREBUFFER_S = 0.05
        try:
            await self.g.manejar(self.play(1, "n", "server"))
            await self.g.esperar_fin()
        finally:
            config.AUDIO_TIMEOUT_PREBUFFER_S = viejo
        self.assertEqual(self.g.modo, "idle")
        self.assertEqual(self.salida.aperturas, 0)
        self.assertEqual(len(self.de_tipo("audio.ended")), 0)

    async def test_conexion_perdida_vacia_el_bufer_y_queda_en_reposo(self):
        self.preparar()
        await self.g.manejar(self.play(1, "n", "server"))
        await self.alimentar(config.AUDIO_PREBUFFER)
        self.g.conexion_perdida()
        await self.g.esperar_fin()
        self.assertEqual(self.g.modo, "idle")
        self.assertEqual(len(self.salida.escrituras), config.AUDIO_PREBUFFER)

    async def test_conexion_perdida_no_corta_cancion_local(self):
        self.preparar({"a": pcm_constante(1000, N * 20)})
        await self.g.manejar(self.play(1, "a", "local"))
        self.g.conexion_perdida()
        await self.g.esperar_fin()
        self.assertEqual(len(self.salida.escrituras), 20)

    async def test_si_no_hay_conexion_al_terminar_no_revienta(self):
        self.preparar({"a": pcm_constante(1000, N * 3)})

        async def enviar_roto(msg):
            if msg["type"] != "audio.state" or msg["mode"] == "idle":
                raise ConnectionError("sin conexión")
        self.g._enviar = enviar_roto
        await self.g._empezar("a", "local")
        await self.g.esperar_fin()
        self.assertEqual(self.g.modo, "idle")


if __name__ == "__main__":
    unittest.main()
