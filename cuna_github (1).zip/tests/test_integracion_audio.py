# Audio de nanas de punta a punta con el simulador. VALIDA PROTOCOLO, NO HARDWARE.
# La salida es falsa y escribe una trama cada 20 ms, como lo haría el I2S real.

import asyncio
import os
import struct
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from simulador.ws_servidor import servir

import config
from hal.luz import Luz
from servicios.cuna_app import CunaApp
from servicios.enlace import Enlace
from servicios.gestor_audio import GestorAudio
from servicios.reloj import Reloj
from servicios.ws_cliente import ClienteWS, ErrorWS
from simulador.servidor_sim import ServidorSim, RUTA
from tests.test_luz import PWMFalso
from tests.utiles import ArchivosFalsos, SalidaFalsa, pcm_constante

TOKEN = "TOKEN_DE_PRUEBA"
N = config.AUDIO_TRAMA_BYTES // 2


class PruebasAudioIntegracion(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.srv = ServidorSim(TOKEN)
        self.servidor = await servir(self.srv.manejador, "127.0.0.1", 0)
        self.puerto = self.servidor.sockets[0].getsockname()[1]
        self.reloj = Reloj()
        self.salida = SalidaFalsa(retardo=0.02)
        self.archivos = ArchivosFalsos({"nana-1": pcm_constante(8000, N * 25),
                                        "nana-2": pcm_constante(8000, N * 25)})
        self.enlace = Enlace()
        self.audio = GestorAudio(self.salida, self.enlace.enviar_json, self.reloj.ahora_ms,
                                 self.archivos.abrir, self.archivos.listar)
        self.audio.volumen = 100
        self.luz = Luz(PWMFalso(), paso_ms=5)

    async def asyncTearDown(self):
        # Todo lo que mandó la cuna debe cumplir el contrato.
        self.assertEqual(self.srv.problemas, [])
        self.servidor.close()
        await self.servidor.wait_closed()

    async def conectar(self):
        cliente = ClienteWS("127.0.0.1", self.puerto, RUTA)
        await cliente.conectar()
        self.enlace.cliente = cliente
        app = CunaApp(cliente, self.luz, self.reloj, "uuid-de-prueba", TOKEN, self.audio)
        await app.saludar()
        escucha = asyncio.create_task(self.bucle(cliente, app))
        return cliente, app, escucha

    async def bucle(self, cliente, app):
        try:
            while True:
                op, datos = await cliente.recibir()
                await app.despachar(op, datos)
        except (ErrorWS, asyncio.IncompleteReadError, ConnectionError):
            pass

    async def esperar_estado(self, modo, timeout=5):
        while True:
            e = await self.srv.esperar("audio.state", timeout)
            if e["mode"] == modo:
                return e

    async def test_hello_declara_las_canciones_locales(self):
        cliente, app, escucha = await self.conectar()
        self.assertEqual(sorted(self.srv.hello["caps"]["local_songs"]), ["nana-1", "nana-2"])
        self.assertEqual(self.srv.hello["caps"]["audio_out_hz"], 16000)
        e = await self.esperar_estado("idle")
        self.assertEqual(e["volume"], 100)
        escucha.cancel()
        await cliente.cerrar()

    async def test_nana_local_de_punta_a_punta(self):
        cliente, app, escucha = await self.conectar()
        await self.esperar_estado("idle")
        await self.srv.audio_play("nana-1", "local")
        e = await self.esperar_estado("song")
        self.assertEqual((e["song_id"], e["source"]), ("nana-1", "local"))
        fin = await self.srv.esperar("audio.ended")
        self.assertEqual(fin["song_id"], "nana-1")
        await self.esperar_estado("idle")
        self.assertEqual(len(self.salida.escrituras), 25)
        escucha.cancel()
        await cliente.cerrar()

    async def test_nana_del_servidor_por_la_red(self):
        cliente, app, escucha = await self.conectar()
        await self.esperar_estado("idle")
        pcm = pcm_constante(8000, N * 50)          # 1 segundo.
        await self.srv.audio_play("cuna-azul", "server")
        await self.esperar_estado("song")
        await self.srv.transmitir(pcm)
        await self.srv.esperar("audio.ended", timeout=5)
        musica = [t for t in self.salida.escrituras if any(t)]
        self.assertEqual(len(musica), 50)
        self.assertEqual(self.audio.perdidas, 0)
        self.assertEqual(self.audio.descartadas, 0)
        escucha.cancel()
        await cliente.cerrar()

    async def test_parar_y_volumen_por_la_red(self):
        cliente, app, escucha = await self.conectar()
        await self.esperar_estado("idle")
        self.archivos.canciones["larga"] = pcm_constante(8000, N * 400)
        await self.srv.audio_play("larga", "local")
        await self.esperar_estado("song")
        await self.srv.audio_volume(40)
        e = await self.esperar_estado("song")
        self.assertEqual(e["volume"], 40)
        await self.srv.audio_stop()
        await self.esperar_estado("idle")
        self.assertEqual(len(self.srv_filtrar("audio.ended")), 0)
        escucha.cancel()
        await cliente.cerrar()

    def srv_filtrar(self, tipo):
        return [x for x in self.srv.recibidos if x["type"] == tipo]

    async def test_cancion_local_sigue_si_cae_la_conexion(self):
        cliente, app, escucha = await self.conectar()
        await self.esperar_estado("idle")
        await self.srv.audio_play("nana-1", "local")
        await self.esperar_estado("song")
        await self.srv.conexion.close()
        await asyncio.sleep(0.05)
        self.enlace.cliente = None
        self.audio.conexion_perdida()
        await self.audio.esperar_fin()                 # No debe fallar al no poder avisar.
        self.assertEqual(len(self.salida.escrituras), 25)
        self.assertEqual(self.audio.modo, "idle")

    async def test_voz_sigue_sin_soporte(self):
        cliente, app, escucha = await self.conectar()
        await self.esperar_estado("idle")
        await self.srv.mandar({"v": 1, "type": "voice.start", "id": "v1", "session_id": "s", "turn": "cradle"})
        err = await self.srv.esperar("error")
        self.assertEqual((err["code"], err["ref"]), ("UNSUPPORTED", "v1"))
        escucha.cancel()
        await cliente.cerrar()


if __name__ == "__main__":
    unittest.main()
