# Banco de pruebas: el firmware completo, sin hardware, contra el simulador.
# Une luz, audio, voz, eventos, sesión y supervisor con piezas falsas de hardware.

import asyncio
import contextlib

import config
from hal.luz import Luz
from servicios.enlace import Enlace
from servicios.eventos import Registro
from servicios.gestor_audio import GestorAudio
from servicios.reloj import Reloj
from servicios.sesion import Cuna
from servicios.supervisor import supervisar
from servicios.voz import ServicioVoz
from simulador.servidor_sim import ServidorSim, RUTA
from simulador.ws_servidor import servir
from tests.test_luz import PWMFalso
from tests.utiles import ArchivosFalsos, MicFalso, SalidaFalsa, pcm_constante

TOKEN = "TOKEN_DE_PRUEBA"
N16 = config.AUDIO_TRAMA_BYTES // 2


@contextlib.contextmanager
def ajustes(**valores):
    """Cambia valores de config por un rato. Sirve para acortar tiempos en las pruebas."""
    viejos = {k: getattr(config, k) for k in valores}
    for k, v in valores.items():
        setattr(config, k, v)
    try:
        yield
    finally:
        for k, v in viejos.items():
            setattr(config, k, v)


class Banco:
    async def abrir(self, canciones=None, token=TOKEN, puerto=0, retardo_salida=0.02, salida=None):
        self.srv = ServidorSim(TOKEN)
        self.servidor = await servir(self.srv.manejador, "127.0.0.1", puerto)
        self.puerto = self.servidor.sockets[0].getsockname()[1]
        self.reloj = Reloj()
        self.pwm = PWMFalso()
        self.luz = Luz(self.pwm, paso_ms=5)
        self.salida = salida or SalidaFalsa(retardo=retardo_salida)
        self.archivos = ArchivosFalsos(canciones if canciones is not None else
                                       {"nana-1": pcm_constante(8000, N16 * 25),
                                        "nana-2": pcm_constante(8000, N16 * 25)})
        self.mic = MicFalso()
        self.enlace = Enlace()
        self.registro = Registro(self.reloj.ahora_ms, self.reloj.uptime_ms, lambda: self.reloj.sincronizado,
                                 boot_id="t001")
        self.audio = GestorAudio(self.salida, self.enlace.enviar_json, self.reloj.ahora_ms,
                                 self.archivos.abrir, self.archivos.listar, self.registro.evento)
        self.audio.volumen = 100
        self.voz = ServicioVoz(self.audio, self.mic, self.enlace.enviar_json, self.enlace.enviar_binario,
                               self.reloj.ahora_ms, self.registro.evento)
        self.cuna = Cuna(self.luz, self.audio, self.voz, self.reloj, self.enlace, self.registro,
                         "127.0.0.1", self.puerto, "uuid-de-prueba", token,
                         leer_estado=lambda: (-60, 100000))
        self.esperas = []
        self.errores = []
        self.supervisor = None
        return self

    def arrancar(self, dormir=None):
        """Arranca la cuna con su supervisor de reconexión."""
        async def dormir_rapido(s):
            self.esperas.append(s)
            await asyncio.sleep(0.01)
        self.supervisor = asyncio.create_task(supervisar(
            self.cuna.una_sesion, self.cuna.estado, dormir=dormir or dormir_rapido,
            avisar=self.errores.append))
        return self.supervisor

    async def cerrar(self):
        if self.supervisor is not None:
            self.supervisor.cancel()
            try:
                await self.supervisor
            except asyncio.CancelledError:
                pass
        await self.voz.terminar(False)
        self.servidor.close()
        await self.servidor.wait_closed()

    def eventos_recibidos(self):
        return [m for m in self.srv.recibidos if m["type"] == "event"]

    def tipos_de_evento(self):
        return [e["event_type"] for e in self.eventos_recibidos()]

    async def esperar_evento(self, tipo, timeout=3):
        fin = asyncio.get_running_loop().time() + timeout
        while tipo not in self.tipos_de_evento():
            if asyncio.get_running_loop().time() > fin:
                raise asyncio.TimeoutError("no llegó el evento " + tipo)
            await asyncio.sleep(0.01)
