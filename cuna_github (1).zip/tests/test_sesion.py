# Sesión completa, reconexión y errores de comunicación. VALIDADO SOLO CON SIMULADOR.
# El firmware corre entero con hardware falso contra el servidor simulado.

import asyncio
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config
from servicios.supervisor import supervisar
from simulador.ws_servidor import servir
from tests.banco import Banco, TOKEN, N16, ajustes
from tests.utiles import pcm_constante


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.b = await Banco().abrir()
        self.srv = self.b.srv

    async def asyncTearDown(self):
        await self.b.cerrar()
        self.assertEqual(self.srv.problemas, [])      # La cuna siempre cumple el contrato.

    async def conectar(self, n=1):
        self.b.arrancar()
        await self.srv.esperar_hello(n)
        await self.srv.esperar("status")              # Ya terminó el saludo.


class PruebasSesion(Base):
    async def test_al_conectar_manda_status_y_todos_los_estados(self):
        with ajustes(LATIDO_S=30):
            self.b.arrancar()
            await self.srv.esperar_hello(1)
            tipos = []
            for _ in range(6):
                try:
                    tipos.append((await asyncio.wait_for(self.srv._cola.get(), 1))["type"])
                except asyncio.TimeoutError:
                    break
            for esperado in ("light.state", "audio.state", "voice.state", "status"):
                self.assertIn(esperado, tipos)
            self.assertEqual(self.b.cuna.sesiones, 1)

    async def test_latido_periodico(self):
        with ajustes(LATIDO_S=0.05):
            await self.conectar()
            await asyncio.sleep(0.2)
            estados = [m for m in self.srv.recibidos if m["type"] == "status"]
            self.assertGreaterEqual(len(estados), 3)
            self.assertEqual(estados[0]["rssi"], -60)
            self.assertEqual(estados[0]["free_ram"], 100000)

    async def test_el_arranque_se_registra_y_llega(self):
        self.b.registro.evento("DEVICE_BOOT", "fw=0.3.0")     # Lo que hace main.py al arrancar.
        await self.conectar()
        await self.b.esperar_evento("DEVICE_BOOT")
        boot = self.b.eventos_recibidos()[0]
        self.assertEqual((boot["synced"], boot["dropped_before"]), (False, 0))

    async def test_los_cambios_generan_eventos(self):
        await self.conectar()
        await self.srv.light_set(True, 40, fade_ms=0)
        await self.srv.esperar("light.state")
        await self.srv.audio_play("nana-1", "local")
        await self.b.esperar_evento("SONG_STOPPED", 5)
        await self.srv.voice_start("s-1")
        await self.srv.esperar("voice.state")
        await self.srv.voice_stop()
        await self.b.esperar_evento("VOICE_STOPPED")
        tipos = self.b.tipos_de_evento()
        for t in ("LIGHT_CHANGED", "SONG_STARTED", "SONG_STOPPED", "VOICE_STARTED", "VOICE_STOPPED"):
            self.assertIn(t, tipos)
        detalle = [e["detail"] for e in self.b.eventos_recibidos() if e["event_type"] == "LIGHT_CHANGED"]
        self.assertEqual(detalle, ["on=true brightness=40 cause=command"])

    async def test_toda_orden_recibe_una_sola_respuesta(self):
        await self.conectar()
        ordenes = [("light.set", {"seq": 1, "on": True, "brightness": 20, "fade_ms": 0}),
                   ("light.get", {}),
                   ("audio.volume", {"seq": 2, "volume": 50}),
                   ("audio.get", {}),
                   ("audio.stop", {"seq": 3}),
                   ("light.set", {"seq": 4, "on": False, "fade_ms": 0}),
                   ("light.set", {"seq": 4, "on": True}),                      # seq repetido
                   ("audio.play", {"seq": 5, "song_id": "no-existe", "source": "local"}),
                   ("voice.stop", {"session_id": "x"})]
        for i, (tipo, campos) in enumerate(ordenes):
            await self.srv.mandar(dict({"v": 1, "type": tipo, "id": "o%d" % i}, **campos))
        await asyncio.sleep(0.3)
        for i in range(len(ordenes)):
            resp = [m for m in self.srv.recibidos if m["type"] in ("ack", "error") and m.get("ref") == "o%d" % i]
            self.assertEqual(len(resp), 1, "la orden o%d recibió %d respuestas" % (i, len(resp)))


class PruebasReconexion(Base):
    async def test_se_cae_y_vuelve_a_conectar_sola(self):
        await self.conectar()
        self.srv.cortar()
        await self.srv.esperar_hello(2)
        self.assertEqual(self.b.cuna.sesiones, 2)
        self.assertTrue(any("sesión terminada" in e for e in self.b.errores))
        self.assertEqual(self.b.esperas[0], 1)           # Primera espera del contrato.

    async def test_la_cuenta_de_esperas_vuelve_a_empezar_al_conectar(self):
        await self.conectar()
        for n in (2, 3, 4):
            self.srv.cortar()
            await self.srv.esperar_hello(n)
        self.assertEqual(self.b.esperas[:3], [1, 1, 1])  # Cada vez conectó bien, así que reinicia.

    async def test_la_luz_se_mantiene_y_se_anuncia_al_volver(self):
        await self.conectar()
        await self.srv.light_set(True, 60, fade_ms=0)
        await self.srv.esperar("light.state")
        pwm_antes = self.b.pwm.historial[-1]
        self.srv.cortar()
        await asyncio.sleep(0.003)
        self.assertEqual(self.b.pwm.historial[-1], pwm_antes)   # No se apaga ni parpadea al caerse.
        await self.srv.esperar_hello(2)
        e = await self.srv.esperar("light.state")
        self.assertEqual((e["on"], e["brightness"], e["cause"]), (True, 60, "boot"))

    async def test_eventos_de_la_desconexion_llegan_en_orden_al_volver(self):
        await self.conectar()
        self.srv.cortar()
        await asyncio.sleep(0.003)
        self.b.registro.evento("PRIMERO", "a")
        self.b.registro.evento("SEGUNDO", "b")
        await self.srv.esperar_hello(2)
        await self.b.esperar_evento("SEGUNDO")
        tipos = self.b.tipos_de_evento()
        self.assertEqual([t for t in tipos if t in ("PRIMERO", "SEGUNDO")], ["PRIMERO", "SEGUNDO"])

    async def test_mas_de_50_eventos_sin_conexion_cuentan_los_perdidos(self):
        await self.conectar()
        self.b.servidor.close()                           # El servidor deja de aceptar.
        self.srv.cortar()
        await asyncio.sleep(0.05)
        for i in range(70):
            self.b.registro.evento("RUIDO", str(i))
        self.assertEqual(self.b.registro.pendientes(), 50)
        self.b.servidor = await servir(self.srv.manejador, "127.0.0.1", self.b.puerto)
        await self.srv.esperar_hello(2, timeout=10)
        await asyncio.sleep(0.3)
        ruido = [e for e in self.b.eventos_recibidos() if e["event_type"] == "RUIDO"]
        self.assertEqual(len(ruido), 50)
        self.assertEqual(ruido[0]["dropped_before"], 20)
        self.assertEqual(ruido[0]["detail"], "20")

    async def test_cancion_del_servidor_se_apaga_sola_al_caerse(self):
        await self.conectar()
        await self.srv.audio_play("rio", "server")
        await self.srv.esperar("audio.state")
        pcm = pcm_constante(8000, N16 * 200)
        envio = asyncio.create_task(self.srv.transmitir(pcm, ritmo=4))
        await asyncio.sleep(0.3)
        self.assertEqual(self.b.audio.modo, "song")
        self.srv.cortar()
        await asyncio.wait_for(self.b.audio.esperar_fin(), 3)   # Vacía el búfer y calla.
        self.assertEqual(self.b.audio.modo, "idle")
        self.assertFalse(self.b.salida.abierta)
        envio.cancel()
        await self.srv.esperar_hello(2)
        e = await self.srv.esperar("audio.state")
        while e["mode"] != "idle":
            e = await self.srv.esperar("audio.state")
        await self.b.esperar_evento("SONG_STOPPED")

    async def test_cancion_local_sigue_sonando_aunque_se_caiga(self):
        self.b.archivos.canciones["larga"] = pcm_constante(8000, N16 * 100)
        await self.conectar()
        await self.srv.audio_play("larga", "local")
        await self.srv.esperar("audio.state")
        await asyncio.sleep(0.2)
        self.srv.cortar()
        await self.srv.esperar_hello(2)
        self.assertEqual(self.b.audio.modo, "song")           # No se cortó.
        e = await self.srv.esperar("audio.state")
        while e["mode"] != "song":
            e = await self.srv.esperar("audio.state")
        self.assertEqual(e["song_id"], "larga")
        await self.srv.audio_stop()
        await self.b.audio.esperar_fin()
        self.assertEqual(self.b.audio.modo, "idle")

    async def test_la_voz_se_cierra_y_el_mic_se_apaga_al_caerse(self):
        await self.conectar()
        await self.srv.voice_start("s-1")
        await self.srv.esperar("voice.state")
        self.assertTrue(self.b.mic.activo)
        self.srv.cortar()
        for _ in range(100):
            if not self.b.mic.activo:
                break
            await asyncio.sleep(0.01)
        self.assertFalse(self.b.mic.activo)                    # Nunca se queda escuchando sin conexión.
        self.assertIsNone(self.b.voz.sesion)
        self.assertEqual(self.b.audio.modo, "idle")
        await self.srv.esperar_hello(2)
        e = await self.srv.esperar("voice.state")
        self.assertFalse(e["active"])
        await self.b.esperar_evento("VOICE_STOPPED")


class PruebasErrores(Base):
    async def test_servidor_apagado_usa_las_esperas_del_contrato(self):
        self.b.servidor.close()
        await self.b.servidor.wait_closed()
        registro = []

        async def dormir(s):
            registro.append(s)
            if len(registro) >= 9:
                raise asyncio.CancelledError()
            await asyncio.sleep(0)
        estado = {"paso": 0}
        cuna = self.b.cuna
        cuna.estado = estado
        with self.assertRaises(asyncio.CancelledError):
            await supervisar(cuna.una_sesion, estado, dormir=dormir)
        self.assertEqual(registro, [1, 2, 4, 8, 16, 30, 30, 30, 30])

    async def test_token_malo_no_reinicia_la_cuenta(self):
        self.b.cuna._token = "MALO"
        self.b.arrancar()
        for _ in range(100):
            if len(self.b.esperas) >= 3:
                break
            await asyncio.sleep(0.02)
        self.assertEqual(self.b.esperas[:3], [1, 2, 4])
        self.assertEqual(self.b.cuna.sesiones, 0)
        self.assertTrue(any("UNAUTHORIZED" in e for e in self.b.errores))
        self.b.cuna._token = TOKEN                            # Se arregla el token.
        await self.srv.esperar_hello(1, timeout=15)
        self.assertEqual(self.b.cuna.estado["paso"], 0)

    async def test_servidor_que_calla_hace_que_la_cuna_reconecte(self):
        with ajustes(TIMEOUT_SIN_MENSAJES_S=0.15, LATIDO_S=30):
            await self.conectar()
            await self.srv.esperar_hello(2, timeout=3)        # Pasó el silencio y reconectó.
            self.assertTrue(any("Timeout" in e for e in self.b.errores))

    async def test_mensaje_gigante_del_servidor_corta_la_sesion_sin_romper_nada(self):
        await self.conectar()
        await self.srv.light_set(True, 30, fade_ms=0)
        await self.srv.esperar("light.state")
        await self.srv.conexion.send(b"x" * (config.WS_MAX_PAYLOAD + 10))
        await self.srv.esperar_hello(2, timeout=5)
        self.assertTrue(any("supera el máximo" in e for e in self.b.errores))
        self.assertEqual(self.b.luz.estado(), (True, 30))     # La luz ni se enteró.

    async def test_basura_cruda_del_servidor(self):
        await self.conectar()
        await self.srv.conexion.escribir_crudo(b"\x01\x02\x03\x04\x05\x06")   # Sin formato de trama.
        await asyncio.sleep(0.3)
        # La cuna debe seguir viva y coherente: reconectó o ignoró, pero no se colgó.
        self.assertFalse(self.b.supervisor.done())

    async def test_trama_con_mascara_del_servidor_es_rechazada(self):
        await self.conectar()
        await self.srv.conexion.escribir_crudo(b"\x81\x81\x00\x00\x00\x00A")     # El servidor no debe enmascarar.
        await self.srv.esperar_hello(2, timeout=5)
        self.assertTrue(any("enmascarar" in e for e in self.b.errores))

    async def test_servidor_que_nunca_manda_welcome(self):
        await self.b.cerrar()

        async def mudo(conn):
            await conn.recv()
            await asyncio.sleep(5)
        self.b.servidor = await servir(mudo, "127.0.0.1", 0)
        self.b.supervisor = None
        self.b.cuna._puerto = self.b.servidor.sockets[0].getsockname()[1]
        with ajustes(TIMEOUT_WELCOME_S=0.1):
            with self.assertRaises(asyncio.TimeoutError):
                await asyncio.wait_for(self.b.cuna.una_sesion(), 2)
        self.assertIsNone(self.b.enlace.cliente)                # Limpió su conexión.
        self.assertEqual(self.b.cuna.sesiones, 0)

    async def test_mensajes_raros_no_tumban_la_sesion(self):
        await self.conectar()
        c = self.srv.conexion
        await c.send("no es json")
        await c.send('{"v":1}')
        await c.send('{"v":1,"type":"tipo.inventado","id":"z"}')
        await c.send("[1,2,3]")
        await c.send(b"\x01")                                    # Binario corto.
        await c.send(b"\x09\x03" + bytes(10))                    # Versión de trama equivocada.
        await asyncio.sleep(0.2)
        codigos = [m["code"] for m in self.srv.recibidos if m["type"] == "error"]
        self.assertEqual(codigos.count("BAD_JSON"), 3)           # Texto roto, sin type y arreglo.
        await self.srv.light_set(True, 50, fade_ms=0)            # Y todo sigue funcionando.
        e = await self.srv.esperar("light.state")
        self.assertEqual(e["brightness"], 50)


if __name__ == "__main__":
    unittest.main()
