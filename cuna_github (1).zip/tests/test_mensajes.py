import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from protocolo import mensajes as m


class PruebasMensajes(unittest.TestCase):
    def test_json_roto(self):
        msg, falla = m.parsear("{no es json")
        self.assertIsNone(msg)
        self.assertEqual(falla[0], "BAD_JSON")

    def test_sin_type(self):
        self.assertEqual(m.parsear('{"v":1}')[1][0], "BAD_JSON")

    def test_version_distinta(self):
        self.assertEqual(m.parsear('{"v":2,"type":"x"}')[1][0], "BAD_VERSION")

    def test_mensaje_valido(self):
        msg, falla = m.parsear('{"v":1,"type":"light.get","id":"a"}')
        self.assertIsNone(falla)
        self.assertEqual(msg["id"], "a")

    def test_bool_no_es_entero(self):
        self.assertFalse(m.es_entero(True))
        self.assertTrue(m.es_entero(5))

    def test_ack_ignored_solo_si_se_pide(self):
        self.assertNotIn("ignored", m.ack("x"))
        self.assertEqual(m.ack("x", True, "old_seq")["ignored"], "old_seq")

    def test_formas_del_contrato(self):
        e = m.error("r", "INVALID_RANGE", "d")
        self.assertEqual(set(e), {"v", "type", "ref", "code", "detail"})
        s = m.light_state(1, True, 40, "command", 5)
        self.assertEqual(set(s), {"v", "type", "seq", "on", "brightness", "cause", "ts"})


if __name__ == "__main__":
    unittest.main()
