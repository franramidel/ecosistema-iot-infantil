import ast
import os
import tempfile
import unittest

from tools import preparar_pico as pp

# Paquetes del proyecto que NO deben estar en la Pico.
SOLO_PC = {"servidor", "simulador", "tests", "tools"}


def _modulos_importados(ruta):
    with open(ruta, encoding="utf-8") as f:
        arbol = ast.parse(f.read())
    for n in ast.walk(arbol):
        if isinstance(n, ast.Import):
            for a in n.names:
                yield a.name
        elif isinstance(n, ast.ImportFrom) and n.module and n.level == 0:
            yield n.module


class PruebasPreparar(unittest.TestCase):
    def setUp(self):
        self.lista = pp.archivos_pico()

    def test_incluye_lo_esencial(self):
        for rel in ("main.py", "config.py", "secrets_example.py",
                    "hal/audio_tonos.py", "servicios/sesion.py", "assets/nana-1.pcm"):
            self.assertIn(rel, self.lista)

    def test_no_incluye_secretos_ni_cosas_de_pc(self):
        for rel in self.lista:
            self.assertNotEqual(rel, "secrets.py")
            self.assertNotIn(rel.split("/")[0], SOLO_PC)
            self.assertNotIn("__pycache__", rel)

    def test_nada_de_lo_que_va_a_la_pico_importa_codigo_solo_de_pc(self):
        for rel in self.lista:
            if rel.endswith(".py"):
                for mod in _modulos_importados(os.path.join(pp.RAIZ, rel)):
                    self.assertNotIn(mod.split(".")[0], SOLO_PC, "%s importa %s" % (rel, mod))

    def test_cada_modulo_del_proyecto_que_se_importa_viene_en_la_lista(self):
        locales = {r[:-3].replace("/", ".") for r in self.lista if r.endswith(".py")}
        # Los nombres de código del proyecto se toman del disco, no de la lista que se prueba.
        raices = {d for d in os.listdir(pp.RAIZ)
                  if os.path.isdir(os.path.join(pp.RAIZ, d)) and d not in ("assets", "docs", "__pycache__")}
        raices |= {f[:-3] for f in os.listdir(pp.RAIZ) if f.endswith(".py")}
        raices -= SOLO_PC
        for rel in self.lista:
            if not rel.endswith(".py"):
                continue
            for mod in _modulos_importados(os.path.join(pp.RAIZ, rel)):
                if mod.split(".")[0] in raices and mod.split(".")[0] != "secrets":
                    ok = mod in locales or (mod + ".__init__") in locales
                    self.assertTrue(ok, "%s importa %s y no está en la lista" % (rel, mod))

    def test_preparar_copia_los_archivos(self):
        with tempfile.TemporaryDirectory() as d:
            destino = os.path.join(d, "salida")
            lista, total = pp.preparar(destino)
            self.assertEqual(lista, self.lista)
            self.assertGreater(total, 100000)
            for rel in lista:
                self.assertTrue(os.path.isfile(os.path.join(destino, rel)))
            self.assertFalse(os.path.exists(os.path.join(destino, "secrets.py")))


if __name__ == "__main__":
    unittest.main()
