import asyncio
import os
import struct
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config
from servicios.gestor_audio import GestorAudio
from servicios.volumen import ganancia_para_volumen
from servicios.voz import ServicioVoz
from tests.utiles import ArchivosFalsos, MicFalso, SalidaFalsa, pcm_constante, trama

N16 = config.AUDIO_TRAMA_BYTES // 2


class Base(unittest.IsolatedAsyncioTestCase):
    def armar(self, canciones=None):
        self.salida = SalidaFalsa(retardo=0.001)
        self.enviados = []
        self.binarios = []
        self.archivos = ArchivosFalsos(canciones or {})

        async def enviar(msg):
            self.enviados.append(msg)

        async def enviar_bin(datos):
            self.binarios.append(bytes(datos))
        self.enviar_bin = enviar_bin
        self.g = GestorAudio(self.salida, enviar, lambda: 5000,
                             self.archivos.abrir, self.archivos.listar)
        self.g.volumen = 100
        self.mic = MicFalso()
        self.v = ServicioVoz(self.g, self.mic, enviar, enviar_bin, lambda: 7000)

    def de_tipo(self, tipo):
        return [x for x in self.enviados if x["type"] == tipo]

    def start(self, sid="s1", turno=None):
        msg = {"v": 1, "type": "voice.start", "id": "i1", "session_id": sid}
        if turno:
            msg["turn"] = turno
        return self.v.manejar(msg)

    def turno(self, turno, sid="s1"):
        return self.v.manejar({"v": 1, "type": "voice.turn", "id": "i2", "session_id": sid, "turn": turno})

    def stop(self, sid="s1"):
        return self.v.manejar({"v": 1, "type": "voice.stop", "id": "i3", "session_id": sid})

    async def limpiar(self):
        await self.v.terminar(False)


class PruebasSesion(Base):
    async def test_el_microfono_esta_apagado_hasta_que_se_pide(self):
        self.armar()
        self.assertFalse(self.mic.activo)
        self.assertEqual(self.mic.inicios, 0)
        await self.g.manejar({"v": 1, "type": "audio.get", "id": "g"})
        self.assertEqual(self.mic.inicios, 0)

    async def test_start_enciende_el_mic_y_reporta(self):
        self.armar()
        await self.start()
        self.assertTrue(self.de_tipo("ack")[0]["ok"])
        e = self.de_tipo("voice.state")[-1]
        self.assertEqual((e["session_id"], e["active"], e["turn"], e["mic_active"], e["mic_hz_real"]),
                         ("s1", True, "cradle", True, 7990))
        self.assertEqual(self.g.modo, "voice")
        self.assertEqual(self.mic.inicios, 1)
        await self.limpiar()

    async def test_el_mic_manda_tramas_tipo_1_con_secuencia(self):
        self.armar()
        await self.start()
        for i in range(3):
            self.mic.poner(bytes([i]) * 320)
        await asyncio.sleep(0.05)
        self.assertEqual(len(self.binarios), 3)
        for i, b in enumerate(self.binarios):
            ver, tipo, seq, ts = struct.unpack("!BBHI", b[:8])
            self.assertEqual((ver, tipo, seq, ts), (1, 1, i, 7000))
            self.assertEqual(b[8:], bytes([i]) * 320)
        await self.limpiar()

    async def test_la_secuencia_da_la_vuelta_a_65535(self):
        self.armar()
        await self.start()
        self.v._seq_tx = 65535
        self.mic.poner(b"\0" * 320)
        self.mic.poner(b"\0" * 320)
        await asyncio.sleep(0.05)
        seqs = [struct.unpack("!H", b[2:4])[0] for b in self.binarios]
        self.assertEqual(seqs, [65535, 0])
        await self.limpiar()

    async def test_start_sin_turn_empieza_en_cradle_y_con_turn_app_no_enciende_el_mic(self):
        self.armar()
        await self.start(turno="app")
        self.assertEqual(self.v.turno, "app")
        self.assertFalse(self.mic.activo)
        await self.limpiar()

    async def test_la_voz_corta_la_nana_y_no_vuelve(self):
        self.armar({"n": pcm_constante(8000, N16 * 500)})
        await self.g.manejar({"v": 1, "type": "audio.play", "id": "p", "seq": 1, "song_id": "n", "source": "local"})
        await asyncio.sleep(0.1)
        self.assertEqual(self.g.modo, "song")
        await self.start()
        self.assertEqual(self.g.modo, "voice")
        self.assertEqual(len(self.de_tipo("audio.ended")), 0)    # Cortar no es terminar.
        await self.stop()
        self.assertEqual(self.g.modo, "idle")
        escrituras = len(self.salida.escrituras)
        await asyncio.sleep(0.1)
        self.assertEqual(len(self.salida.escrituras), escrituras)   # La nana no sigue.
        self.assertIsNone(self.g.song_id)

    async def test_play_durante_voz_da_busy(self):
        self.armar({"n": b"\0" * 640})
        await self.start()
        await self.g.manejar({"v": 1, "type": "audio.play", "id": "p", "seq": 1, "song_id": "n", "source": "local"})
        self.assertEqual(self.de_tipo("error")[-1]["code"], "BUSY")
        await self.limpiar()

    async def test_start_repetido_y_otra_sesion(self):
        self.armar()
        await self.start("s1")
        await self.start("s1")
        self.assertEqual(self.de_tipo("ack")[-1].get("ignored"), "already_active")
        await self.start("s2")
        self.assertEqual(self.de_tipo("error")[-1]["code"], "BUSY")
        self.assertEqual(self.mic.inicios, 1)
        await self.limpiar()

    async def test_stop_apaga_todo_y_es_repetible(self):
        self.armar()
        await self.start()
        await self.stop()
        self.assertFalse(self.mic.activo)
        self.assertEqual(self.v.sesion, None)
        self.assertEqual(self.g.modo, "idle")
        self.assertFalse(self.salida.abierta)
        e = self.de_tipo("voice.state")[-1]
        self.assertEqual((e["active"], e["mic_active"], e["turn"]), (False, False, None))
        await self.stop()                                   # No falla ni enciende nada.
        self.assertEqual(self.mic.inicios, 1)
        self.mic.poner(b"\0" * 320)
        await asyncio.sleep(0.03)
        self.assertEqual(self.binarios, [])

    async def test_validaciones(self):
        self.armar()
        await self.v.manejar({"v": 1, "type": "voice.start", "id": "a", "session_id": ""})
        await self.v.manejar({"v": 1, "type": "voice.start", "id": "b", "session_id": 5})
        await self.v.manejar({"v": 1, "type": "voice.start", "id": "c", "session_id": "s", "turn": "los dos"})
        await self.v.manejar({"v": 1, "type": "voice.turn", "id": "d", "session_id": "s"})
        self.assertEqual([e["code"] for e in self.de_tipo("error")],
                         ["BAD_JSON", "BAD_JSON", "INVALID_RANGE", "BAD_JSON"])
        self.assertEqual(self.mic.inicios, 0)

    async def test_sesion_equivocada(self):
        self.armar()
        await self.turno("app", sid="x")
        self.assertEqual(self.de_tipo("error")[-1]["code"], "NO_SESSION")
        await self.start("s1")
        await self.turno("app", sid="otra")
        await self.stop("otra")
        self.assertEqual([e["code"] for e in self.de_tipo("error")][-2:], ["NO_SESSION", "NO_SESSION"])
        self.assertTrue(self.mic.activo)                    # La sesión real sigue.
        await self.limpiar()

    async def test_mic_roto_da_error_y_deja_todo_en_reposo(self):
        self.armar()
        self.mic.falla_al_iniciar = True
        await self.start()
        self.assertEqual(self.de_tipo("error")[-1]["code"], "MIC_UNAVAILABLE")
        self.assertIsNone(self.v.sesion)
        self.assertEqual(self.g.modo, "idle")
        self.assertFalse(self.mic.activo)

    async def test_conexion_perdida_apaga_el_mic_sin_avisar(self):
        self.armar()
        await self.start()
        antes = len(self.enviados)
        await self.v.terminar(False)
        self.assertFalse(self.mic.activo)
        self.assertEqual(self.g.modo, "idle")
        self.assertEqual(self.v.sesion, None)
        self.assertEqual([e for e in self.enviados[antes:] if e["type"] == "voice.state"], [])

    async def test_si_falla_el_envio_el_mic_se_apaga(self):
        self.armar()

        async def roto(_d):
            raise ConnectionError("sin conexión")
        self.v._enviar_bin = roto
        await self.start()
        self.mic.poner(b"\0" * 320)
        await asyncio.sleep(0.05)
        self.assertFalse(self.mic.activo)
        await self.limpiar()

    async def test_informe_periodico(self):
        self.armar()
        viejo = config.VOZ_INFORME_S
        config.VOZ_INFORME_S = 0.03
        try:
            await self.start()
            n = len(self.de_tipo("voice.state"))
            await asyncio.sleep(0.12)
            self.assertGreaterEqual(len(self.de_tipo("voice.state")) - n, 2)
        finally:
            config.VOZ_INFORME_S = viejo
            await self.limpiar()


class PruebasTurnos(Base):
    async def test_turno_app_apaga_el_mic_y_suena_la_voz_de_la_app(self):
        self.armar()
        await self.start()
        await self.turno("app")
        await asyncio.sleep(0.02)
        self.assertFalse(self.mic.activo)
        self.assertEqual(self.de_tipo("voice.state")[-1]["turn"], "app")
        self.assertFalse(self.de_tipo("voice.state")[-1]["mic_active"])
        for i in range(8):
            self.v.recibir_trama(trama(i, pcm_constante(10000, N16), tipo=2))
        await asyncio.sleep(0.1)
        sonidos = [t for t in self.salida.escrituras if any(t)]
        self.assertGreaterEqual(len(sonidos), 3)
        pico = max(abs(x) for x in struct.unpack("<%dh" % N16, sonidos[0]))
        self.assertEqual(pico, 10000 * ganancia_para_volumen(100) // 256)   # Volumen entra directo.
        await self.limpiar()

    async def test_tramas_de_la_app_fuera_de_turno_se_descartan_y_se_cuentan(self):
        self.armar()
        await self.start()                                   # Turno de la cuna.
        for i in range(4):
            self.v.recibir_trama(trama(i, pcm_constante(1, N16), tipo=2))
        self.assertEqual(self.v.descartadas, 4)
        self.assertEqual(self.g._cola_voz, [])
        self.assertEqual(self.v.estado()["dropped_frames"], 4)
        await self.limpiar()

    async def test_tramas_sin_sesion_se_descartan(self):
        self.armar()
        self.v.recibir_trama(trama(0, pcm_constante(1, N16), tipo=2))
        self.assertEqual(self.v.descartadas, 1)

    async def test_tramas_invalidas_se_descartan_o_ignoran(self):
        self.armar()
        await self.start(turno="app")
        self.v.recibir_trama(b"\x01\x02")                                       # Corta: se ignora.
        self.v.recibir_trama(struct.pack("!BBHI", 2, 2, 0, 0) + b"\0" * 640)    # Versión 2: se ignora.
        self.v.recibir_trama(trama(0, b"\0" * 640, tipo=1))                     # No es tipo 2: se ignora.
        self.assertEqual(self.v.descartadas, 0)
        self.v.recibir_trama(trama(0, b"\0" * 641, tipo=2))                     # Largo impar.
        self.v.recibir_trama(trama(0, b"\0" * 2000, tipo=2))                    # Demasiado grande.
        self.v.recibir_trama(trama(0, b"", tipo=2))                             # Vacía.
        self.assertEqual(self.v.descartadas, 3)
        await self.limpiar()

    async def test_cola_llena_descarta(self):
        self.armar()
        await self.start(turno="app")
        self.g._cola_voz = [bytearray(640)] * config.VOZ_COLA_MAX
        self.v.recibir_trama(trama(0, pcm_constante(1, N16), tipo=2))
        self.assertEqual(self.v.descartadas, 1)
        await self.limpiar()

    async def test_volver_a_la_cuna_vacia_lo_pendiente_y_espera_antes_del_mic(self):
        self.armar()
        await self.start()
        await self.turno("app")
        await asyncio.sleep(0.02)
        for i in range(10):
            self.v.recibir_trama(trama(i, pcm_constante(10000, N16), tipo=2))
        await self.turno("cradle")
        await asyncio.sleep(0.05)
        self.assertEqual(self.g._cola_voz, [])               # Se vació el búfer de reproducción.
        self.assertFalse(self.salida.abierta)                # Y el parlante quedó en silencio.
        self.assertFalse(self.mic.activo)                    # Aún en la pausa de guarda.
        self.assertEqual(self.v.turno, "cradle")
        await asyncio.sleep(config.VOZ_GUARDA_MS / 1000)
        self.assertTrue(self.mic.activo)
        self.assertEqual(self.mic.inicios, 2)
        await self.limpiar()

    async def test_voz_de_la_app_que_llega_en_la_pausa_se_descarta(self):
        self.armar()
        await self.start()
        await self.turno("app")
        await asyncio.sleep(0.02)
        await self.turno("cradle")
        await asyncio.sleep(0.02)
        antes = self.v.descartadas
        self.v.recibir_trama(trama(0, pcm_constante(1, N16), tipo=2))
        self.assertEqual(self.v.descartadas, antes + 1)
        await self.limpiar()

    async def test_cambios_de_turno_seguidos_quedan_en_el_ultimo(self):
        self.armar()
        await self.start()
        await self.turno("app")
        await self.turno("cradle")
        await self.turno("app")
        await asyncio.sleep(0.4)
        self.assertEqual(self.v.turno, "app")
        self.assertFalse(self.mic.activo)
        self.assertEqual(self.mic.inicios, 1)                # Nunca se reabrió por el cambio cancelado.
        await self.limpiar()

    async def test_underrun_de_voz_se_cuenta_y_se_mete_silencio(self):
        self.armar()
        await self.start(turno="app")
        for i in range(config.VOZ_PREBUFFER + 1):
            self.v.recibir_trama(trama(i, pcm_constante(10000, N16), tipo=2))
        await asyncio.sleep(0.1)
        self.assertGreaterEqual(self.g.underruns, 1)
        self.assertTrue(any(not any(t) for t in self.salida.escrituras))
        await self.limpiar()

    async def test_volumen_cero_en_voz_deja_silencio(self):
        self.armar()
        self.g.volumen = 0
        await self.start(turno="app")
        for i in range(6):
            self.v.recibir_trama(trama(i, pcm_constante(10000, N16), tipo=2))
        await asyncio.sleep(0.08)
        self.assertEqual(max(abs(x) for x in self.salida.muestras()), 0)
        await self.limpiar()


if __name__ == "__main__":
    unittest.main()
