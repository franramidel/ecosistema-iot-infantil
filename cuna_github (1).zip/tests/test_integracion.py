# Prueba con simulador. Usa el cliente WebSocket real de la cuna contra un servidor
# hecho con la biblioteca estándar. Esto valida el protocolo, NO el hardware.

import asyncio
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from simulador.ws_servidor import servir

from hal.luz import Luz, duty_para_brillo
from servicios.cuna_app import CunaApp
from servicios.reloj import Reloj
from servicios.ws_cliente import ClienteWS, ErrorWS, armar_trama
from simulador.servidor_sim import ServidorSim, RUTA
from tests.test_luz import PWMFalso

TOKEN = "TOKEN_DE_PRUEBA"


class PruebasIntegracion(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.srv = ServidorSim(TOKEN)
        self.servidor = await servir(self.srv.manejador, "127.0.0.1", 0)
        self.puerto = self.servidor.sockets[0].getsockname()[1]
        self.pwm = PWMFalso()
        self.luz = Luz(self.pwm, paso_ms=5)
        self.reloj = Reloj()

    async def asyncTearDown(self):
        # Todo lo que mandó la cuna debe cumplir el contrato.
        self.assertEqual(self.srv.problemas, [])
        self.servidor.close()
        await self.servidor.wait_closed()

    async def conectar(self, token=TOKEN, ruta=RUTA):
        cliente = ClienteWS("127.0.0.1", self.puerto, ruta)
        await cliente.conectar()
        app = CunaApp(cliente, self.luz, self.reloj, "3f2a9c1e-5b7d-4e8a-9c21-7d4e5f6a8b90", token)
        return cliente, app

    async def sesion(self):
        cliente, app = await self.conectar()
        await app.saludar()
        escucha = asyncio.create_task(self.bucle(cliente, app))
        return cliente, app, escucha

    async def bucle(self, cliente, app):
        try:
            while True:
                op, datos = await cliente.recibir()
                await app.despachar(op, datos)
        except (ErrorWS, asyncio.IncompleteReadError, ConnectionError):
            pass

    async def test_hello_welcome_y_estado_inicial(self):
        cliente, app, escucha = await self.sesion()
        self.assertEqual(self.srv.hello["device_id"], "3f2a9c1e-5b7d-4e8a-9c21-7d4e5f6a8b90")
        self.assertTrue(self.reloj.sincronizado)
        estado = await self.srv.esperar("light.state")
        self.assertEqual((estado["on"], estado["brightness"], estado["cause"]), (False, 0, "boot"))
        escucha.cancel()
        await cliente.cerrar()

    async def test_token_malo_es_rechazado(self):
        cliente, app = await self.conectar(token="OTRO")
        with self.assertRaises(ValueError):
            await app.saludar()
        await cliente.cerrar()

    async def test_ruta_mala_no_conecta(self):
        cliente = ClienteWS("127.0.0.1", self.puerto, "/otra")
        with self.assertRaises((ErrorWS, asyncio.IncompleteReadError, ConnectionError)):
            await cliente.conectar()
            await cliente.recibir()

    async def test_light_set_da_ack_cambia_pwm_y_reporta_estado(self):
        cliente, app, escucha = await self.sesion()
        await self.srv.esperar("light.state")  # boot
        await self.srv.light_set(True, 40, fade_ms=50)
        ack = await self.srv.esperar("ack")
        self.assertTrue(ack["ok"])
        self.assertEqual(ack["ref"], "r-1")
        estado = await self.srv.esperar("light.state")
        self.assertEqual((estado["seq"], estado["on"], estado["brightness"], estado["cause"]),
                         (1, True, 40, "command"))
        self.assertEqual(self.pwm.historial[-1], duty_para_brillo(40))
        escucha.cancel()
        await cliente.cerrar()

    async def test_apagar(self):
        cliente, app, escucha = await self.sesion()
        await self.srv.esperar("light.state")  # boot
        await self.srv.light_set(True, 60, fade_ms=0)
        await self.srv.esperar("light.state")
        await self.srv.light_set(False, fade_ms=0)
        e = await self.srv.esperar("light.state")
        self.assertEqual((e["on"], e["brightness"]), (False, 0))
        self.assertEqual(self.pwm.historial[-1], 0)
        escucha.cancel()
        await cliente.cerrar()

    async def test_brillo_fuera_de_rango_da_error_y_no_cambia_la_luz(self):
        cliente, app, escucha = await self.sesion()
        await self.srv.esperar("light.state")
        antes = list(self.pwm.historial)
        await self.srv.light_set(True, 150, validar_salida=False)
        err = await self.srv.esperar("error")
        self.assertEqual(err["code"], "INVALID_RANGE")
        self.assertEqual(err["ref"], "r-1")
        self.assertEqual(self.pwm.historial, antes)
        # Una orden mala no gasta el seq. La siguiente con el mismo seq sí se aplica.
        await self.srv.light_set(True, 20, fade_ms=0, seq=1)
        e = await self.srv.esperar("light.state")
        self.assertEqual(e["brightness"], 20)
        escucha.cancel()
        await cliente.cerrar()

    async def test_tipos_incorrectos(self):
        cliente, app, escucha = await self.sesion()
        await self.srv.esperar("light.state")
        await self.srv.mandar({"v": 1, "type": "light.set", "id": "x", "seq": 1, "on": "si"}, validar_salida=False)
        self.assertEqual((await self.srv.esperar("error"))["code"], "BAD_JSON")
        await self.srv.mandar({"v": 1, "type": "light.set", "id": "y", "seq": 1, "on": True, "brightness": True}, validar_salida=False)
        self.assertEqual((await self.srv.esperar("error"))["code"], "BAD_JSON")
        await self.srv.mandar({"v": 1, "type": "light.set", "id": "z", "seq": 1, "on": True, "fade_ms": 99999}, validar_salida=False)
        self.assertEqual((await self.srv.esperar("error"))["code"], "INVALID_RANGE")
        escucha.cancel()
        await cliente.cerrar()

    async def test_seq_viejo_se_ignora_y_se_reporta_estado(self):
        cliente, app, escucha = await self.sesion()
        await self.srv.esperar("light.state")
        await self.srv.light_set(True, 50, fade_ms=0, seq=10)
        await self.srv.esperar("light.state")
        await self.srv.light_set(False, fade_ms=0, seq=10)
        ack = await self.srv.esperar("ack")
        self.assertEqual(ack.get("ignored"), "old_seq")
        e = await self.srv.esperar("light.state")
        self.assertEqual((e["on"], e["brightness"]), (True, 50))
        self.assertEqual(self.pwm.historial[-1], duty_para_brillo(50))
        escucha.cancel()
        await cliente.cerrar()

    async def test_orden_nueva_corta_el_fade_anterior(self):
        cliente, app, escucha = await self.sesion()
        await self.srv.esperar("light.state")
        await self.srv.light_set(True, 100, fade_ms=2000)
        await asyncio.sleep(0.1)
        await self.srv.light_set(False, fade_ms=0)
        e = await self.srv.esperar("light.state")
        self.assertEqual(e["seq"], 2)
        await asyncio.sleep(0.2)
        self.assertEqual(self.pwm.historial[-1], 0)
        escucha.cancel()
        await cliente.cerrar()

    async def test_light_get(self):
        cliente, app, escucha = await self.sesion()
        await self.srv.esperar("light.state")
        await self.srv.mandar({"v": 1, "type": "light.get", "id": "g1"})
        self.assertEqual((await self.srv.esperar("ack"))["ref"], "g1")
        self.assertEqual((await self.srv.esperar("light.state"))["cause"], "command")
        escucha.cancel()
        await cliente.cerrar()

    async def test_audio_y_voz_responden_unsupported(self):
        cliente, app, escucha = await self.sesion()
        await self.srv.esperar("light.state")
        await self.srv.mandar({"v": 1, "type": "audio.play", "id": "a1", "seq": 1,
                               "song_id": "nana-1", "source": "server"})
        err = await self.srv.esperar("error")
        self.assertEqual((err["code"], err["ref"]), ("UNSUPPORTED", "a1"))
        escucha.cancel()
        await cliente.cerrar()

    async def test_json_roto_y_version_mala(self):
        cliente, app, escucha = await self.sesion()
        await self.srv.esperar("light.state")
        await self.srv.conexion.send("{roto")
        self.assertEqual((await self.srv.esperar("error"))["code"], "BAD_JSON")
        await self.srv.mandar({"v": 9, "type": "light.get", "id": "q"}, validar_salida=False)
        self.assertEqual((await self.srv.esperar("error"))["code"], "BAD_VERSION")
        escucha.cancel()
        await cliente.cerrar()

    async def test_status(self):
        cliente, app, escucha = await self.sesion()
        await self.srv.esperar("light.state")
        await app.enviar_status(None, 123456)
        s = await self.srv.esperar("status")
        self.assertEqual(s["free_ram"], 123456)
        self.assertTrue(s["synced"])
        escucha.cancel()
        await cliente.cerrar()

    async def test_trama_se_enmascara_y_servidor_acepta_mensaje_largo(self):
        # Un texto de más de 125 bytes usa el largo extendido de 16 bits.
        trama = armar_trama(0x1, b"a" * 300)
        self.assertEqual(trama[1] & 0x80, 0x80)
        self.assertEqual(trama[1] & 0x7F, 126)
        cliente, app, escucha = await self.sesion()
        await self.srv.esperar("light.state")
        await cliente.enviar_texto(
            '{"v":1,"type":"event","event_id":"t-1","event_type":"PRUEBA","severity":"info",'
            '"detail":"%s","ts":1,"uptime_ms":1,"synced":true,"dropped_before":0}' % ("z" * 300))
        e = await self.srv.esperar("event")
        self.assertEqual(len(e["detail"]), 300)
        escucha.cancel()
        await cliente.cerrar()

    async def test_servidor_que_cierra_hace_fallar_recibir(self):
        cliente, app = await self.conectar()
        await app.saludar()
        await self.srv.conexion.close()
        with self.assertRaises((ErrorWS, asyncio.IncompleteReadError, ConnectionError)):
            await cliente.recibir()
        # La luz conserva su estado aunque la conexión caiga.
        self.assertEqual(self.luz.estado(), (False, 0))


if __name__ == "__main__":
    unittest.main()
