# El corredor de escenarios contra la cuna de software. VALIDADO SOLO CON SIMULADOR.
import os, sys, unittest, asyncio
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from simulador.escenarios import Corrida
from tests.banco import Banco, ajustes


class PruebasEscenarios(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.b = await Banco().abrir()
        self.b.archivos.canciones["nana-1"] = bytes(640 * 200)
        self.alimentador = None

    async def asyncTearDown(self):
        if self.alimentador:
            self.alimentador.cancel()
        await self.b.cerrar()

    async def correr(self, con_corte):
        async def alimentar():
            while True:
                self.b.mic.poner(b"\x10\x00" * 160)
                await asyncio.sleep(0.02)
        self.alimentador = asyncio.create_task(alimentar())
        self.b.arrancar()
        await self.b.srv.esperar_hello(1)
        await asyncio.sleep(0.3)
        salida = []
        c = Corrida(self.b.srv, imprimir=salida.append, con_corte=con_corte)
        res = await asyncio.wait_for(c.correr(), 60)
        return c, res, salida

    async def test_completo_pasa_todo(self):
        c, res, salida = await self.correr(False)
        fallos = [r for r in res if not r[1]]
        self.assertEqual(fallos, [], "\n".join(salida))
        self.assertIn("SERVIDOR SIMULADO", c.resumen())
        self.assertIn("persona debe confirmar", c.resumen())

    async def test_con_corte_pasa_todo(self):
        with ajustes():
            c, res, salida = await self.correr(True)
        self.assertEqual([r for r in res if not r[1]], [], "\n".join(salida))

    async def test_detecta_una_cuna_rota(self):
        self.b.luz.ir_a_original = self.b.luz.ir_a

        async def mala(*a, **k):
            return None
        self.b.luz.ir_a = mala                                    # La luz ya no obedece.
        c, res, _ = await self.correr(False)
        self.assertTrue(any(not ok for n, ok, _ in res if "luz" in n))


if __name__ == "__main__":
    unittest.main()
