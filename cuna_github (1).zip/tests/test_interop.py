# Compatibilidad con una implementación ajena. Usa la librería websockets, que NO es
# parte del proyecto. Se salta sola si no está instalada. Sirve para comprobar que el
# cliente de la cuna y el servidor del simulador cumplen el protocolo real y no solo
# se entienden entre ellos.

import asyncio
import json
import os
import struct
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

try:
    import websockets
except ImportError:
    websockets = None

from servicios.ws_cliente import ClienteWS, ErrorWS
from simulador.ws_servidor import servir


@unittest.skipIf(websockets is None, "falta la librería websockets")
class CompatibilidadCliente(unittest.IsolatedAsyncioTestCase):
    """El cliente de la cuna contra un servidor hecho por otros."""

    async def asyncSetUp(self):
        self.recibido = []

        async def manejador(ws):
            async for m in ws:
                self.recibido.append(m)
                if isinstance(m, str):
                    await ws.send("eco:" + m)
                else:
                    await ws.send(b"\x01" + m)
        self.servidor = await websockets.serve(manejador, "127.0.0.1", 0)
        self.puerto = self.servidor.sockets[0].getsockname()[1]

    async def asyncTearDown(self):
        self.servidor.close()
        await self.servidor.wait_closed()

    async def test_texto_y_binario_de_ida_y_vuelta(self):
        c = ClienteWS("127.0.0.1", self.puerto, "/x")
        await c.conectar()
        await c.enviar_texto("hola")
        self.assertEqual(await c.recibir(), (1, b"eco:hola"))
        await c.enviar_binario(b"\x00\x01\x02")
        self.assertEqual(await c.recibir(), (2, b"\x01\x00\x01\x02"))
        await c.cerrar()

    async def test_mensajes_de_todos_los_tamanos(self):
        c = ClienteWS("127.0.0.1", self.puerto, "/x", max_payload=70000)
        await c.conectar()
        for n in (0, 1, 125, 126, 127, 640, 1300, 4000, 60000):
            await c.enviar_binario(bytes(range(256)) * (n // 256) + bytes(n % 256))
            op, datos = await c.recibir()
            self.assertEqual((op, len(datos)), (2, n + 1))
        await c.cerrar()

    async def test_el_servidor_cierra_y_el_cliente_se_entera(self):
        c = ClienteWS("127.0.0.1", self.puerto, "/x")
        await c.conectar()
        for ws in list(self.servidor.connections):
            await ws.close()
        with self.assertRaises((ErrorWS, asyncio.IncompleteReadError, ConnectionError)):
            await c.recibir()
        self.assertFalse(c.abierto)


@unittest.skipIf(websockets is None, "falta la librería websockets")
class CompatibilidadServidor(unittest.IsolatedAsyncioTestCase):
    """El servidor del simulador contra un cliente hecho por otros."""

    async def asyncSetUp(self):
        self.recibido = []

        async def manejador(conn):
            self.ruta = conn.request.path
            async for m in conn:
                self.recibido.append(m)
                await conn.send(m)
        self.servidor = await servir(manejador, "127.0.0.1", 0)
        self.puerto = self.servidor.sockets[0].getsockname()[1]

    async def asyncTearDown(self):
        self.servidor.close()
        await self.servidor.wait_closed()

    async def test_eco_de_texto_y_binario(self):
        async with websockets.connect("ws://127.0.0.1:%d/ws/cuna" % self.puerto) as ws:
            await ws.send("hola ñ")
            self.assertEqual(await ws.recv(), "hola ñ")
            await ws.send(b"\x00\xff")
            self.assertEqual(await ws.recv(), b"\x00\xff")
        self.assertEqual(self.ruta, "/ws/cuna")

    async def test_mensaje_grande_y_fragmentado(self):
        async with websockets.connect("ws://127.0.0.1:%d/" % self.puerto, max_size=None) as ws:
            grande = b"a" * 60000
            await ws.send(grande)
            self.assertEqual(await ws.recv(), grande)
            # Mensaje en tres fragmentos.
            await ws.send(iter([b"uno-", b"dos-", b"tres"]))
            self.assertEqual(await ws.recv(), b"uno-dos-tres")

    async def test_ping_se_responde(self):
        async with websockets.connect("ws://127.0.0.1:%d/" % self.puerto) as ws:
            pong = await ws.ping()
            await asyncio.wait_for(pong, 2)

    async def test_mensaje_sobre_el_limite_cierra_la_conexion(self):
        s2 = await servir(lambda c: c.recv(), "127.0.0.1", 0, max_payload=100)
        try:
            p = s2.sockets[0].getsockname()[1]
            async with websockets.connect("ws://127.0.0.1:%d/" % p) as ws:
                await ws.send(b"x" * 500)
                with self.assertRaises(websockets.ConnectionClosed):
                    await ws.recv()
                self.assertEqual(ws.close_code, 1009)
        finally:
            s2.close()
            await s2.wait_closed()


if __name__ == "__main__":
    unittest.main()
