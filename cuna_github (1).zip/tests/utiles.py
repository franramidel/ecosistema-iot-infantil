# Piezas falsas para probar sin hardware.
import asyncio
import io
import struct


class SalidaFalsa:
    """Imita SalidaI2S. Guarda lo que se escribiría en el DAC."""
    def __init__(self, retardo=0.001):
        self.abierta = False
        self.aperturas = 0
        self.cierres = 0
        self.escrituras = []
        self.retardo = retardo

    def abrir(self):
        if not self.abierta:
            self.abierta = True
            self.aperturas += 1

    async def escribir(self, buf):
        assert self.abierta, "se escribió con la salida cerrada"
        self.escrituras.append(bytes(buf))
        await asyncio.sleep(self.retardo)

    def cerrar(self):
        if self.abierta:
            self.abierta = False
            self.cierres += 1

    def muestras(self):
        datos = b"".join(self.escrituras)
        return list(struct.unpack("<%dh" % (len(datos) // 2), datos))


class ArchivosFalsos:
    """Imita la carpeta assets. Cada canción es un BytesIO nuevo con readinto."""
    def __init__(self, canciones):
        self.canciones = canciones   # dict id -> bytes

    def listar(self):
        return list(self.canciones)

    def abrir(self, song_id):
        if song_id not in self.canciones:
            return None
        return io.BytesIO(self.canciones[song_id])


def pcm_constante(valor, n_muestras):
    return struct.pack("<%dh" % n_muestras, *([valor] * n_muestras))


def trama(seq, audio, tipo=3, ts=0):
    return struct.pack("!BBHI", 1, tipo, seq & 0xFFFF, ts) + audio


class ADCFalso:
    """Imita machine.ADC. Da lecturas sin signo de 16 bits."""
    def __init__(self, fuente=None):
        self.fuente = fuente or (lambda i: 32768)
        self.lecturas = 0
        self.falla = False

    def read_u16(self):
        if self.falla:
            raise OSError("ADC roto")
        v = self.fuente(self.lecturas)
        self.lecturas += 1
        return v


class TimerFalso:
    def __init__(self):
        self.args = None
        self.cb = None
        self.apagado = False

    def init(self, *, mode, freq, callback):
        self.args = (mode, freq)
        self.cb = callback

    def deinit(self):
        self.apagado = True
        self.cb = None


class FlagFalso:
    """Imita ThreadSafeFlag, que solo existe en MicroPython."""
    def __init__(self):
        import asyncio
        self._e = asyncio.Event()

    def set(self):
        self._e.set()

    def clear(self):
        self._e.clear()

    async def wait(self):
        await self._e.wait()
        self._e.clear()


class MicFalso:
    """Micrófono sin hardware. Entrega tramas de 320 bytes a pedido de la prueba."""
    def __init__(self):
        import asyncio
        self.activo = False
        self.perdidas = 0
        self.inicios = 0
        self.paradas = 0
        self.falla_al_iniciar = False
        self._cola = asyncio.Queue()
        self.hz = 7990

    def iniciar(self):
        from hal.mic import ErrorMic
        if self.falla_al_iniciar:
            raise ErrorMic("el ADC no responde")
        if not self.activo:
            self.activo = True
            self.inicios += 1

    def detener(self):
        if self.activo:
            self.activo = False
            self.paradas += 1

    def hz_real(self):
        return self.hz if self.activo else 0

    def poner(self, trama):
        self._cola.put_nowait(trama)

    async def siguiente_trama(self):
        return await self._cola.get()
