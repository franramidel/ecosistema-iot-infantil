# Que luz, nanas y voz no se estorben entre sí, y que los estados reportados sean los reales.
# VALIDADO SOLO CON SIMULADOR. El firmware corre entero con hardware falso.

import asyncio
import os
import struct
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config
from hal.luz import duty_para_brillo
from tests.banco import Banco, N16, ajustes
from tests.utiles import pcm_constante


class Base(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.b = await Banco().abrir()
        self.srv = self.b.srv
        self.b.arrancar()
        await self.srv.esperar_hello(1)
        await self.srv.esperar("status")
        self.alimentador = None

    async def asyncTearDown(self):
        if self.alimentador:
            self.alimentador.cancel()
        await self.b.cerrar()
        self.assertEqual(self.srv.problemas, [])

    def hablar_con_el_mic(self):
        """Un micrófono falso que entrega una trama cada 20 ms, como el real."""
        async def alimentar():
            while True:
                self.b.mic.poner(b"\x10\x00" * 160)
                await asyncio.sleep(0.02)
        self.alimentador = asyncio.create_task(alimentar())

    async def ultimo(self, tipo, **filtros):
        """Pide el estado y devuelve la respuesta más reciente de ese tipo."""
        await asyncio.sleep(0.05)
        for m in reversed(self.srv.recibidos):
            if m["type"] == tipo and all(m.get(k) == v for k, v in filtros.items()):
                return m
        raise AssertionError("no llegó " + tipo)


class PruebasInterferencia(Base):
    async def test_luz_y_nana_no_se_estorban(self):
        self.b.archivos.canciones["larga"] = pcm_constante(8000, N16 * 120)       # 2,4 segundos.
        await self.srv.audio_play("larga", "local")
        await self.srv.esperar("audio.state")
        escrituras0 = len(self.b.salida.escrituras)
        t0 = asyncio.get_running_loop().time()
        for i, brillo in enumerate((10, 80, 30, 100, 0)):
            await self.srv.light_set(brillo > 0, brillo or None, fade_ms=200)
            await asyncio.sleep(0.15)
            await self.srv.audio_volume(20 + i * 10)
            await asyncio.sleep(0.05)
        await asyncio.sleep(0.3)
        pasado = asyncio.get_running_loop().time() - t0
        escritas = len(self.b.salida.escrituras) - escrituras0
        self.assertGreaterEqual(escritas, int(pasado / 0.02 * 0.6))   # El audio no se atrasó por la luz.
        self.assertEqual(self.b.luz.estado(), (False, 0))
        self.assertEqual(self.b.pwm.historial[-1], 0)
        self.assertEqual(self.b.audio.volumen, 60)
        self.assertEqual(self.b.audio.modo, "song")                    # La luz no cortó la nana.

    async def test_luz_y_voz_no_se_estorban(self):
        self.hablar_con_el_mic()
        await self.srv.voice_start("s-1")
        await self.srv.esperar("voice.state")
        for brillo in (20, 60, 100, 40):
            await self.srv.light_set(True, brillo, fade_ms=150)
            await asyncio.sleep(0.2)
        antes = len(self.srv.voz_cuna)
        await asyncio.sleep(0.3)
        recibidas = len(self.srv.voz_cuna) - antes
        self.assertGreaterEqual(recibidas, 10)                          # El micrófono siguió mandando.
        self.assertEqual(self.b.luz.estado(), (True, 40))
        self.assertTrue(self.b.mic.activo)
        seqs = [t[0] for t in self.srv.voz_cuna]
        self.assertEqual(seqs, list(range(len(seqs))))                 # Sin huecos ni repetidas.
        await self.srv.voice_turn("app")
        await asyncio.sleep(0.05)
        await self.srv.mandar_voz(pcm_constante(8000, N16 * 20))
        await self.srv.light_set(False, fade_ms=0)
        await asyncio.sleep(0.2)
        self.assertEqual(self.b.pwm.historial[-1], 0)
        self.assertGreaterEqual(len([t for t in self.b.salida.escrituras if any(t)]), 15)

    async def test_voz_y_nana_se_reparten_el_parlante(self):
        self.b.archivos.canciones["larga"] = pcm_constante(8000, N16 * 300)
        await self.srv.audio_play("larga", "local")
        await self.srv.esperar("audio.state")
        await asyncio.sleep(0.1)
        await self.srv.voice_start("s-1")
        await self.srv.esperar("voice.state")
        self.assertEqual(self.b.audio.modo, "voice")
        await self.srv.audio_play("larga", "local")                    # Durante la voz.
        err = await self.srv.esperar("error")
        self.assertEqual(err["code"], "BUSY")
        await self.srv.voice_stop()
        await self.srv.esperar("voice.state")
        await asyncio.sleep(0.1)
        escrituras = len(self.b.salida.escrituras)
        await asyncio.sleep(0.2)
        self.assertEqual(len(self.b.salida.escrituras), escrituras)    # La nana no volvió sola.
        self.assertEqual(self.b.audio.modo, "idle")
        await self.srv.audio_play("larga", "local")                    # Pero se puede pedir de nuevo.
        e = await self.srv.esperar("audio.state")
        self.assertEqual(e["mode"], "song")
        await self.srv.audio_stop()
        await self.b.audio.esperar_fin()

    async def test_nana_del_servidor_con_luz_latido_y_eventos_a_la_vez(self):
        with ajustes(LATIDO_S=0.05):
            self.b.arrancar  # La cuna ya está corriendo. Solo se acorta el latido de la próxima sesión.
            self.srv.cortar()
            await self.srv.esperar_hello(2)
            await self.srv.esperar("status")
            await self.srv.audio_play("rio", "server")
            await self.srv.esperar("audio.state")
            envio = asyncio.create_task(self.srv.transmitir(pcm_constante(8000, N16 * 75)))   # 1,5 s.
            for i in range(10):
                await self.srv.light_set(i % 2 == 0, 10 + i * 8, fade_ms=100)
                await asyncio.sleep(0.12)
            await envio
            fin = await self.srv.esperar("audio.ended", timeout=5)
            self.assertEqual(fin["song_id"], "rio")
            self.assertEqual((self.b.audio.descartadas, self.b.audio.perdidas), (0, 0))
            self.assertLessEqual(self.b.audio.underruns, 3)
            estados = [m for m in self.srv.recibidos if m["type"] == "status"]
            self.assertGreaterEqual(len(estados), 10)                    # El latido siguió durante todo.

    async def test_el_volumen_se_aplica_tambien_en_voz(self):
        await self.srv.voice_start("s-1", "app")
        await self.srv.esperar("voice.state")
        await self.srv.audio_volume(100)
        await asyncio.sleep(0.05)
        await self.srv.mandar_voz(pcm_constante(10000, N16 * 10))
        await asyncio.sleep(0.3)
        fuertes = [max(abs(x) for x in struct.unpack("<%dh" % N16, t)) for t in self.b.salida.escrituras if any(t)]
        self.assertTrue(fuertes)
        self.assertEqual(max(fuertes), 10000 * int(256 * config.AUDIO_GANANCIA_MAX) // 256)


class PruebasEstadosConsistentes(Base):
    async def test_lo_que_la_cuna_reporta_es_lo_que_tiene(self):
        pasos = [
            lambda: self.srv.light_set(True, 70, fade_ms=0),
            lambda: self.srv.audio_volume(45),
            lambda: self.srv.audio_play("nana-1", "local"),
            lambda: self.srv.light_set(False, fade_ms=0),
            lambda: self.srv.audio_stop(),
            lambda: self.srv.voice_start("s-1"),
            lambda: self.srv.voice_turn("app"),
            lambda: self.srv.light_set(True, 5, fade_ms=0),
            lambda: self.srv.voice_turn("cradle"),
            lambda: self.srv.voice_stop(),
        ]
        for paso in pasos:
            await paso()
            await asyncio.sleep(0.45 if paso is pasos[8] else 0.12)
            await self.srv.mandar({"v": 1, "type": "light.get", "id": "lg"})
            await self.srv.mandar({"v": 1, "type": "audio.get", "id": "ag"})
            await asyncio.sleep(0.08)
            luz = await self.ultimo("light.state", cause="command")
            audio = await self.ultimo("audio.state")
            on, brillo = self.b.luz.estado()
            self.assertEqual((luz["on"], luz["brightness"]), (on, brillo))
            self.assertEqual((audio["mode"], audio["volume"]), (self.b.audio.modo, self.b.audio.volumen))
            self.assertEqual(audio["song_id"], self.b.audio.song_id)
            self.assertEqual(self.b.pwm.historial[-1], duty_para_brillo(brillo))
        # Al final todo en reposo, y el micrófono apagado.
        self.assertFalse(self.b.mic.activo)
        self.assertEqual(self.b.audio.modo, "idle")
        self.assertFalse(self.b.salida.abierta)

    async def test_el_ack_llega_antes_que_el_estado_final(self):
        await self.srv.light_set(True, 50, fade_ms=100)
        await asyncio.sleep(0.3)
        orden = [m["type"] for m in self.srv.recibidos if m["type"] in ("ack", "light.state")
                 and (m.get("ref") == "r-1" or m.get("seq") == 1)]
        self.assertEqual(orden, ["ack", "light.state"])

    async def test_ninguna_pieza_se_queda_encendida_tras_un_barrido_de_ordenes(self):
        self.hablar_con_el_mic()
        for _ in range(3):
            await self.srv.voice_start("s-1")
            await asyncio.sleep(0.05)
            await self.srv.voice_turn("app")
            await asyncio.sleep(0.05)
            await self.srv.voice_turn("cradle")
            await asyncio.sleep(0.05)
            await self.srv.voice_stop()
            await asyncio.sleep(0.05)
        await asyncio.sleep(0.3)
        self.assertFalse(self.b.mic.activo)
        self.assertFalse(self.b.salida.abierta)
        self.assertIsNone(self.b.voz.sesion)
        self.assertEqual(self.b.audio.modo, "idle")


if __name__ == "__main__":
    unittest.main()
