# Salida de audio por PWM, sin DAC. VALIDADO SOLO CON SIMULADOR: el PWM es falso.
# Las pruebas usan las dos nanas reales de assets. No prueban cómo suena en el parlante.
import asyncio
import os
import struct
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config
from hal.audio_tonos import SalidaTonos, estimar_tono
from servicios.gestor_audio import GestorAudio
from tests.utiles import ArchivosFalsos
from tools.generar_nanas import NANAS, RATE

N = config.AUDIO_TRAMA_BYTES // 2


def leer(nombre):
    with open(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets", nombre + ".pcm"), "rb") as f:
        return f.read()


def seno(freq, n=N, amp=8000):
    import math
    return struct.pack("<%dh" % n, *[int(amp * math.sin(2 * math.pi * freq * i / RATE)) for i in range(n)])


class PWMFalso:
    def __init__(self, pin=None):
        self.eventos = []
        self.f = None
        self.d = 0
        self.vivo = True

    def freq(self, v):
        self.f = v
        self.eventos.append(("f", v))

    def duty_u16(self, v):
        self.d = v
        self.eventos.append(("d", v))

    def deinit(self):
        self.vivo = False


class PruebasEstimador(unittest.TestCase):
    def test_tonos_puros(self):
        for f in (110, 261.63, 329.63, 440, 523.25, 1000, 2000):
            est, pico = estimar_tono(seno(f), N)
            self.assertAlmostEqual(est / f, 1.0, delta=0.03, msg=str(f))
            self.assertGreater(pico, 7000)

    def test_silencio_y_ruido_bajo(self):
        self.assertEqual(estimar_tono(bytes(N * 2), N)[0], 0)
        self.assertEqual(estimar_tono(seno(440, amp=100), N)[0], 0)
        self.assertEqual(estimar_tono(b"", 0), (0, 0))

    def test_una_trama_corta_o_con_un_solo_ciclo_no_da_tono(self):
        self.assertEqual(estimar_tono(seno(440, n=3), 3), (0, 0))
        self.assertEqual(estimar_tono(seno(30, n=N), N)[0], 0)      # Menos de 2 ciclos en 20 ms.

    def test_las_dos_nanas_reales_dan_la_nota_correcta(self):
        for nombre, notas in NANAS.items():
            pcm = leer(nombre)
            pos = 0
            revisadas = 0
            for freq, seg in notas:
                n = int(RATE * seg)
                # Se saltan 3 tramas al inicio y 8 al final: ahí el volumen sube y baja y se acerca a cero.
                for k in range(3, n // N - 8):
                    ini = (pos + k * N) * 2
                    est, _ = estimar_tono(pcm[ini:ini + N * 2], N)
                    self.assertAlmostEqual(est / freq, 1.0, delta=0.03, msg="%s nota %s trama %d" % (nombre, freq, k))
                    revisadas += 1
                pos += n
            self.assertGreater(revisadas, 200)


class PruebasSalida(unittest.IsolatedAsyncioTestCase):
    async def test_pone_frecuencia_y_ciclo_de_trabajo(self):
        pwm = PWMFalso()
        s = SalidaTonos(crear_pwm=lambda pin: pwm)
        s.abrir()
        await s.escribir(seno(440))
        self.assertAlmostEqual(pwm.f, 440, delta=14)
        esperado = min(config.AUDIO_TONO_DUTY_MAX, 8000 / 32768 * config.AUDIO_TONO_ESCALA)
        self.assertAlmostEqual(pwm.d / 65535, esperado, delta=0.02)

    async def test_mas_pico_da_mas_ciclo_y_nunca_pasa_del_maximo(self):
        pwm = PWMFalso()
        s = SalidaTonos(crear_pwm=lambda pin: pwm)
        s.abrir()
        previos = []
        for amp in (500, 2000, 8000, 32000):
            await s.escribir(seno(440, amp=amp))
            previos.append(pwm.d)
        self.assertEqual(previos, sorted(previos))
        self.assertLessEqual(previos[-1] / 65535, config.AUDIO_TONO_DUTY_MAX + 0.001)

    async def test_silencio_apaga_el_ciclo(self):
        pwm = PWMFalso()
        s = SalidaTonos(crear_pwm=lambda pin: pwm)
        s.abrir()
        await s.escribir(seno(440))
        await s.escribir(bytes(N * 2))
        self.assertEqual(pwm.d, 0)

    async def test_frecuencias_fuera_de_rango_se_callan(self):
        pwm = PWMFalso()
        s = SalidaTonos(crear_pwm=lambda pin: pwm)
        s.abrir()
        await s.escribir(seno(6000))
        self.assertEqual(pwm.d, 0)

    async def test_no_toca_la_frecuencia_si_no_cambia(self):
        pwm = PWMFalso()
        s = SalidaTonos(crear_pwm=lambda pin: pwm)
        s.abrir()
        for _ in range(5):
            await s.escribir(seno(440))
        self.assertEqual(len([e for e in pwm.eventos if e[0] == "f"]), 1)

    async def test_cerrar_apaga_y_libera(self):
        pwm = PWMFalso()
        s = SalidaTonos(crear_pwm=lambda pin: pwm)
        s.abrir()
        await s.escribir(seno(440))
        s.cerrar()
        self.assertEqual(pwm.d, 0)
        self.assertFalse(pwm.vivo)
        s.cerrar()                       # Cerrar dos veces no falla.
        s.abrir()                        # Se puede volver a abrir.


class PruebasConGestor(unittest.IsolatedAsyncioTestCase):
    def preparar(self):
        self.pwm = PWMFalso()
        self.salida = SalidaTonos(crear_pwm=lambda pin: self.pwm)
        self.enviados = []
        self.archivos = ArchivosFalsos({"nana-1": leer("nana-1"), "nana-2": leer("nana-2")})

        async def enviar(msg):
            self.enviados.append(msg)
        self.g = GestorAudio(self.salida, enviar, lambda: 1000, self.archivos.abrir, self.archivos.listar)
        self.g.volumen = 100

    def play(self, seq, sid, fuente):
        return {"v": 1, "type": "audio.play", "id": "p%d" % seq, "seq": seq, "song_id": sid, "source": fuente}

    async def test_la_nana_suena_como_la_melodia_y_termina_sola(self):
        self.preparar()
        saltos = []
        original = self.pwm.freq

        def espiar(v):
            saltos.append(v)
            original(v)
        self.pwm.freq = espiar
        await self.g.manejar(self.play(1, "nana-1", "local"))
        await asyncio.wait_for(self.g.esperar_fin(), 60)
        esperadas = [f for f, _ in NANAS["nana-1"]]
        # Las notas distintas que se oyen, en orden, deben coincidir con la melodía.
        oidas = []
        for v in saltos:
            if not oidas or abs(v - oidas[-1]) / oidas[-1] > 0.04:
                oidas.append(v)
        notas = []
        for f in esperadas:
            if not notas or abs(f - notas[-1]) / notas[-1] > 0.01:
                notas.append(f)
        # Las notas repetidas seguidas se funden. Se compara que cada nota esperada aparezca en orden.
        i = 0
        for v in oidas:
            if i < len(notas) and abs(v - notas[i]) / notas[i] < 0.04:
                i += 1
        self.assertEqual(i, len(notas), "oídas %s esperadas %s" % ([round(x) for x in oidas], notas))
        self.assertEqual(self.g.modo, "idle")
        self.assertEqual(self.pwm.d, 0)
        self.assertFalse(self.pwm.vivo)
        fines = [m for m in self.enviados if m["type"] == "audio.ended"]
        self.assertEqual(len(fines), 1)

    async def test_el_volumen_cambia_el_ciclo_de_trabajo(self):
        maximos = {}
        for vol in (20, 100):
            self.preparar()
            self.g.volumen = vol
            await self.g.manejar(self.play(1, "nana-1", "local"))
            await asyncio.sleep(1.5)
            m = max(v for t, v in self.pwm.eventos if t == "d")
            maximos[vol] = m
            await self.g.manejar({"v": 1, "type": "audio.stop", "id": "s", "seq": 2})
            await asyncio.wait_for(self.g.esperar_fin(), 5)
        self.assertGreater(maximos[100], maximos[20] * 1.5)

    async def test_parar_baja_a_cero_y_cierra(self):
        self.preparar()
        await self.g.manejar(self.play(1, "nana-2", "local"))
        await asyncio.sleep(0.5)
        await self.g.manejar({"v": 1, "type": "audio.stop", "id": "s", "seq": 2})
        await asyncio.wait_for(self.g.esperar_fin(), 5)
        self.assertEqual(self.g.modo, "idle")
        self.assertEqual(self.pwm.d, 0)
        self.assertFalse(self.pwm.vivo)

    async def test_cancion_del_servidor_recibe_unsupported(self):
        self.preparar()
        await self.g.manejar(self.play(1, "rio", "server"))
        errores = [m for m in self.enviados if m["type"] == "error"]
        self.assertEqual([e["code"] for e in errores], ["UNSUPPORTED"])
        self.assertEqual(self.g.modo, "idle")
        self.assertEqual(self.g.ultimo_seq, 0)

    async def test_la_voz_de_la_app_se_descarta(self):
        self.preparar()
        self.assertFalse(self.g.encolar_voz(bytes(640)))
        self.assertEqual(self.g._cola_voz, [])


class PruebasDeExtremoAExtremo(unittest.IsolatedAsyncioTestCase):
    """La cuna completa en modo tonos contra el simulador."""
    async def asyncSetUp(self):
        from tests.banco import Banco
        self.pwm = PWMFalso()
        self.b = await Banco().abrir(canciones={"nana-1": leer("nana-1"), "nana-2": leer("nana-2")},
                                     salida=SalidaTonos(crear_pwm=lambda pin: self.pwm))
        self.srv = self.b.srv
        self.alimentador = None

    async def asyncTearDown(self):
        if self.alimentador:
            self.alimentador.cancel()
        await self.b.cerrar()
        self.assertEqual(self.srv.problemas, [])

    async def test_el_hello_dice_que_es_salida_por_tonos(self):
        self.b.arrancar()
        await self.srv.esperar_hello(1)
        caps = self.srv.hello["caps"]
        self.assertEqual(caps["audio_out_mode"], "tones")
        self.assertIs(caps["voice_playback"], False)
        self.assertIs(caps["server_songs"], False)
        self.assertEqual(sorted(caps["local_songs"]), ["nana-1", "nana-2"])

    async def test_nana_local_y_rechazo_de_cancion_del_servidor(self):
        self.b.arrancar()
        await self.srv.esperar_hello(1)
        await self.srv.esperar("status")
        await self.srv.audio_play("nana-2", "local")
        a = await self.srv.esperar("audio.state")
        while a["mode"] != "song":
            a = await self.srv.esperar("audio.state")
        await asyncio.sleep(0.4)
        self.assertGreater(self.pwm.d, 0)
        await self.srv.audio_stop()
        await self.b.audio.esperar_fin()
        await self.srv.audio_play("rio", "server")
        e = await self.srv.esperar("error")
        self.assertEqual(e["code"], "UNSUPPORTED")

    async def test_el_micrófono_sigue_y_la_voz_de_la_app_no_suena(self):
        async def alimentar():
            while True:
                self.b.mic.poner(b"\x10\x00" * 160)
                await asyncio.sleep(0.02)
        self.alimentador = asyncio.create_task(alimentar())
        self.b.arrancar()
        await self.srv.esperar_hello(1)
        await self.srv.esperar("status")
        await self.srv.voice_start("s-1")
        await self.srv.esperar("voice.state")
        await asyncio.sleep(0.5)
        self.assertGreater(len(self.srv.voz_cuna), 10)       # La cuna le habla a la app.
        await self.srv.voice_turn("app")
        await asyncio.sleep(0.05)
        await self.srv.mandar_voz(seno(440, n=N * 20))
        await asyncio.sleep(0.2)
        self.assertEqual(self.pwm.d, 0)                       # Y no suena nada por el parlante.
        self.assertEqual(self.b.voz.sesion is not None, True)
        await self.srv.voice_stop()
        await self.srv.esperar("voice.state")


if __name__ == "__main__":
    unittest.main()
