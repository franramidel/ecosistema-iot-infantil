# Voz por turnos de punta a punta con el simulador. VALIDA PROTOCOLO, NO HARDWARE.
# El micrófono y la salida son falsos.

import asyncio
import os
import struct
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from simulador.ws_servidor import servir

import config
from hal.luz import Luz
from servicios.cuna_app import CunaApp
from servicios.enlace import Enlace
from servicios.gestor_audio import GestorAudio
from servicios.reloj import Reloj
from servicios.voz import ServicioVoz
from servicios.ws_cliente import ClienteWS, ErrorWS
from simulador.servidor_sim import ServidorSim, RUTA
from tests.test_luz import PWMFalso
from tests.utiles import ArchivosFalsos, MicFalso, SalidaFalsa, pcm_constante

TOKEN = "TOKEN_DE_PRUEBA"
N16 = config.AUDIO_TRAMA_BYTES // 2


class PruebasVozIntegracion(unittest.IsolatedAsyncioTestCase):
    async def asyncSetUp(self):
        self.srv = ServidorSim(TOKEN)
        self.servidor = await servir(self.srv.manejador, "127.0.0.1", 0)
        self.puerto = self.servidor.sockets[0].getsockname()[1]
        self.reloj = Reloj()
        self.salida = SalidaFalsa(retardo=0.02)
        self.archivos = ArchivosFalsos({"nana-1": pcm_constante(8000, N16 * 500)})
        self.enlace = Enlace()
        self.audio = GestorAudio(self.salida, self.enlace.enviar_json, self.reloj.ahora_ms,
                                 self.archivos.abrir, self.archivos.listar)
        self.audio.volumen = 100
        self.mic = MicFalso()
        self.voz = ServicioVoz(self.audio, self.mic, self.enlace.enviar_json,
                               self.enlace.enviar_binario, self.reloj.ahora_ms)

    async def asyncTearDown(self):
        # Todo lo que mandó la cuna debe cumplir el contrato.
        self.assertEqual(self.srv.problemas, [])
        await self.voz.terminar(False)
        self.servidor.close()
        await self.servidor.wait_closed()

    async def conectar(self):
        cliente = ClienteWS("127.0.0.1", self.puerto, RUTA)
        await cliente.conectar()
        self.enlace.cliente = cliente
        app = CunaApp(cliente, Luz(PWMFalso(), paso_ms=5), self.reloj, "uuid-de-prueba", TOKEN,
                      self.audio, self.voz)
        await app.saludar()
        escucha = asyncio.create_task(self.bucle(cliente, app))
        return cliente, app, escucha

    async def bucle(self, cliente, app):
        try:
            while True:
                op, datos = await cliente.recibir()
                await app.despachar(op, datos)
        except (ErrorWS, asyncio.IncompleteReadError, ConnectionError):
            pass

    async def estado_voz(self, activa, timeout=5):
        while True:
            e = await self.srv.esperar("voice.state", timeout)
            if e["active"] == activa:
                return e

    async def test_hello_declara_voz_y_el_mic_sigue_apagado(self):
        cliente, app, escucha = await self.conectar()
        self.assertTrue(self.srv.hello["caps"]["voice"])
        self.assertEqual(self.srv.hello["caps"]["audio_in_hz"], 8000)
        e = await self.estado_voz(False)
        self.assertFalse(e["mic_active"])
        self.assertEqual(self.mic.inicios, 0)
        escucha.cancel()
        await cliente.cerrar()

    async def test_conversacion_completa_por_turnos(self):
        cliente, app, escucha = await self.conectar()
        await self.estado_voz(False)
        # La nana suena y la voz la corta.
        await self.srv.audio_play("nana-1", "local")
        await self.srv.esperar("audio.state")
        await asyncio.sleep(0.15)
        await self.srv.voice_start("s-9")
        e = await self.estado_voz(True)
        self.assertEqual((e["turn"], e["mic_active"]), ("cradle", True))
        # Turno de la cuna. El micrófono falso habla.
        for i in range(5):
            self.mic.poner(bytes([i + 1]) * 320)
        await asyncio.sleep(0.2)
        self.assertEqual(len(self.srv.voz_cuna), 5)
        self.assertEqual([t[0] for t in self.srv.voz_cuna], [0, 1, 2, 3, 4])
        self.assertEqual(self.srv.voz_cuna[2][2], bytes([3]) * 320)
        # Turno de la app. El servidor manda un segundo de voz.
        await self.srv.voice_turn("app")
        e = await self.estado_voz(True)
        while e["turn"] != "app":
            e = await self.estado_voz(True)
        self.assertFalse(e["mic_active"])
        await self.srv.mandar_voz(pcm_constante(8000, N16 * 50))
        await asyncio.sleep(0.2)
        habla = [t for t in self.salida.escrituras if any(t)]
        self.assertGreaterEqual(len(habla), 45)
        # Cierra.
        await self.srv.voice_stop()
        e = await self.estado_voz(False)
        self.assertFalse(self.mic.activo)
        self.assertEqual(self.audio.modo, "idle")
        self.assertEqual(len(self.srv_filtrar("audio.ended")), 0)
        escucha.cancel()
        await cliente.cerrar()

    def srv_filtrar(self, tipo):
        return [x for x in self.srv.recibidos if x["type"] == tipo]

    async def test_se_guarda_un_wav_con_lo_que_oyo_la_cuna(self):
        import wave
        cliente, app, escucha = await self.conectar()
        await self.estado_voz(False)
        await self.srv.voice_start("s-1")
        await self.estado_voz(True)
        for _ in range(10):
            self.mic.poner(b"\x10\x00" * 160)
        await asyncio.sleep(0.2)
        ruta = os.path.join(os.path.dirname(os.path.abspath(__file__)), "_prueba.wav")
        try:
            self.assertEqual(self.srv.guardar_wav(ruta), 10)
            with wave.open(ruta) as w:
                self.assertEqual((w.getframerate(), w.getnchannels(), w.getnframes()), (8000, 1, 1600))
        finally:
            if os.path.exists(ruta):
                os.remove(ruta)
        escucha.cancel()
        await cliente.cerrar()

    async def test_si_se_cae_la_conexion_el_mic_se_apaga(self):
        cliente, app, escucha = await self.conectar()
        await self.estado_voz(False)
        await self.srv.voice_start("s-1")
        await self.estado_voz(True)
        self.assertTrue(self.mic.activo)
        await self.srv.conexion.close()
        await asyncio.sleep(0.1)
        # Esto es lo que hace main.py en su bloque finally.
        self.enlace.cliente = None
        await self.voz.terminar(False)
        self.assertFalse(self.mic.activo)
        self.assertEqual(self.audio.modo, "idle")

    async def test_voz_sin_servicio_sigue_dando_unsupported(self):
        cliente = ClienteWS("127.0.0.1", self.puerto, RUTA)
        await cliente.conectar()
        app = CunaApp(cliente, Luz(PWMFalso(), paso_ms=5), self.reloj, "u", TOKEN)
        await app.saludar()
        self.assertFalse(self.srv.hello["caps"]["voice"])
        escucha = asyncio.create_task(self.bucle(cliente, app))
        await self.srv.mandar({"v": 1, "type": "voice.start", "id": "v1", "session_id": "s", "turn": "cradle"})
        err = await self.srv.esperar("error")
        self.assertEqual((err["code"], err["ref"]), ("UNSUPPORTED", "v1"))
        escucha.cancel()
        await cliente.cerrar()


if __name__ == "__main__":
    unittest.main()
