import asyncio
import math
import os
import struct
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import config
from hal.mic import ErrorMic, Microfono, _procesar
from array import array
from tests.utiles import ADCFalso, FlagFalso, TimerFalso


def procesar(lecturas, ganancia=256, estado=None):
    """Corre el procesado sobre una lista de lecturas de 16 bits sin signo."""
    src = array("H", lecturas)
    dst = bytearray(2 * len(lecturas))
    est = estado if estado is not None else array("i", [0])
    _procesar(src, dst, len(lecturas), est, ganancia)
    return list(struct.unpack("<%dh" % len(lecturas), dst)), est


class PruebasProcesado(unittest.TestCase):
    def test_nivel_de_continua_se_va(self):
        # Una lectura fija de 40000 es puro nivel de continua. Debe tender a cero.
        salida, _ = procesar([40000] * 6000)
        self.assertGreater(abs(salida[0]), 1000)
        self.assertLess(abs(salida[-1]), 5)

    def test_centro_de_escala_da_silencio(self):
        salida, _ = procesar([32768] * 200)
        self.assertEqual(set(salida), {0})

    def test_una_onda_pasa_con_su_amplitud(self):
        onda = [int(32768 + 3000 * math.sin(2 * math.pi * 400 * i / 8000)) for i in range(4000)]
        salida, _ = procesar(onda, ganancia=256)
        cola = salida[-800:]
        self.assertAlmostEqual(max(cola), 3000, delta=150)
        self.assertAlmostEqual(min(cola), -3000, delta=150)

    def test_la_ganancia_multiplica(self):
        onda = [int(32768 + 1000 * math.sin(2 * math.pi * 400 * i / 8000)) for i in range(4000)]
        uno, _ = procesar(onda, 256)
        cuatro, _ = procesar(onda, 1024)
        self.assertAlmostEqual(max(cuatro[-800:]) / max(uno[-800:]), 4, delta=0.1)

    def test_recorta_sin_dar_la_vuelta(self):
        onda = [65535 if (i // 4) % 2 else 0 for i in range(800)]
        salida, _ = procesar(onda, 4096)
        self.assertTrue(all(-32768 <= x <= 32767 for x in salida))
        self.assertEqual(max(salida), 32767)
        self.assertEqual(min(salida), -32768)

    def test_el_estado_se_guarda_entre_tramas(self):
        est = array("i", [0])
        procesar([40000] * 160, estado=est)
        despues_de_una = est[0]
        procesar([40000] * 160, estado=est)
        self.assertGreater(est[0], despues_de_una)


class PruebasMicrofono(unittest.IsolatedAsyncioTestCase):
    def armar(self, fuente=None, nbufs=4, muestras=8):
        self.adc = ADCFalso(fuente)
        self.timers = []
        self.t = [0]

        def crear_timer():
            tm = TimerFalso()
            self.timers.append(tm)
            return tm
        mic = Microfono(self.adc, crear_timer, "PERIODICO", FlagFalso, lambda: self.t[0],
                        rate=8000, muestras=muestras, nbufs=nbufs, ganancia=256)
        return mic

    def pulsos(self, mic, n):
        for _ in range(n):
            mic._cb(None)

    async def test_apagado_por_defecto(self):
        mic = self.armar()
        self.assertFalse(mic.activo)
        self.assertEqual(self.timers, [])          # Ni siquiera se creó el temporizador.
        self.assertEqual(self.adc.lecturas, 0)     # Y no se leyó nada.
        self.assertEqual(mic.hz_real(), 0)

    async def test_iniciar_crea_temporizador_a_8khz(self):
        mic = self.armar()
        mic.iniciar()
        self.assertTrue(mic.activo)
        self.assertEqual(self.timers[0].args, ("PERIODICO", 8000))

    async def test_iniciar_dos_veces_no_duplica(self):
        mic = self.armar()
        mic.iniciar()
        mic.iniciar()
        self.assertEqual(len(self.timers), 1)

    async def test_detener_apaga_el_temporizador(self):
        mic = self.armar()
        mic.iniciar()
        mic.detener()
        self.assertFalse(mic.activo)
        self.assertTrue(self.timers[0].apagado)
        mic.detener()                                # Detener dos veces no falla.

    async def test_adc_roto_da_error_y_no_arranca(self):
        mic = self.armar()
        self.adc.falla = True
        with self.assertRaises(ErrorMic):
            mic.iniciar()
        self.assertFalse(mic.activo)
        self.assertEqual(self.timers, [])

    async def test_entrega_tramas_completas_en_orden(self):
        mic = self.armar(fuente=lambda i: 32768 + (i % 100), muestras=8)
        mic.iniciar()
        self.pulsos(mic, 8 * 3)
        for _ in range(3):
            trama = await asyncio.wait_for(mic.siguiente_trama(), 1)
            self.assertEqual(len(trama), 16)
        # Ya no hay más. La siguiente espera.
        with self.assertRaises(asyncio.TimeoutError):
            await asyncio.wait_for(mic.siguiente_trama(), 0.05)

    async def test_espera_y_despierta_cuando_llega_una_trama(self):
        mic = self.armar(muestras=8)
        mic.iniciar()
        tarea = asyncio.create_task(mic.siguiente_trama())
        await asyncio.sleep(0.01)
        self.assertFalse(tarea.done())
        self.pulsos(mic, 8)
        trama = await asyncio.wait_for(tarea, 1)
        self.assertEqual(len(trama), 16)

    async def test_anillo_lleno_cuenta_perdidas_sin_romperse(self):
        mic = self.armar(muestras=8, nbufs=3)
        mic.iniciar()
        self.pulsos(mic, 8 * 10)                     # Nadie consume.
        self.assertGreater(mic.perdidas, 0)
        for _ in range(2):                           # Caben nbufs menos uno.
            await asyncio.wait_for(mic.siguiente_trama(), 1)
        with self.assertRaises(asyncio.TimeoutError):
            await asyncio.wait_for(mic.siguiente_trama(), 0.05)

    async def test_hz_real_mide_lo_que_se_hizo(self):
        mic = self.armar()
        mic.iniciar()
        self.t[0] = 1000                             # Pasó un segundo.
        self.pulsos(mic, 7500)                       # Pero el temporizador no llegó a 8000.
        self.assertEqual(mic.hz_real(), 7500)

    async def test_al_reiniciar_los_contadores_vuelven_a_cero(self):
        mic = self.armar(muestras=8, nbufs=3)
        mic.iniciar()
        self.pulsos(mic, 80)
        mic.detener()
        mic.iniciar()
        self.assertEqual(mic.perdidas, 0)
        self.t[0] = 500
        self.pulsos(mic, 100)
        self.assertEqual(mic.hz_real(), 200)

    async def test_tick_no_crea_numeros_grandes(self):
        # El callback debe ser simple. Solo revisa que los contadores no crezcan raro.
        mic = self.armar(muestras=8)
        mic.iniciar()
        self.pulsos(mic, 8)
        self.assertLess(mic._i, 8)
        self.assertLess(mic._w, mic._nb)


if __name__ == "__main__":
    unittest.main()
