# SCRUM-44 y SCRUM-45, lado servidor. VALIDADO SOLO CON SIMULADOR: no se manda nada a Telegram.
import asyncio
import os
import sys
import unittest
from datetime import datetime, timedelta

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from servidor.alertas import Alertas, LIMITE_PIE, LIMITE_TEXTO
from servidor.horarios import (ErrorHorario, ZONA_CR, en_ventana, siguiente_cambio, validar_rangos)
from servidor.kit import ControlKit
from simulador.validar import validar


def cr(texto):
    """'2026-11-23 20:00' -> datetime con zona de Costa Rica. El 23 de noviembre de 2026 es lunes."""
    f = "%Y-%m-%d %H:%M:%S" if texto.count(":") == 2 else "%Y-%m-%d %H:%M"
    return datetime.strptime(texto, f).replace(tzinfo=ZONA_CR)


def rango(sid="h-1", days=(1, 2, 3, 4, 5, 6, 7), start="20:00", end="06:00", enabled=True):
    return {"schedule_id": sid, "days": list(days), "start": start, "end": end, "enabled": enabled}


class PruebasHorarios(unittest.TestCase):
    def activo(self, rangos, cuando):
        return en_ventana(validar_rangos(rangos), cr(cuando))

    def test_el_dia_de_la_prueba_es_lunes(self):
        self.assertEqual(cr("2026-11-23 12:00").weekday(), 0)

    def test_rango_normal_inicio_entra_y_fin_no(self):
        r = [rango(start="08:00", end="12:00")]
        self.assertFalse(self.activo(r, "2026-11-23 07:59"))
        self.assertTrue(self.activo(r, "2026-11-23 08:00"))
        self.assertTrue(self.activo(r, "2026-11-23 11:59"))
        self.assertFalse(self.activo(r, "2026-11-23 12:00"))

    def test_rango_que_cruza_medianoche(self):
        r = [rango()]
        self.assertFalse(self.activo(r, "2026-11-23 19:59"))
        self.assertTrue(self.activo(r, "2026-11-23 20:00"))
        self.assertTrue(self.activo(r, "2026-11-23 23:59"))
        self.assertTrue(self.activo(r, "2026-11-24 00:00"))
        self.assertTrue(self.activo(r, "2026-11-24 05:59"))
        self.assertFalse(self.activo(r, "2026-11-24 06:00"))

    def test_el_dia_que_cuenta_es_el_de_inicio(self):
        r = [rango(days=[1])]                                  # Solo lunes, 20:00 a 06:00.
        self.assertTrue(self.activo(r, "2026-11-24 03:00"))    # Martes de madrugada, aún del lunes.
        self.assertFalse(self.activo(r, "2026-11-23 03:00"))   # Lunes de madrugada, viene del domingo.
        self.assertFalse(self.activo(r, "2026-11-24 21:00"))   # Martes de noche no cuenta.

    def test_el_domingo_cruza_hacia_el_lunes(self):
        r = [rango(days=[7])]
        self.assertTrue(self.activo(r, "2026-11-29 22:00"))    # Domingo.
        self.assertTrue(self.activo(r, "2026-11-30 05:00"))    # Lunes siguiente.
        self.assertFalse(self.activo(r, "2026-11-30 06:00"))

    def test_hora_de_otra_zona_se_convierte(self):
        r = [rango(start="08:00", end="12:00")]
        utc = datetime(2026, 11, 23, 15, 0, tzinfo=ZONA_CR.__class__(timedelta(0)))   # 09:00 en Costa Rica.
        self.assertTrue(en_ventana(validar_rangos(r), utc))

    def test_hora_sin_zona_se_rechaza(self):
        with self.assertRaises(ValueError):
            en_ventana(validar_rangos([rango()]), datetime(2026, 11, 23, 21, 0))

    def test_desactivado_no_cuenta(self):
        self.assertFalse(self.activo([rango(enabled=False)], "2026-11-23 22:00"))

    def test_solapes_se_rechazan(self):
        casos = [
            [rango("a", start="20:00", end="23:00"), rango("b", start="22:00", end="02:00")],
            [rango("a"), rango("b", days=[2], start="01:00", end="03:00")],        # Se pisa con la cola del lunes.
            [rango("a", days=[7]), rango("b", days=[1], start="02:00", end="04:00")],   # Domingo cruza al lunes.
            [rango("a", start="08:00", end="12:00"), rango("b", start="09:00", end="10:00")],
        ]
        for c in casos:
            with self.assertRaises(ErrorHorario) as cm:
                validar_rangos(c)
            self.assertEqual(cm.exception.codigo, "SCHEDULE_OVERLAP", c)

    def test_rangos_que_se_tocan_no_se_solapan(self):
        validar_rangos([rango("a", start="08:00", end="12:00"), rango("b", start="12:00", end="14:00")])
        validar_rangos([rango("a", days=[1], start="20:00", end="06:00"), rango("b", days=[2], start="06:00", end="10:00")])

    def test_un_desactivado_no_causa_solape(self):
        validar_rangos([rango("a"), rango("b", enabled=False)])

    def test_formatos_invalidos(self):
        malos = [rango(start="8:00"), rango(start="24:00"), rango(end="12:60"), rango(start="20:00", end="20:00"),
                 rango(days=[]), rango(days=[0]), rango(days=[8]), rango(days=[1, 1]), rango(days=["1"]),
                 rango(days=[True]), rango(sid=""), rango(enabled="si"), "no es objeto", None]
        for m in malos:
            with self.assertRaises(ErrorHorario, msg=repr(m)) as cm:
                validar_rangos([m])
            self.assertEqual(cm.exception.codigo, "INVALID_RANGE")
        with self.assertRaises(ErrorHorario):
            validar_rangos([rango("a"), rango("a", days=[1], start="08:00", end="09:00")])
        with self.assertRaises(ErrorHorario):
            validar_rangos("x")

    def test_siguiente_cambio(self):
        n = validar_rangos([rango()])
        self.assertEqual(siguiente_cambio(n, cr("2026-11-23 15:00")), cr("2026-11-23 20:00"))
        self.assertEqual(siguiente_cambio(n, cr("2026-11-23 20:00")), cr("2026-11-24 06:00"))
        self.assertEqual(siguiente_cambio(n, cr("2026-11-23 20:00:30")), cr("2026-11-24 06:00"))
        self.assertEqual(siguiente_cambio(n, cr("2026-11-24 06:00")), cr("2026-11-24 20:00"))
        self.assertIsNone(siguiente_cambio([], cr("2026-11-23 15:00")))
        self.assertIsNone(siguiente_cambio(validar_rangos([rango(enabled=False)]), cr("2026-11-23 15:00")))

    def test_siguiente_cambio_da_la_vuelta_a_la_semana(self):
        n = validar_rangos([rango(days=[1], start="08:00", end="09:00")])
        self.assertEqual(siguiente_cambio(n, cr("2026-11-23 09:00")), cr("2026-11-30 08:00"))


class Reloj:
    def __init__(self, inicio):
        self.t = cr(inicio)

    def __call__(self):
        return self.t

    def avanzar(self, **k):
        self.t += timedelta(**k)


class PruebasControl(unittest.IsolatedAsyncioTestCase):
    def nuevo(self, inicio="2026-11-23 15:00", rangos=None):
        self.reloj = Reloj(inicio)
        self.enviados = []

        async def enviar(m):
            self.enviados.append(m)
        self.c = ControlKit(self.reloj, enviar)
        if rangos is not None:
            self.c.set_rangos(rangos)
        return self.c

    async def test_sin_rangos_el_kit_esta_inactivo(self):
        c = self.nuevo()
        self.assertEqual(c.estado(), (False, "none"))
        await c.revisar()
        self.assertEqual(self.enviados[0]["reason"], "none")

    async def test_la_ventana_arma_y_desarma_sola(self):
        c = self.nuevo(rangos=[rango()])
        await c.revisar()
        self.reloj.t = cr("2026-11-23 20:00")
        await c.revisar()
        self.reloj.t = cr("2026-11-24 06:00")
        await c.revisar()
        self.assertEqual([(m["armed"], m["reason"]) for m in self.enviados],
                         [(False, "schedule"), (True, "schedule"), (False, "schedule")])

    async def test_no_repite_el_mismo_estado_pero_se_puede_forzar(self):
        c = self.nuevo(rangos=[rango()])
        await c.revisar()
        await c.revisar()
        self.assertEqual(len(self.enviados), 1)
        await c.revisar(forzar=True)                    # El kit reconectó.
        self.assertEqual(len(self.enviados), 2)

    async def test_manual_es_inmediato_y_vence_en_el_siguiente_cambio(self):
        c = self.nuevo(rangos=[rango()])                # Lunes 15:00, fuera de ventana.
        await c.manual("arm")
        self.assertEqual(c.estado(), (True, "manual"))
        self.reloj.t = cr("2026-11-23 19:59")
        self.assertEqual(c.estado(), (True, "manual"))
        self.reloj.t = cr("2026-11-23 20:00")           # Empieza la ventana. Manda el horario.
        self.assertEqual(c.estado(), (True, "schedule"))

    async def test_desarmar_en_plena_ventana_dura_hasta_que_termine(self):
        c = self.nuevo("2026-11-23 22:00", rangos=[rango()])
        await c.manual("disarm")
        self.assertEqual(c.estado(), (False, "manual"))
        self.reloj.t = cr("2026-11-24 05:59")
        self.assertEqual(c.estado(), (False, "manual"))
        self.reloj.t = cr("2026-11-24 06:00")
        self.assertEqual(c.estado(), (False, "schedule"))
        self.reloj.t = cr("2026-11-24 20:00")           # Y la noche siguiente vuelve a armar sola.
        self.assertEqual(c.estado(), (True, "schedule"))

    async def test_manual_sin_rangos_dura_hasta_que_alguien_lo_cambie(self):
        c = self.nuevo()
        await c.manual("arm")
        self.reloj.avanzar(days=30)
        self.assertEqual(c.estado(), (True, "manual"))
        await c.manual("disarm")
        self.assertEqual(c.estado(), (False, "manual"))

    async def test_manual_manda_el_mensaje_al_kit_y_cumple_el_contrato(self):
        c = self.nuevo(rangos=[rango()])
        await c.manual("arm")
        m = self.enviados[-1]
        self.assertEqual((m["type"], m["armed"], m["reason"]), ("kit.armed", True, "manual"))
        self.assertEqual(m["ts"], int(cr("2026-11-23 15:00").timestamp() * 1000))
        seqs = [x["seq"] for x in self.enviados]
        await c.manual("disarm")
        self.assertEqual([x["seq"] for x in self.enviados][:len(seqs)], seqs)
        self.assertGreater(self.enviados[-1]["seq"], seqs[-1])

    async def test_orden_manual_invalida(self):
        c = self.nuevo()
        with self.assertRaises(ErrorHorario):
            await c.manual("encender")
        self.assertEqual(c.estado(), (False, "none"))

    async def test_rangos_malos_no_cambian_los_que_habia(self):
        c = self.nuevo(rangos=[rango()])
        with self.assertRaises(ErrorHorario):
            c.set_rangos([rango("a"), rango("b")])
        self.assertEqual(len(c.rangos()), 1)

    async def test_cambiar_los_rangos_recalcula_el_vencimiento_del_manual(self):
        c = self.nuevo(rangos=[rango()])
        await c.manual("arm")                           # Lunes 15:00, vence a las 20:00.
        c.set_rangos([rango(start="16:00", end="17:00")])
        self.reloj.t = cr("2026-11-23 16:00")
        self.assertEqual(c.estado(), (True, "schedule"))

    async def test_el_mensaje_kit_armed_tiene_la_forma_del_contrato(self):
        c = self.nuevo()
        await c.manual("arm")
        m = self.enviados[0]
        self.assertEqual(set(m), {"v", "type", "armed", "reason", "seq", "ts"})
        self.assertIn(m["reason"], ("schedule", "manual", "none"))


class PruebasAlertas(unittest.IsolatedAsyncioTestCase):
    def nuevo(self, inicio="2026-11-23 22:00", armado=True):
        self.reloj = Reloj(inicio)
        self.salida = []
        self.falla = False

        async def enviar(metodo, datos):
            if self.falla:
                raise ConnectionError("sin red")
            self.salida.append((metodo, datos))

        async def nada(_m):
            pass
        self.c = ControlKit(self.reloj, nada)
        self.c.set_rangos([rango()])
        self.a = Alertas(self.c, enviar, self.reloj, "CHAT-DE-PRUEBA")
        return self.a

    def evento(self, n=1, sev="critical", tipo="DOOR_OPENED", foto="ok"):
        ev = {"event_id": "e-%d" % n, "event_type": tipo, "severity": sev,
              "occurred_at": "2026-11-23T22:00:00-06:00", "baby_id": "B", "device_id": "D", "photo": None}
        if foto == "ok":
            ev["photo"] = {"url_signed": "https://ejemplo.invalid/f?firma=X", "expires_at": "2026-11-23T22:10:00-06:00"}
        elif foto == "vencida":
            ev["photo"] = {"url_signed": "https://ejemplo.invalid/f?firma=X", "expires_at": "2026-11-23T21:00:00-06:00"}
        return ev

    async def test_toda_alerta_sale_silenciosa(self):
        a = self.nuevo()
        for i, f in enumerate(("ok", None, "vencida")):
            r = await a.procesar(self.evento(i, foto=f))
            self.assertTrue(r["enviado"], r)
        self.assertEqual(len(self.salida), 3)
        for metodo, datos in self.salida:
            self.assertIs(datos["disable_notification"], True)
            self.assertEqual(datos["chat_id"], "CHAT-DE-PRUEBA")

    async def test_con_foto_usa_sendPhoto_y_sin_foto_sendMessage(self):
        a = self.nuevo()
        await a.procesar(self.evento(1, foto="ok"))
        await a.procesar(self.evento(2, foto=None))
        self.assertEqual([m for m, _ in self.salida], ["sendPhoto", "sendMessage"])
        self.assertTrue(self.salida[0][1]["photo"].startswith("https://"))

    async def test_foto_vencida_se_trata_como_sin_foto(self):
        a = self.nuevo()
        r = await a.procesar(self.evento(1, foto="vencida"))
        self.assertTrue(r["enviado"])
        self.assertFalse(r["con_foto"])
        self.assertEqual(self.salida[0][0], "sendMessage")

    async def test_foto_con_url_malo_no_se_manda(self):
        a = self.nuevo()
        ev = self.evento(1)
        ev["photo"]["url_signed"] = "javascript:alert(1)"
        await a.procesar(ev)
        self.assertEqual(self.salida[0][0], "sendMessage")

    async def test_segundo_mensaje_cuando_la_foto_esta_lista(self):
        a = self.nuevo()
        await a.procesar(self.evento(1, foto=None))
        foto = {"url_signed": "https://ejemplo.invalid/f?firma=Y", "expires_at": "2026-11-23T22:10:00-06:00"}
        r = await a.foto_lista("e-1", foto)
        self.assertTrue(r["enviado"])
        self.assertEqual([m for m, _ in self.salida], ["sendMessage", "sendPhoto"])
        self.assertIs(self.salida[1][1]["disable_notification"], True)
        r2 = await a.foto_lista("e-1", foto)                  # No se repite.
        self.assertFalse(r2["enviado"])
        self.assertEqual(len(self.salida), 2)

    async def test_foto_lista_sin_alerta_previa_o_vencida(self):
        a = self.nuevo()
        foto = {"url_signed": "https://ejemplo.invalid/f", "expires_at": "2026-11-23T22:10:00-06:00"}
        self.assertEqual((await a.foto_lista("e-9", foto))["motivo"], "SIN_ALERTA_PREVIA")
        await a.procesar(self.evento(1, foto=None))
        self.reloj.avanzar(minutes=30)
        self.assertEqual((await a.foto_lista("e-1", foto))["motivo"], "FOTO_VENCIDA")

    async def test_fuera_de_la_ventana_no_hay_alerta(self):
        a = self.nuevo("2026-11-23 12:00")
        r = await a.procesar(self.evento(1))
        self.assertEqual((r["enviado"], r["motivo"]), (False, "KIT_DESARMADO"))
        self.assertEqual(self.salida, [])

    async def test_el_boton_manual_manda_sobre_la_ventana(self):
        a = self.nuevo("2026-11-23 22:00")
        await self.c.manual("disarm")
        self.assertEqual((await a.procesar(self.evento(1)))["motivo"], "KIT_DESARMADO")
        await self.c.manual("arm")
        self.assertTrue((await a.procesar(self.evento(2)))["enviado"])

    async def test_foto_lista_tampoco_sale_si_el_kit_se_desarmo(self):
        a = self.nuevo()
        await a.procesar(self.evento(1, foto=None))
        await self.c.manual("disarm")
        foto = {"url_signed": "https://ejemplo.invalid/f", "expires_at": "2026-11-23T22:10:00-06:00"}
        self.assertEqual((await a.foto_lista("e-1", foto))["motivo"], "KIT_DESARMADO")

    async def test_solo_warning_y_critical_alertan(self):
        a = self.nuevo()
        self.assertEqual((await a.procesar(self.evento(1, sev="info")))["motivo"], "SEVERIDAD_NO_ALERTA")
        self.assertTrue((await a.procesar(self.evento(2, sev="warning")))["enviado"])
        self.assertTrue((await a.procesar(self.evento(3, sev="critical")))["enviado"])
        self.assertEqual(len(self.salida), 2)

    async def test_el_mismo_evento_no_alerta_dos_veces(self):
        a = self.nuevo()
        await a.procesar(self.evento(1))
        self.assertEqual((await a.procesar(self.evento(1)))["motivo"], "REPETIDO")
        self.assertEqual(len(self.salida), 1)

    async def test_si_telegram_falla_no_se_pierde_y_se_puede_reintentar(self):
        a = self.nuevo()
        self.falla = True
        r = await a.procesar(self.evento(1))
        self.assertEqual(r["motivo"], "ERROR_ENVIO")
        self.falla = False
        self.assertTrue((await a.procesar(self.evento(1)))["enviado"])

    async def test_eventos_incompletos(self):
        a = self.nuevo()
        for ev in ({}, {"event_id": "x"}, {"event_id": "e", "event_type": "T", "severity": "critical"},
                   {"event_id": 5, "event_type": "T", "severity": "critical", "occurred_at": "x"}):
            self.assertEqual((await a.procesar(ev))["motivo"], "EVENTO_INVALIDO")
        self.assertEqual(self.salida, [])

    async def test_menos_de_2_segundos_con_un_telegram_lento_simulado(self):
        a = self.nuevo()
        t = {"v": 0.0}

        async def lento(metodo, datos):
            t["v"] += 0.35                                         # Telegram tarda 350 ms.
        a._enviar = lento
        marcas = iter([self.reloj.t, self.reloj.t + timedelta(seconds=0.35)])
        a._ahora = lambda: next(marcas, self.reloj.t)
        r = await a.procesar(self.evento(1))
        self.assertTrue(r["enviado"])
        self.assertLess(r["demora_s"], 2.0)

    async def test_textos_largos_se_cortan_a_los_limites_de_telegram(self):
        a = self.nuevo()
        ev = self.evento(1, foto=None, tipo="X" * 6000)
        await a.procesar(ev)
        self.assertLessEqual(len(self.salida[0][1]["text"]), LIMITE_TEXTO)
        ev = self.evento(2, tipo="Y" * 3000)
        await a.procesar(ev)
        self.assertLessEqual(len(self.salida[1][1]["caption"]), LIMITE_PIE)

    async def test_el_mensaje_no_lleva_ids_del_bebe(self):
        a = self.nuevo()
        await a.procesar(self.evento(1, foto=None))
        texto = self.salida[0][1]["text"]
        self.assertNotIn("baby", texto.lower())
        self.assertNotIn("UUID", texto)


if __name__ == "__main__":
    unittest.main()
