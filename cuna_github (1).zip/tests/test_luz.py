import asyncio
import os
import sys
import unittest

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from hal.luz import Luz, duty_para_brillo


class PWMFalso:
    """Imita machine.PWM. Guarda lo que se le pidió."""
    def __init__(self):
        self.frecuencia = None
        self.historial = []

    def freq(self, f=None):
        self.frecuencia = f

    def duty_u16(self, v):
        self.historial.append(v)


class PruebasDuty(unittest.TestCase):
    def test_extremos(self):
        self.assertEqual(duty_para_brillo(0), 0)
        self.assertEqual(duty_para_brillo(100), 65535)

    def test_crece_y_queda_en_rango(self):
        anterior = -1
        for b in range(0, 101):
            d = duty_para_brillo(b)
            self.assertTrue(0 <= d <= 65535)
            self.assertGreaterEqual(d, anterior)
            anterior = d

    def test_curva_deja_medio_por_debajo_de_lineal(self):
        self.assertLess(duty_para_brillo(50), 32768)


class PruebasLuz(unittest.IsolatedAsyncioTestCase):
    def nueva(self):
        pwm = PWMFalso()
        return Luz(pwm, frecuencia=1000, brillo_defecto=30, paso_ms=5), pwm

    async def test_arranca_apagada_con_frecuencia(self):
        luz, pwm = self.nueva()
        self.assertEqual(pwm.frecuencia, 1000)
        self.assertEqual(pwm.historial[-1], 0)
        self.assertEqual(luz.estado(), (False, 0))

    async def test_encender_con_brillo(self):
        luz, pwm = self.nueva()
        await luz.ir_a(True, 40, 0)
        self.assertEqual(luz.estado(), (True, 40))
        self.assertEqual(pwm.historial[-1], duty_para_brillo(40))

    async def test_encender_sin_brillo_usa_el_defecto_y_luego_el_ultimo(self):
        luz, pwm = self.nueva()
        await luz.ir_a(True, None, 0)
        self.assertEqual(luz.estado(), (True, 30))
        await luz.ir_a(True, 70, 0)
        await luz.ir_a(False, None, 0)
        self.assertEqual(luz.estado(), (False, 0))
        await luz.ir_a(True, None, 0)
        self.assertEqual(luz.estado(), (True, 70))

    async def test_encender_con_brillo_cero_queda_apagada(self):
        luz, pwm = self.nueva()
        await luz.ir_a(True, 0, 0)
        self.assertEqual(luz.estado(), (False, 0))

    async def test_fade_pasa_por_valores_intermedios_y_termina_exacto(self):
        luz, pwm = self.nueva()
        await luz.ir_a(True, 100, 50)
        intermedios = [d for d in pwm.historial if 0 < d < 65535]
        self.assertGreater(len(intermedios), 3)
        self.assertEqual(pwm.historial[-1], 65535)

    async def test_fade_cancelado_deja_la_luz_a_medias_sin_romper(self):
        luz, pwm = self.nueva()
        tarea = asyncio.create_task(luz.ir_a(True, 100, 500))
        await asyncio.sleep(0.05)
        tarea.cancel()
        with self.assertRaises(asyncio.CancelledError):
            await tarea
        self.assertTrue(0 < luz._actual < 100)
        await luz.ir_a(False, None, 0)
        self.assertEqual(pwm.historial[-1], 0)


if __name__ == "__main__":
    unittest.main()
