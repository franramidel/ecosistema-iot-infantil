# Luz de noche. Maneja el brillo por PWM.
# Circuito propuesto: GP18 -> 1 kOhm -> base del 2N3904. El LED va en el colector.
# Con PWM alto la luz prende. Por eso el duty no se invierte.

import asyncio

import config


def duty_para_brillo(brillo, curva=config.LUZ_CURVA):
    """Convierte brillo de 0 a 100 en duty de 0 a 65535 con una curva."""
    if brillo <= 0:
        return 0
    if brillo >= 100:
        return 65535
    return int(((brillo / 100) ** curva) * 65535)


class Luz:
    def __init__(self, pwm, frecuencia=config.LUZ_FRECUENCIA_HZ,
                 brillo_defecto=config.LUZ_BRILLO_DEFECTO,
                 paso_ms=config.LUZ_PASO_FADE_MS):
        # pwm es un objeto como machine.PWM. Se inyecta para poder probarlo sin hardware.
        self._pwm = pwm
        self._pwm.freq(frecuencia)
        self._paso_ms = paso_ms
        self._actual = 0.0              # Brillo real en este momento, puede tener decimales.
        self.objetivo = 0               # Brillo al que va o en el que quedó.
        self.ultimo_brillo = brillo_defecto  # Brillo que se recuerda al apagar.
        self._escribir(0)

    def _escribir(self, brillo):
        self._actual = brillo
        self._pwm.duty_u16(duty_para_brillo(brillo))

    def estado(self):
        """Devuelve on y brillo objetivo. Apagada se reporta con brillo 0."""
        return self.objetivo > 0, self.objetivo

    def calcular_objetivo(self, encender, brillo):
        """Decide el brillo final. No mueve la luz."""
        if encender:
            if brillo is None:
                brillo = self.ultimo_brillo
            if brillo > 0:
                self.ultimo_brillo = brillo
            return brillo  # Encender con brillo 0 deja la luz apagada.
        if brillo is not None and brillo > 0:
            self.ultimo_brillo = brillo
        return 0

    async def ir_a(self, encender, brillo=None, fade_ms=config.LUZ_FADE_DEFECTO_MS):
        """Cambia la luz con una transición suave."""
        destino = self.calcular_objetivo(encender, brillo)
        self.objetivo = destino
        inicio = self._actual
        if fade_ms <= 0 or inicio == destino:
            self._escribir(destino)
            return
        pasos = max(1, fade_ms // self._paso_ms)
        for i in range(1, pasos + 1):
            await asyncio.sleep(self._paso_ms / 1000)
            self._escribir(inicio + (destino - inicio) * i / pasos)
        self._escribir(destino)  # Cierra exacto en el destino.
