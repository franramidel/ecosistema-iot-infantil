# Salida de audio por I2S hacia el DAC PCM5102A.
# La salida se abre al empezar a sonar y se cierra al terminar. Así BCK y LRCK se detienen
# cuando no hay audio. Según la hoja del PCM5102A, el chip entra en ahorro de energía si
# se detienen. La documentación de MicroPython no dice qué pasa con la salida si el búfer
# se vacía, por eso no se deja el I2S corriendo sin datos.

import asyncio

import config


class SalidaI2S:
    def __init__(self, bck=config.PIN_I2S_BCK, lrck=config.PIN_I2S_LRCK,
                 datos=config.PIN_I2S_DATOS, rate=config.AUDIO_RATE_HZ,
                 ibuf=config.AUDIO_IBUF_BYTES):
        self._pines = (bck, lrck, datos)
        self._rate = rate
        self._ibuf = ibuf
        self._i2s = None
        self._sw = None

    def abrir(self):
        if self._i2s is not None:
            return
        from machine import I2S, Pin
        bck, lrck, datos = self._pines
        # MONO escribe la misma muestra en los canales izquierdo y derecho.
        self._i2s = I2S(0, sck=Pin(bck), ws=Pin(lrck), sd=Pin(datos), mode=I2S.TX,
                        bits=16, format=I2S.MONO, rate=self._rate, ibuf=self._ibuf)
        self._sw = asyncio.StreamWriter(self._i2s)

    async def escribir(self, buf):
        self._sw.write(buf)
        await self._sw.drain()

    def cerrar(self):
        if self._i2s is not None:
            self._i2s.deinit()
            self._i2s = None
            self._sw = None
