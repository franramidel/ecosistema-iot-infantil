# Micrófono. Lee el ADC a 8 kHz con un temporizador y entrega tramas de 20 ms.
# La cápsula de electret va a un amplificador con sesgo a mitad de escala, y de ahí a GP26.
# El micrófono está APAGADO por defecto. El temporizador solo corre entre iniciar y detener.
#
# Importante. MicroPython no tiene ADC por DMA. Esta lectura depende de que el temporizador
# alcance los 8 kHz con el Wi-Fi activo. Eso NO está probado. Por eso se cuenta cuántas
# lecturas se hicieron de verdad y se reporta en hz_real.

import array
import asyncio

import config

try:
    import micropython
    _rapido = micropython.viper
except ImportError:
    # En una PC normal no existe viper. Se usa el mismo código sin compilar.
    def _rapido(f):
        return f

    def ptr16(obj):
        return memoryview(obj).cast("B").cast("H")

    def ptr32(obj):
        return memoryview(obj).cast("B").cast("i")


@_rapido
def _procesar(src, dst, n: int, estado, ganancia: int):
    # Pasa lecturas sin signo de 16 bits a PCM de 16 bits con signo.
    # Quita el nivel de continua con un promedio lento, con 8 bits de decimales.
    # La documentación no dice si ptr16 tiene signo. Por eso se enmascara a mano.
    s = ptr16(src)
    d = ptr16(dst)
    e = ptr32(estado)
    dc = int(e[0])
    for i in range(n):
        x = (int(s[i]) & 0xFFFF) - 32768
        dc += ((x << 8) - dc) >> 9
        y = ((x - (dc >> 8)) * ganancia) >> 8
        if y > 32767:
            y = 32767
        if y < -32768:
            y = -32768
        d[i] = y & 0xFFFF
    e[0] = dc


class ErrorMic(Exception):
    pass


class Microfono:
    def __init__(self, adc, crear_timer, periodico, crear_flag, reloj_ms,
                 rate=config.MIC_RATE_HZ, muestras=config.MIC_MUESTRAS_TRAMA,
                 nbufs=config.MIC_BUFS, ganancia=config.MIC_GANANCIA_Q8):
        self._adc = adc
        self._crear_timer = crear_timer
        self._periodico = periodico
        self._flag = crear_flag()
        self._reloj_ms = reloj_ms
        self._rate = rate
        self._n = muestras
        self._nb = nbufs
        self._ganancia = ganancia
        # Se crean con una lista. Con bytes, MicroPython y Python normal leen distinto.
        self._bufs = [array.array("H", [0] * muestras) for _ in range(nbufs)]
        self._estado = array.array("i", [0])
        self._timer = None
        self._cb = self._tick      # Se crea una vez. El callback no puede pedir memoria.
        self._w = 0
        self._r = 0
        self._i = 0
        self._cuenta = 0
        self._t0 = 0
        self.perdidas = 0

    @property
    def activo(self):
        return self._timer is not None

    def iniciar(self):
        if self._timer is not None:
            return
        try:
            self._adc.read_u16()    # Si el ADC falla, que falle aquí y no dentro del temporizador.
        except Exception as e:
            raise ErrorMic("el ADC no responde: %r" % (e,))
        self._w = self._r = self._i = self._cuenta = 0
        self.perdidas = 0
        self._estado[0] = 0
        self._flag.clear()
        self._t0 = self._reloj_ms()
        self._timer = self._crear_timer()
        self._timer.init(mode=self._periodico, freq=self._rate, callback=self._cb)

    def detener(self):
        if self._timer is not None:
            self._timer.deinit()
            self._timer = None

    def _tick(self, _t):
        # Corre en el temporizador. Sin crear objetos ni números grandes.
        self._bufs[self._w][self._i] = self._adc.read_u16()
        self._i += 1
        self._cuenta += 1
        if self._i >= self._n:
            self._i = 0
            sig = self._w + 1
            if sig >= self._nb:
                sig = 0
            if sig == self._r:
                self.perdidas += 1   # El anillo está lleno. Se pierde la trama nueva.
            else:
                self._w = sig
                self._flag.set()

    def hz_real(self):
        """Lecturas por segundo desde que se inició. Mide lo que de verdad hizo el ADC."""
        if self._timer is None:
            return 0
        ms = self._reloj_ms() - self._t0
        if ms <= 0:
            return 0
        return self._cuenta * 1000 // ms

    async def siguiente_trama(self):
        """Espera una trama lista y la devuelve como PCM de 16 bits, bytearray."""
        while True:
            if self._r != self._w:
                salida = bytearray(2 * self._n)
                _procesar(self._bufs[self._r], salida, self._n, self._estado, self._ganancia)
                self._r = (self._r + 1) % self._nb
                return salida
            await self._flag.wait()


def crear_microfono():
    """Arma el micrófono real. Solo se llama en la Pico."""
    import time
    from machine import ADC, Pin, Timer
    return Microfono(ADC(Pin(config.PIN_MIC_ADC)), lambda: Timer(-1), Timer.PERIODIC,
                     asyncio.ThreadSafeFlag, time.ticks_ms)
