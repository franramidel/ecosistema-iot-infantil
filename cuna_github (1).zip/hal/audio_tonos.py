# Salida de audio por PWM, sin DAC. Toca las nanas como notas sueltas.
# Cómo funciona: cada trama de 20 ms de la nana, que ya viene escalada por el volumen, se analiza.
# Se mide su frecuencia contando cruces por cero y su pico. Con eso se pone la frecuencia del
# PWM y su ciclo de trabajo. Solo sirve para melodías de una sola nota a la vez.
# Documentación de PWM: https://docs.micropython.org/en/latest/library/machine.PWM.html
# La documentación no da el rango de frecuencias en rp2 ni dice cómo comparten frecuencia las
# dos salidas de un bloque. Por eso este pin queda solo para audio.
# Estado: IMPLEMENTADO NO PROBADO EN HARDWARE.

import asyncio
import struct

import config


def estimar_tono(buf, n_muestras, rate=config.AUDIO_RATE_HZ):
    """Devuelve (frecuencia en Hz o 0, pico) de una trama PCM de 16 bits con signo.
    Cuenta cruces por cero hacia arriba, con interpolación entre muestras."""
    if n_muestras < 4:
        return 0, 0
    s = struct.unpack_from("<%dh" % n_muestras, buf, 0)
    pico = max(max(s), -min(s))
    if pico < config.AUDIO_TONO_PICO_MIN:
        return 0, pico
    primero = ultimo = None
    cruces = 0
    previo = s[0]
    for i in range(1, n_muestras):
        actual = s[i]
        if previo < 0 and actual >= 0:
            pos = (i - 1) + (-previo) / (actual - previo)
            if primero is None:
                primero = pos
            ultimo = pos
            cruces += 1
        previo = actual
    if cruces < 2 or ultimo <= primero:
        return 0, pico
    return (cruces - 1) * rate / (ultimo - primero), pico


class SalidaTonos:
    solo_tonos = True      # El gestor de audio lo mira para rechazar lo que no puede tocar.

    def __init__(self, pin=config.PIN_PWM_AUDIO, crear_pwm=None):
        self._pin = pin
        self._crear = crear_pwm      # Para pruebas. En la Pico se importa machine.
        self._pwm = None
        self._freq = 0

    def abrir(self):
        if self._pwm is not None:
            return
        if self._crear is not None:
            self._pwm = self._crear(self._pin)
        else:
            from machine import PWM, Pin
            self._pwm = PWM(Pin(self._pin), freq=1000, duty_u16=0)
        self._freq = 0

    async def escribir(self, buf):
        n = len(buf) // 2
        freq, pico = estimar_tono(buf, n)
        pwm = self._pwm
        if freq and config.AUDIO_TONO_MIN_HZ <= freq <= config.AUDIO_TONO_MAX_HZ:
            if abs(freq - self._freq) > 2:
                pwm.freq(int(freq))
                self._freq = freq
            frac = min(config.AUDIO_TONO_DUTY_MAX, pico / 32768 * config.AUDIO_TONO_ESCALA)
            pwm.duty_u16(int(frac * 65535))
        else:
            pwm.duty_u16(0)
        await asyncio.sleep(config.AUDIO_TRAMA_MS / 1000)

    def cerrar(self):
        if self._pwm is not None:
            self._pwm.duty_u16(0)
            self._pwm.deinit()
            self._pwm = None
