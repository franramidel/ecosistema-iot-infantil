# SCRUM-45: estado armado o desarmado del kit, con ventanas y botón manual.
# Esta clase decide. No guarda en base de datos: Jan Carlo conecta su almacenamiento
# con set_rangos y con los métodos que devuelven el estado.
# El kit es de otro integrante. El mensaje kit.armed es una PROPUESTA a acordar con él.

import time

from servidor.horarios import (ErrorHorario, en_ventana, siguiente_cambio, validar_rangos)


class ControlKit:
    def __init__(self, ahora, enviar=None):
        """ahora() devuelve un datetime con zona. enviar(msg) es async y manda el mensaje al kit."""
        self._ahora = ahora
        self._enviar = enviar
        self._rangos = []
        self._manual = None          # (armado, desde) o None.
        self._ultimo = None          # Último (armado, razón) que se mandó.
        self._seq = 0

    def rangos(self):
        return list(self._rangos)

    def set_rangos(self, lista):
        """Reemplaza todos los rangos o falla sin cambiar nada. Lanza ErrorHorario."""
        self._rangos = validar_rangos(lista)

    def estado(self, momento=None):
        """Devuelve (armado, razón). razón es schedule, manual o none."""
        momento = momento or self._ahora()
        if self._manual is not None:
            armado, desde = self._manual
            hasta = siguiente_cambio(self._rangos, desde)
            if hasta is None or momento < hasta:
                return armado, "manual"
            self._manual = None                     # La orden manual ya venció.
        if not any(n[4] for n in self._rangos):
            return False, "none"
        return en_ventana(self._rangos, momento), "schedule"

    def armado(self, momento=None):
        return self.estado(momento)[0]

    async def manual(self, accion):
        """Orden del botón de la app. accion es arm o disarm. Actúa al instante."""
        if accion not in ("arm", "disarm"):
            raise ErrorHorario("INVALID_RANGE", "action debe ser arm o disarm")
        self._manual = (accion == "arm", self._ahora())
        await self.revisar()
        return self.estado()

    async def revisar(self, forzar=False):
        """Manda kit.armed si el estado cambió, o siempre si forzar es verdadero.
        Se llama en cada tick, tras cada cambio, y con forzar al reconectar el kit."""
        estado = self.estado()
        if estado == self._ultimo and not forzar:
            return False
        self._ultimo = estado
        if self._enviar is None:
            return True
        self._seq += 1
        await self._enviar({"v": 1, "type": "kit.armed", "armed": estado[0], "reason": estado[1],
                            "seq": self._seq, "ts": int(self._ahora().timestamp() * 1000)})
        return True
