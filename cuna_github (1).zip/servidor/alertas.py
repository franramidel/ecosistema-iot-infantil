# SCRUM-44: alertas silenciosas por Telegram, con la foto como enlace.
# NO crea un bot nuevo. Usa el bot de SCRUM-24 que entrega Jan Carlo, detrás de la
# interfaz enviar(metodo, datos). Aquí nunca se manda nada real a Telegram.
# Reglas verificadas en https://core.telegram.org/bots/api :
#   sendMessage y sendPhoto aceptan disable_notification, que manda el aviso sin sonido.
#   sendMessage admite hasta 4096 caracteres. El pie de foto de sendPhoto, hasta 1024.
#   sendPhoto acepta un URL http como cadena, de hasta 10 MB.
# El silencio final en el teléfono depende del teléfono y de la app de Telegram.

from datetime import datetime

SEVERIDADES = ("warning", "critical")
LIMITE_TEXTO = 4096
LIMITE_PIE = 1024

TITULOS = {
    "DOOR_OPENED": "Se abrió la puerta",
    "WEIGHT_DROP": "Bajó el peso de golpe",
    "TEMP_OUT_OF_RANGE": "Temperatura fuera de rango",
}


def _cortar(texto, limite):
    return texto if len(texto) <= limite else texto[:limite - 1] + "…"


def texto_alerta(ev):
    """Texto corto, sin datos del bebé más allá del evento."""
    titulo = TITULOS.get(ev["event_type"], ev["event_type"])
    marca = "CRÍTICO" if ev["severity"] == "critical" else "Aviso"
    return "%s: %s\nHora: %s" % (marca, titulo, ev["occurred_at"])


class Alertas:
    def __init__(self, control, enviar, ahora, chat_id):
        """control: ControlKit. enviar(metodo, datos): async, del bot de SCRUM-24.
        chat_id: la cuenta de Telegram vinculada, que entrega Jan Carlo."""
        self._control = control
        self._enviar = enviar
        self._ahora = ahora
        self._chat = chat_id
        self._hechos = set()          # Alertas ya mandadas, por event_id.
        self._con_foto = set()        # Eventos cuya foto ya salió.
        self._sin_foto = {}           # event_id -> evento que salió sin foto.

    def _evento_valido(self, ev):
        for k in ("event_id", "event_type", "severity", "occurred_at"):
            if not isinstance(ev.get(k), str) or not ev[k]:
                return "falta " + k
        return None

    async def procesar(self, ev):
        """Maneja un evento del kit. Devuelve un diccionario con lo que pasó.
        Fuera de la ventana activa no se manda nada, como pide SCRUM-45 CA2."""
        error = self._evento_valido(ev)
        if error:
            return {"enviado": False, "motivo": "EVENTO_INVALIDO", "detalle": error}
        if ev["severity"] not in SEVERIDADES:
            return {"enviado": False, "motivo": "SEVERIDAD_NO_ALERTA"}
        if ev["event_id"] in self._hechos:
            return {"enviado": False, "motivo": "REPETIDO"}
        if not self._control.armado():
            return {"enviado": False, "motivo": "KIT_DESARMADO"}
        inicio = self._ahora()
        foto = ev.get("photo")
        if foto and self._foto_vencida(foto):
            foto = None
        try:
            if foto:
                await self._mandar_foto(ev, foto)
                self._con_foto.add(ev["event_id"])
            else:
                await self._enviar("sendMessage", {"chat_id": self._chat, "text": _cortar(texto_alerta(ev), LIMITE_TEXTO),
                                                   "disable_notification": True})
                if not ev.get("photo"):
                    self._sin_foto[ev["event_id"]] = ev
        except Exception as e:
            return {"enviado": False, "motivo": "ERROR_ENVIO", "detalle": str(e)}
        self._hechos.add(ev["event_id"])
        demora = (self._ahora() - inicio).total_seconds()
        return {"enviado": True, "con_foto": bool(foto), "demora_s": demora}

    async def foto_lista(self, event_id, foto):
        """La foto terminó de subirse después de la alerta. Se manda un segundo mensaje, también silencioso."""
        ev = self._sin_foto.get(event_id)
        if ev is None:
            return {"enviado": False, "motivo": "SIN_ALERTA_PREVIA" if event_id not in self._con_foto else "REPETIDO"}
        if not self._control.armado():
            return {"enviado": False, "motivo": "KIT_DESARMADO"}
        if not foto or self._foto_vencida(foto):
            return {"enviado": False, "motivo": "FOTO_VENCIDA"}
        try:
            await self._mandar_foto(ev, foto)
        except Exception as e:
            return {"enviado": False, "motivo": "ERROR_ENVIO", "detalle": str(e)}
        del self._sin_foto[event_id]
        self._con_foto.add(event_id)
        return {"enviado": True, "con_foto": True}

    def _foto_vencida(self, foto):
        """True si el URL firmado ya expiró o no tiene datos válidos."""
        if not isinstance(foto, dict) or not isinstance(foto.get("url_signed"), str):
            return True
        if not foto["url_signed"].startswith(("https://", "http://")):
            return True
        try:
            return datetime.fromisoformat(foto["expires_at"]) <= self._ahora()
        except (KeyError, TypeError, ValueError):
            return True

    async def _mandar_foto(self, ev, foto):
        await self._enviar("sendPhoto", {"chat_id": self._chat, "photo": foto["url_signed"],
                                         "caption": _cortar(texto_alerta(ev), LIMITE_PIE),
                                         "disable_notification": True})
