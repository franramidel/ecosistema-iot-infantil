# SCRUM-45: ventanas horarias. Lógica pura, sin red ni base de datos.
# Zona America/Costa_Rica, UTC-6 fijo, sin horario de verano.
# Contrato: CONTRATO.md sección 14. Todo PROPUESTO, pendiente de aprobar con Jan Carlo.

from datetime import datetime, timedelta, timezone

ZONA_CR = timezone(timedelta(hours=-6))
MIN_DIA = 24 * 60
MIN_SEMANA = 7 * MIN_DIA


class ErrorHorario(ValueError):
    """Error de rangos con un código del contrato en self.codigo."""

    def __init__(self, codigo, detalle=""):
        ValueError.__init__(self, "%s %s" % (codigo, detalle))
        self.codigo = codigo
        self.detalle = detalle


def _minutos(texto):
    """Convierte 'HH:MM' en minutos desde medianoche. Falla si el formato no es exacto."""
    if not isinstance(texto, str) or len(texto) != 5 or texto[2] != ":":
        raise ErrorHorario("INVALID_RANGE", "hora inválida: %r" % (texto,))
    h, m = texto[:2], texto[3:]
    if not (h.isdigit() and m.isdigit()):
        raise ErrorHorario("INVALID_RANGE", "hora inválida: %r" % (texto,))
    h, m = int(h), int(m)
    if h > 23 or m > 59:
        raise ErrorHorario("INVALID_RANGE", "hora fuera de rango: %r" % (texto,))
    return h * 60 + m


def validar_rango(r):
    """Revisa un rango. Devuelve (id, dias, inicio_min, fin_min, activo)."""
    if not isinstance(r, dict):
        raise ErrorHorario("INVALID_RANGE", "el rango no es un objeto")
    sid = r.get("schedule_id")
    if not isinstance(sid, str) or not sid:
        raise ErrorHorario("INVALID_RANGE", "falta schedule_id")
    dias = r.get("days")
    if (not isinstance(dias, list) or not dias or len(set(dias)) != len(dias)
            or any(type(d) is not int or d < 1 or d > 7 for d in dias)):
        raise ErrorHorario("INVALID_RANGE", "days debe ser una lista sin repetir de 1 a 7")
    ini, fin = _minutos(r.get("start")), _minutos(r.get("end"))
    if ini == fin:
        raise ErrorHorario("INVALID_RANGE", "start y end no pueden ser iguales")
    activo = r.get("enabled", True)
    if type(activo) is not bool:
        raise ErrorHorario("INVALID_RANGE", "enabled debe ser verdadero o falso")
    return sid, sorted(dias), ini, fin, activo


def _intervalos(dias, ini, fin):
    """Intervalos [a, b) en minutos de la semana, contando desde el lunes a las 00:00.
    Si el rango cruza la medianoche, el día que cuenta es el de inicio."""
    largo = (fin - ini) % MIN_DIA
    return [((d - 1) * MIN_DIA + ini, (d - 1) * MIN_DIA + ini + largo) for d in dias]


def _se_solapan(a, b):
    """Dos intervalos [a0, a1) y [b0, b1) sobre una semana que se repite. El fin no entra."""
    for desplazo in (-MIN_SEMANA, 0, MIN_SEMANA):
        if a[0] < b[1] + desplazo and b[0] + desplazo < a[1]:
            return True
    return False


def validar_rangos(rangos):
    """Valida todos los rangos. Devuelve la lista normalizada. Los desactivados no se comparan."""
    if not isinstance(rangos, list):
        raise ErrorHorario("INVALID_RANGE", "los rangos deben ser una lista")
    normales, ids = [], set()
    for r in rangos:
        n = validar_rango(r)
        if n[0] in ids:
            raise ErrorHorario("INVALID_RANGE", "schedule_id repetido: " + n[0])
        ids.add(n[0])
        normales.append(n)
    activos = [(n[0], _intervalos(n[1], n[2], n[3])) for n in normales if n[4]]
    for i in range(len(activos)):
        for j in range(i + 1, len(activos)):
            for a in activos[i][1]:
                for b in activos[j][1]:
                    if _se_solapan(a, b):
                        raise ErrorHorario("SCHEDULE_OVERLAP", "%s con %s" % (activos[i][0], activos[j][0]))
    return normales


def _a_cr(momento):
    if momento.tzinfo is None:
        raise ValueError("la hora debe traer zona horaria")
    return momento.astimezone(ZONA_CR)


def _min_semana(momento):
    c = _a_cr(momento)
    return c.weekday() * MIN_DIA + c.hour * 60 + c.minute


def _intervalos_activos(normales):
    return [i for n in normales if n[4] for i in _intervalos(n[1], n[2], n[3])]


def en_ventana(normales, momento):
    """True si el momento cae dentro de alguna ventana activa. El inicio entra, el fin no."""
    t = _min_semana(momento)
    for a, b in _intervalos_activos(normales):
        if a <= t < b or a <= t + MIN_SEMANA < b:
            return True
    return False


def siguiente_cambio(normales, momento):
    """Primer instante, después de momento, en que empieza o termina una ventana activa.
    Devuelve None si no hay ventanas activas."""
    ivs = _intervalos_activos(normales)
    if not ivs:
        return None
    c = _a_cr(momento).replace(second=0, microsecond=0)
    t = _min_semana(momento)
    puntos = set()
    for a, b in ivs:
        puntos.add(a % MIN_SEMANA)
        puntos.add(b % MIN_SEMANA)
    mejor = min(((p - t - 1) % MIN_SEMANA) + 1 for p in puntos)       # Minutos hasta el siguiente.
    return c + timedelta(minutes=mejor)
