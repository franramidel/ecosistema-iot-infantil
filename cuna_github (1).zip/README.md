# Cuna inteligente, Ecosistema IoT Infantil

Firmware y herramientas de la cuna para el curso Principios de Modelado del TEC. Es una maqueta de bajo costo con una Raspberry Pi Pico 2 W y MicroPython 1.29.0.

## Qué hace

Luz de noche con brillo regulable por PWM, nanas por un parlante y voz por turnos con la app. Todo va por una sola conexión WebSocket con mensajes JSON y audio binario. Historias: SCRUM-29, SCRUM-30 y SCRUM-31 parte A. El módulo de SCRUM-44 y SCRUM-45 vive en la carpeta servidor.

## Estado, con honestidad

El código está completo y las 229 pruebas pasan. Todas usan hardware falso y un servidor simulado. Nada se ha probado en una Pico. El contrato de mensajes es una propuesta y Jan Carlo todavía no lo aprueba. La lista de pruebas pendientes en hardware está en docs/07_ETAPA6_pruebas_y_criterios.md.

## Carpetas

| Carpeta | Para qué sirve | ¿Va a la Pico? |
| --- | --- | --- |
| hal, protocolo, servicios, assets | El firmware | Sí |
| config.py, main.py, secrets.py | Configuración y arranque | Sí |
| servidor | Lógica de SCRUM-44 y 45 para el servidor | No |
| simulador | Servidor simulado y escenarios | No |
| tests, tools | Pruebas y generador de nanas | No |

secrets.py no se sube. Copia secrets_example.py como secrets.py y llénalo.

## Probar en tu PC

Necesita Python 3.10 o más nuevo. No hay que instalar nada.

    python3 -m unittest discover -s tests -t .

Para ver el simulador con una cuna de software, en dos terminales.

    python3 -m simulador.servidor_sim --puerto 8080 --escenario con-corte
    python3 -m simulador.cuna_software --puerto 8080

Más detalles en simulador/README.md. La prueba tests/test_interop.py usa la biblioteca websockets y se salta si no está instalada.

## Para quien continúe el trabajo

Lee primero AGENTS.md. Resume el estado, lo que falta y las trampas conocidas.

## Instalar en la Pico

Con Thonny, ver docs/11_GUIA_THONNY.md. Con la terminal y mpremote, ver docs/08_GUIA_INSTALACION.md.

Sin el DAC PCM5102A, la cuna suena por PWM en GP12 con el modo tonos, que es el valor por defecto en config.py. Solo suenan las nanas guardadas. Para usar el DAC, cambia AUDIO_SALIDA a i2s. Detalles en docs/10_AUDIO_SIN_DAC.md.
