# Traspaso del proyecto, para quien lo siga

Este archivo es para la persona o la IA que continúe este trabajo. Léelo completo antes de cambiar código. Fecha del traspaso: 27 de noviembre de 2026. Firmware 0.3.0. Contrato de mensajes versión 1.

## Qué es esto

Es la parte de Claudia del proyecto Ecosistema IoT Infantil, curso Principios de Modelado del TEC, con Scrum y Jira. Es una maqueta barata de una cuna inteligente. Corre en una Raspberry Pi Pico 2 W con MicroPython 1.29.0. Jan Carlo hace la app y el servidor real.

Las historias de Claudia son SCRUM-29 luz de noche, SCRUM-30 nanas, SCRUM-31 parte A voz, y SCRUM-44 y SCRUM-45 del lado del servidor.

## Estado en una frase

El código está completo y 229 pruebas automáticas pasan, pero todas usan hardware falso y un servidor simulado. Nada se ha probado en una Pico, y el servidor real de Jan Carlo no se ha tocado.

## Reglas que Claudia fijó para este trabajo

No inventes APIs, resultados ni pruebas de hardware. Si no lo puedes verificar, di que no lo verificaste. Revisa la documentación oficial y cítala. Los comentarios del código van en español. Los secretos solo van en secrets_example.py, con valores falsos, y secrets.py está en .gitignore. No hagas commit ni push sin que ella lo pida. No modifiques módulos de otros compañeros.

Cada criterio de aceptación se clasifica con una de estas etiquetas: IMPLEMENTADO Y PROBADO, IMPLEMENTADO NO PROBADO EN HARDWARE, VALIDADO SOLO CON SIMULADOR, PENDIENTE DE INTEGRACIÓN EXTERNA o NO IMPLEMENTADO. Distingue siempre una prueba con servidor simulado de una integración real. Hoy ningún criterio está en IMPLEMENTADO Y PROBADO.

Ella escribe con oraciones cortas y palabras básicas, y prefiere prosa a listas. Sin paréntesis salvo siglas institucionales y citas de artículos de un reglamento. Sin comillas angulares en documentos de Word.

## Dónde está cada cosa

| Ruta | Qué es | ¿Va a la Pico? |
| --- | --- | --- |
| main.py, config.py | Arranque y configuración fija | Sí |
| secrets_example.py | Plantilla de secretos. Se copia como secrets.py | Sí, como secrets.py |
| hal | Luz, salida de audio por I2S, salida por tonos PWM, micrófono | Sí |
| protocolo | Formato de los mensajes | Sí |
| servicios | Sesión, reconexión, eventos, audio, voz, cliente WebSocket, reloj | Sí |
| assets | Las nanas, en PCM de 16 bits, mono, 16 kHz | Sí |
| servidor | Lógica de SCRUM-44 y SCRUM-45 para el servidor de Jan Carlo | No |
| simulador | Servidor simulado, cuna de software y escenarios | No |
| tests | 229 pruebas automáticas | No |
| tools | Generador de nanas, preparador de archivos de la Pico, prueba de hardware | No |
| docs | Informes de cada etapa, contrato, guías y diagramas | No |

## Documentos que debes leer, en este orden

1. docs/00_CONTRATO.md. El contrato de mensajes. Todo está PROPUESTO. Jan Carlo no lo ha aprobado.
2. docs/07_ETAPA6_pruebas_y_criterios.md. Estado de cada criterio, plan de 14 pruebas de hardware y riesgos abiertos.
3. docs/10_AUDIO_SIN_DAC.md. El modo de audio por tonos, y el error de cancelación que se encontró.
4. docs/11_GUIA_THONNY.md. Cómo subir y correr todo en la Pico.
5. docs/05_ETAPA5_integracion.md y docs/06_SCRUM44_45_servidor.md. Integración y lado servidor.
6. docs/01_ETAPA1_viabilidad.md a docs/04_ETAPA4_SCRUM31.md. Decisiones y pines por etapa.
7. docs/09_GUIA_DEFENSA.md. Qué se puede decir en la defensa y qué no.

## Cómo correr las pruebas

Python 3.10 o más nuevo. No hay que instalar nada.

    python3 -m unittest discover -s tests -t .

Tardan unos 80 segundos. La prueba tests/test_interop.py usa la biblioteca websockets y se salta si no está. Para ver la cuna de software contra el simulador, en dos terminales:

    python3 -m simulador.servidor_sim --puerto 8080 --escenario con-corte
    python3 -m simulador.cuna_software --puerto 8080

## Cómo llevarlo a la Pico

Ver docs/11_GUIA_THONNY.md. En corto: corre python3 tools/preparar_pico.py, sube la carpeta pico_subir con Thonny, crea secrets.py en la Pico y prueba primero con tools/prueba_hardware.py.

## Hardware, como está hoy

La luz sale por GP18, pin 24, con PWM, a través de un transistor NPN. El audio sale por GP12, pin 16, con PWM, hacia un amplificador PAM8403 y un parlante. El micrófono entra por GP26, pin 31, al ADC. El diagrama está en docs/cuna_diagrama_electronico.pdf, versión 4. El bloque de audio con más detalle está en docs/parte_B_detallada.pdf.

Claudia ya tiene la Pico con pines soldados, el PAM8403, un módulo de sonido HW-484, un condensador de 100 nF, uno electrolítico de 10 µF a 25 V, LEDs y resistencias. Le faltaba conseguir un transistor NPN como el 2N3904 y un parlante de 8 Ω. Esta lista puede haber cambiado. Pregúntale antes de asumir.

No consiguió el DAC PCM5102A. Por eso el modo por defecto es AUDIO_SALIDA igual a tonos, en config.py. Con el DAC se cambia a i2s. El código I2S existe y no se ha probado con el DAC ni en la Pico.

## Lo que no funciona en modo tonos

Solo suenan las nanas guardadas en la cuna, como notas. No suena la voz de la app y no suenan canciones del servidor. La cuna responde UNSUPPORTED a esas órdenes y avisa en el hello con tres campos propuestos: audio_out_mode, voice_playback y server_songs. La voz de la cuna hacia la app sí está implementada. Esto debilita el criterio de voz de SCRUM-31.

## Lo que falta

1. Correr las 14 pruebas de hardware de la sección 4 del documento 07 y anotar resultados reales. Los umbrales de las pruebas 3 y 8 son propuestas, no salen de documentación.
2. Que Jan Carlo apruebe el contrato, incluidos los cambios propuestos. Sin eso, la integración real puede fallar aunque todo pase con el simulador.
3. Conectar el módulo de la carpeta servidor al servidor real. Hoy recibe el envío inyectado como función y no crea ningún bot de Telegram ni manda nada real.
4. SCRUM-44 criterio 1, el kit sin sonido, es un requisito de hardware del kit de seguridad y está NO IMPLEMENTADO.
5. El rssi se reporta como null. No confirmé en la documentación cómo leerlo en MicroPython.
6. Decidir si la voz por turnos cumple SCRUM-31. Jira dice bidireccional y esto va por turnos, no a la vez. Se eligió WebSocket, que Jira permite.
7. Armar el circuito del micrófono. El plan A usa el módulo HW-484 y el plan B un MCP6002. El pinout del MCP6002 salió de memoria y está marcado en el diagrama como por verificar.

## Riesgos que siguen abiertos

El mayor es leer el ADC a 8 kHz con el Wi-Fi activo. Si falla, la voz de la cuna hacia la app no sirve. Los caminos están en el documento 04. Después va el cliente WebSocket escrito a mano, que solo se probó contra el simulador y contra la biblioteca websockets en el PC. Después la RAM y la flash, que se miden en las pruebas 3 y 4. Los valores del divisor de voltaje del audio, 10 kΩ y 1 kΩ, son una propuesta sin probar.

Lo que ninguna prueba del PC puede cubrir: el código viper, el comportamiento real de I2S en el RP2350, la velocidad real del ADC, el Wi-Fi real, el reloj NTP y hashlib.sha1 en la Pico, y cómo suena el PWM en un parlante real. La documentación de machine.PWM para RP2 no da un rango de frecuencia ni confirma cómo comparten frecuencia las dos salidas de un mismo bloque PWM. Por eso GP12 se usa solo.

## Decisiones de diseño y su razón

Todo va por una sola conexión WebSocket, con mensajes JSON para control y tramas binarias para audio. La voz es por turnos y no a la vez. La razón completa está en docs/04_ETAPA4_SCRUM31.md. El micrófono está apagado por defecto. Las esperas de reconexión son 1, 2, 4, 8, 16 y 30 segundos. El búfer de eventos guarda 50. El estado se manda cada 30 segundos.

En SCRUM-45 las ventanas horarias usan la zona America/Costa_Rica, UTC-6. Una ventana que cruza la medianoche cuenta bajo el día en que empieza. El inicio es inclusivo y el fin exclusivo. Dos ventanas que se solapan dan SCHEDULE_OVERLAP. Una orden manual dura hasta el próximo borde de ventana. En SCRUM-44 se usan sendMessage y sendPhoto de Telegram con disable_notification verdadero. El límite de texto es 4096 y el de pie de foto 1024.

Se agregó __init__.py en hal, protocolo y servicios porque no confirmé que MicroPython soporte paquetes de espacio de nombres.

## Trampas que ya nos mordieron

Tragar CancelledError al esperar una tarea hija también traga la cancelación de quien llama, y la sesión no termina. Para esto existe servicios/tareas.py con cancelar_y_esperar. Úsala en vez de un await dentro de un try. No usa Task.cancelling, porque no confirmé que exista en MicroPython.

Las pruebas por mutación sirven. Rompiendo el código a propósito se encontraron huecos reales en las pruebas, por ejemplo que hacía falta llamar a pendiente después de un envío fallido, y una prueba de importaciones que se calculaba con la misma lista que probaba. Si agregas una prueba, rompe el código y mira que falle.

El perro guardián de main.py no se puede detener una vez iniciado. Al parar el programa en Thonny, la Pico se reinicia sola en unos 8 segundos. Ver la guía de Thonny.

## Qué pedirle a Claudia

Que te diga qué piezas tiene ya, cuáles pruebas de hardware ha corrido y con qué resultados, y si Jan Carlo aprobó el contrato. Los datos que ella había quedado de traer son mic_hz_real y free_ram, medidos en la Pico.
