# Plantilla de secretos. Copia este archivo como secrets.py y cambia los valores.
# secrets.py está en .gitignore y nunca se sube. Estos valores son falsos.

WIFI_SSID = "NOMBRE_DE_TU_WIFI"
WIFI_CLAVE = "CLAVE_DE_TU_WIFI"

# Dirección del servidor de Jan Carlo.
SERVIDOR_HOST = "192.168.0.10"
SERVIDOR_PUERTO = 8080

# UUID de esta cuna. Debe ser el Device_ID registrado en la plataforma.
DEVICE_ID = "00000000-0000-4000-8000-000000000000"

# Token propio de esta cuna. Lo entrega el servidor.
TOKEN = "CAMBIAR_ESTE_TOKEN"
