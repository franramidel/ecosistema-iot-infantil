"""Junta en una carpeta solo los archivos que van a la Pico.

Se corre en el PC, no en la Pico. Después se sube la carpeta con Thonny.
Uso, desde la raíz del repositorio:

    python3 tools/preparar_pico.py
    python3 tools/preparar_pico.py --destino otra_carpeta

No copia secrets.py. Ese archivo lo creas tú a partir de secrets_example.py.
"""
import argparse
import os
import shutil
import sys

RAIZ = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

ARCHIVOS_RAIZ = ["main.py", "config.py", "secrets_example.py"]
CARPETAS = ["hal", "protocolo", "servicios", "assets"]
EXTENSIONES = (".py", ".pcm")


def archivos_pico(raiz=RAIZ):
    """Lista de rutas relativas, con barra normal, de lo que va a la Pico."""
    lista = []
    for nombre in ARCHIVOS_RAIZ:
        if os.path.isfile(os.path.join(raiz, nombre)):
            lista.append(nombre)
    for carpeta in CARPETAS:
        for dirpath, dirnames, filenames in os.walk(os.path.join(raiz, carpeta)):
            dirnames[:] = [d for d in dirnames if d != "__pycache__"]
            for f in sorted(filenames):
                if f.endswith(EXTENSIONES):
                    rel = os.path.relpath(os.path.join(dirpath, f), raiz)
                    lista.append(rel.replace(os.sep, "/"))
    return sorted(lista)


def preparar(destino, raiz=RAIZ):
    if os.path.exists(destino):
        shutil.rmtree(destino)
    total = 0
    lista = archivos_pico(raiz)
    for rel in lista:
        origen = os.path.join(raiz, rel)
        fin = os.path.join(destino, rel)
        os.makedirs(os.path.dirname(fin) or destino, exist_ok=True)
        shutil.copy2(origen, fin)
        total += os.path.getsize(origen)
    return lista, total


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--destino", default=os.path.join(RAIZ, "pico_subir"))
    a = p.parse_args(argv)
    lista, total = preparar(a.destino)
    for rel in lista:
        print(rel)
    print("\n%d archivos, %d bytes, en %s" % (len(lista), total, a.destino))
    print("Falta crear secrets.py en la Pico a partir de secrets_example.py.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
