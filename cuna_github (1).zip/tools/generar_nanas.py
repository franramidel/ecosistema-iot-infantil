# Genera dos nanas cortas y originales para dejar en la memoria de la cuna.
# Formato: PCM de 16 bits con signo, mono, 16 kHz, little endian, sin cabecera.
# Son melodías simples inventadas para la maqueta. No copian ninguna canción.
# Uso: python3 tools/generar_nanas.py

import array
import math
import os
import sys

RATE = 16000
SALIDA = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "assets")

# Frecuencias de una escala pentatónica suave, en Hz.
DO, RE, MI, SOL, LA, DO2 = 261.63, 293.66, 329.63, 392.00, 440.00, 523.25


def nota(freq, seg, amp=0.6):
    n = int(RATE * seg)
    datos = []
    for i in range(n):
        t = i / RATE
        # Ataque y caída suaves para que no haya clics.
        ataque = min(1.0, i / (0.02 * RATE))
        caida = min(1.0, (n - i) / (0.15 * RATE))
        v = math.sin(2 * math.pi * freq * t) + 0.25 * math.sin(2 * math.pi * 2 * freq * t)
        datos.append(int(32767 * amp * ataque * caida * v / 1.25))
    return datos


def cancion(notas):
    pcm = []
    for f, seg in notas:
        pcm += nota(f, seg) if f else [0] * int(RATE * seg)
    return pcm


NANAS = {
    "nana-1": [(MI, .5), (SOL, .5), (LA, 1.0), (SOL, .5), (MI, .5), (RE, 1.0),
               (DO, .5), (RE, .5), (MI, 1.0), (SOL, .5), (MI, .5), (DO, 1.5)],
    "nana-2": [(SOL, .75), (MI, .75), (SOL, 1.5), (LA, .75), (SOL, .75), (MI, 1.5),
               (RE, .75), (MI, .75), (DO, 2.0)],
}

if __name__ == "__main__":
    os.makedirs(SALIDA, exist_ok=True)
    for nombre, notas in NANAS.items():
        a = array.array("h", cancion(notas))
        if sys.byteorder == "big":
            a.byteswap()
        ruta = os.path.join(SALIDA, nombre + ".pcm")
        with open(ruta, "wb") as f:
            f.write(a.tobytes())
        print(nombre, os.path.getsize(ruta), "bytes", round(len(a) / RATE, 1), "s")
