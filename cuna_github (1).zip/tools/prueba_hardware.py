# Prueba de hardware para correr en la Pico desde Thonny. Sin Wi-Fi y sin el resto del firmware.
# Abre este archivo en Thonny con el intérprete MicroPython (Raspberry Pi Pico) y pulsa Run (F5).
# No hace falta subirlo a la Pico: Thonny manda el contenido del editor.
# Cubre en parte las pruebas 2, 3, 4 y 8 de docs/07_ETAPA6_pruebas_y_criterios.md.
# La prueba 8 real mide el ritmo del micrófono con el Wi-Fi activo. Aquí solo se mide qué tan rápido lee el ADC sin Wi-Fi.
# Se hizo sin poder probarlo en una Pico. Usa solo Pin, PWM, ADC, gc, os y time.
import gc
import os
import time
from machine import ADC, PWM, Pin

try:
    import config
    PIN_LUZ, PIN_AUDIO, PIN_MIC = config.PIN_LUZ, config.PIN_PWM_AUDIO, config.PIN_MIC_ADC
    RATE_PEDIDO = config.MIC_RATE_HZ
except ImportError:
    PIN_LUZ, PIN_AUDIO, PIN_MIC, RATE_PEDIDO = 18, 12, 26, 8000


def info():
    gc.collect()
    st = os.statvfs("/")
    print("Sistema:", os.uname().version)
    print("RAM libre (bytes):", gc.mem_free())
    print("Flash libre (bytes):", st[0] * st[3])


def luz():
    print("LUZ: debe subir y bajar suave en unos 2 segundos.")
    pwm = PWM(Pin(PIN_LUZ), freq=1000, duty_u16=0)
    for d in range(0, 26000, 500):
        pwm.duty_u16(d)
        time.sleep_ms(20)
    for d in range(26000, 0, -500):
        pwm.duty_u16(d)
        time.sleep_ms(20)
    pwm.duty_u16(0)
    pwm.deinit()


def tono():
    print("TONO: deben oírse 440 Hz y luego 880 Hz, un segundo cada uno. Volumen bajo.")
    pwm = PWM(Pin(PIN_AUDIO), freq=440, duty_u16=8192)
    time.sleep_ms(1000)
    pwm.freq(880)
    time.sleep_ms(1000)
    pwm.duty_u16(0)
    pwm.deinit()


def microfono():
    print("MICRÓFONO: habla cerca durante 1 segundo.")
    adc = ADC(Pin(PIN_MIC))
    minimo, maximo, suma, n = 65535, 0, 0, 0
    t0 = time.ticks_us()
    while time.ticks_diff(time.ticks_us(), t0) < 1000000:
        v = adc.read_u16()
        suma += v
        n += 1
        if v < minimo:
            minimo = v
        if v > maximo:
            maximo = v
    print("Lecturas hechas en 1 segundo:", n, "(el firmware pide %d por segundo)" % RATE_PEDIDO)
    print("ADC mínimo, máximo, promedio:", minimo, maximo, suma // n)
    print("Si el máximo menos el mínimo es casi cero aunque hables, el micrófono no está dando señal.")


def principal():
    print("=== Prueba de hardware de la cuna ===")
    info()
    luz()
    tono()
    microfono()
    print("=== Fin. Copia lo impreso arriba y anota qué viste y oíste. ===")


principal()
