# Configuración fija de la cuna. Aquí no van secretos.
# Los secretos van en secrets.py, que no se sube al repositorio.

VERSION_FW = "0.3.0"
VERSION_PROTOCOLO = 1

# Pines. Ver la tabla de pines en ETAPA1_viabilidad.md.
PIN_LUZ = 18          # GP18, pin físico 24, PWM1 canal A

# Luz de noche.
LUZ_FRECUENCIA_HZ = 1000     # Dentro del rango de 8 Hz a 62,5 MHz que documenta MicroPython.
LUZ_BRILLO_DEFECTO = 30      # Se usa si nunca hubo un brillo anterior.
LUZ_FADE_DEFECTO_MS = 1000
LUZ_FADE_MAX_MS = 10000
LUZ_PASO_FADE_MS = 20
LUZ_CURVA = 2.2              # Curva para que el brillo se vea parejo al ojo.

# Conexión al servidor.
WS_RUTA = "/ws/cuna"         # Propuesta, pendiente de aprobación de Jan Carlo.
WS_MAX_PAYLOAD = 4096        # Tamaño máximo que aceptamos de un mensaje.
ESPERAS_RECONEXION_S = (1, 2, 4, 8, 16, 30)
LATIDO_S = 30
TIMEOUT_WELCOME_S = 10
TIMEOUT_SIN_MENSAJES_S = 95  # Si el servidor calla más que esto, reconectamos.

# Perro guardián. El máximo que documenta MicroPython en rp2 es 8388 ms.
WDT_MS = 8000
WDT_ALIMENTAR_S = 2

# Hora.
SEGUNDOS_EPOCA_2000_A_1970 = 946684800

# Audio de salida. Una sola configuración de I2S para voz y nanas.
PIN_I2S_BCK = 10      # GP10, pin 14. El pin LRCK debe ser el siguiente número, GP11.
PIN_I2S_LRCK = 11     # GP11, pin 15
PIN_I2S_DATOS = 12    # GP12, pin 16
AUDIO_RATE_HZ = 16000
AUDIO_IBUF_BYTES = 4096        # Búfer interno de I2S. Valor inicial, se ajusta con pruebas.
AUDIO_TRAMA_MS = 20
AUDIO_TRAMA_BYTES = 640        # 320 muestras de 16 bits a 16 kHz en 20 ms.
AUDIO_TRAMA_MAX_BYTES = 1280   # Más que esto se descarta.
AUDIO_COLA_MAX = 40            # Tramas del servidor que se guardan. 40 por 20 ms son 800 ms.
AUDIO_PREBUFFER = 8            # Tramas que se esperan antes de empezar, 160 ms.
AUDIO_TIMEOUT_PREBUFFER_S = 5
AUDIO_VOLUMEN_DEFECTO = 30     # Porcentaje de 0 a 100.
AUDIO_GANANCIA_MAX = 0.5       # Con volumen 100 la señal queda a la mitad. Cuida el parlante.
AUDIO_TRAMAS_RAMPA = 16        # Una subida o bajada de volumen tarda 16 tramas, 320 ms.
AUDIO_TRAMAS_FADE_OUT = 3      # Al parar se baja a cero en 3 tramas, 60 ms.
# Salida de audio. "i2s" usa el DAC PCM5102A. "tonos" usa un pin con PWM y toca las nanas como notas.
# El modo tonos no reproduce canciones del servidor ni la voz de la app. Sin probar en hardware.
AUDIO_SALIDA = "tonos"
PIN_PWM_AUDIO = 12             # GP12, pin 16. Va al PAM8403 por un divisor de voltaje.
AUDIO_TONO_MIN_HZ = 80
AUDIO_TONO_MAX_HZ = 4000
AUDIO_TONO_PICO_MIN = 150      # Una trama con menos pico que esto se toma como silencio.
AUDIO_TONO_ESCALA = 1.5        # Del pico de la trama al ciclo de trabajo. Se ajusta escuchando.
AUDIO_TONO_DUTY_MAX = 0.5      # Más de 50 por ciento no suena más fuerte, solo más agudo.
RUTA_NANAS = "assets"          # Archivos .pcm: PCM de 16 bits, mono, 16 kHz.

# Micrófono. Cápsula de electret con amplificador, entrada ADC en GP26.
PIN_MIC_ADC = 26               # GP26, pin 31
MIC_RATE_HZ = 8000
MIC_MUESTRAS_TRAMA = 160       # 20 ms a 8 kHz.
MIC_BUFS = 6                   # Anillo de 6 tramas, 120 ms de margen.
MIC_GANANCIA_Q8 = 1024         # 4,0 en punto fijo. Se ajusta escuchando.

# Voz por turnos, SCRUM-31 parte A.
VOZ_GUARDA_MS = 200            # Pausa antes de abrir el micrófono al cambiar de turno.
VOZ_PREBUFFER = 3              # Tramas de la app que se esperan antes de sonar, 60 ms.
VOZ_COLA_MAX = 15              # Máximo de tramas de la app en espera, 300 ms.
VOZ_INFORME_S = 5              # Cada cuánto se manda voice.state durante la sesión.

# Eventos de auditoría, SCRUM-20 y SCRUM-22.
EVENTOS_MAX = 50               # Eventos que se guardan si no hay conexión.
EVENTOS_DETALLE_MAX = 120      # Largo máximo del texto de detalle.
EVENTO_UNDERRUN_CADA_MS = 5000  # Un AUDIO_UNDERRUN como máximo cada 5 segundos.
