# Registro de eventos de la cuna. Sirve para la auditoría de SCRUM-20 y el búfer sin
# conexión de SCRUM-22. Si no hay conexión, guarda hasta 50 eventos. Al reconectar los manda
# en orden, con su hora original. Si el búfer se llena, descarta los más viejos y cuenta
# cuántos perdió en dropped_before del evento más viejo que queda.
#
# La severidad es siempre info. SCRUM-25 dispara una alerta en Telegram con warning o
# critical, y los eventos de la cuna no deben generar alertas de seguridad.

import asyncio

import config
from protocolo import mensajes as m


class Registro:
    def __init__(self, ahora_ms, uptime_ms, sincronizado, boot_id=None, maximo=config.EVENTOS_MAX):
        self._ahora_ms = ahora_ms
        self._uptime_ms = uptime_ms
        self._sincronizado = sincronizado     # Función que dice si la hora es confiable.
        self._max = maximo
        self._buf = []
        self._n = 0
        self._ultimo = {}
        self._boot = boot_id if boot_id is not None else self._nuevo_boot()
        self._aviso = asyncio.Event()
        self.perdidos = 0

    @staticmethod
    def _nuevo_boot():
        try:
            import os
            return "".join("%02x" % b for b in os.urandom(2))
        except (ImportError, AttributeError):
            import random
            return "%04x" % random.getrandbits(16)

    def pendientes(self):
        return len(self._buf)

    def registrar(self, tipo, detalle="", severidad="info", min_intervalo_ms=0):
        """Anota un evento. Devuelve True si se guardó. No espera nada ni usa la red."""
        ahora = self._uptime_ms()
        if min_intervalo_ms:
            antes = self._ultimo.get(tipo)
            if antes is not None and ahora - antes < min_intervalo_ms:
                return False
            self._ultimo[tipo] = ahora
        self._n += 1
        ev = m.event("%s-%d" % (self._boot, self._n), tipo[:50], severidad,
                     str(detalle)[:config.EVENTOS_DETALLE_MAX], self._ahora_ms(), ahora,
                     self._sincronizado(), 0)
        self._buf.append(ev)
        if len(self._buf) > self._max:
            viejo = self._buf.pop(0)
            self._buf[0]["dropped_before"] += viejo["dropped_before"] + 1
            self.perdidos += 1
        self._aviso.set()
        return True

    def evento(self, tipo, detalle="", min_intervalo_ms=0):
        """Forma corta para los servicios. La severidad es siempre info."""
        return self.registrar(tipo, detalle, "info", min_intervalo_ms)

    def pendiente(self):
        """Pide al emisor que mande lo que haya. Se usa al conectar."""
        self._aviso.set()

    async def vaciar(self, enviar):
        """Manda los eventos en orden. Si falla un envío, el evento se queda para después."""
        while self._buf:
            await enviar(self._buf[0])
            self._buf.pop(0)

    async def emisor(self, enviar):
        """Tarea que manda los eventos apenas se registran. Corre mientras haya conexión."""
        while True:
            await self._aviso.wait()
            self._aviso.clear()
            try:
                await self.vaciar(enviar)
            except asyncio.CancelledError:
                raise
            except Exception:
                return      # La conexión falló. Los eventos siguen guardados.
