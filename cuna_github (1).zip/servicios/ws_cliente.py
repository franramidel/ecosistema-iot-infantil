# Cliente WebSocket mínimo, hecho sobre asyncio.open_connection.
# Se escribió propio porque la librería aiohttp de micropython-lib tiene reportes de
# caídas con envíos sostenidos y no la pude probar. Este cliente solo usa funciones
# documentadas de asyncio: open_connection, readline, readexactly, write y drain.
# Limitaciones: sin TLS por ahora, sin mensajes fragmentados.

import asyncio
import binascii
import struct

try:
    import os
    _urandom = os.urandom
except (ImportError, AttributeError):
    _urandom = None

try:
    import hashlib
except ImportError:
    hashlib = None

OP_TEXTO = 0x1
OP_BINARIO = 0x2
OP_CIERRE = 0x8
OP_PING = 0x9
OP_PONG = 0xA

_GUID = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"


class ErrorWS(Exception):
    pass


def _aleatorio(n):
    if _urandom is not None:
        return _urandom(n)
    import random
    return bytes(random.getrandbits(8) for _ in range(n))


def _enmascarar(datos, mascara):
    n = len(datos)
    if n == 0:
        return b""
    clave = (mascara * (n // 4 + 1))[:n]
    x = int.from_bytes(datos, "little") ^ int.from_bytes(clave, "little")
    return x.to_bytes(n, "little")


def armar_trama(opcode, datos):
    """Arma una trama del cliente. El cliente siempre enmascara."""
    n = len(datos)
    if n < 126:
        cab = struct.pack("!BB", 0x80 | opcode, 0x80 | n)
    elif n < 65536:
        cab = struct.pack("!BBH", 0x80 | opcode, 0x80 | 126, n)
    else:
        raise ErrorWS("mensaje demasiado grande")
    mascara = _aleatorio(4)
    return cab + mascara + _enmascarar(datos, mascara)


class ClienteWS:
    def __init__(self, host, puerto, ruta, max_payload=4096):
        self._host = host
        self._puerto = puerto
        self._ruta = ruta
        self._max = max_payload
        self._r = None
        self._w = None
        self._candado = asyncio.Lock()
        self.abierto = False

    async def conectar(self):
        self._r, self._w = await asyncio.open_connection(self._host, self._puerto)
        clave = binascii.b2a_base64(_aleatorio(16)).strip().decode()
        pedido = ("GET %s HTTP/1.1\r\nHost: %s:%d\r\nUpgrade: websocket\r\n"
                  "Connection: Upgrade\r\nSec-WebSocket-Key: %s\r\n"
                  "Sec-WebSocket-Version: 13\r\n\r\n") % (
                      self._ruta, self._host, self._puerto, clave)
        self._w.write(pedido.encode())
        await self._w.drain()
        linea = await self._r.readline()
        if b" 101 " not in linea:
            self._cerrar_socket()
            raise ErrorWS("el servidor no aceptó el WebSocket: %r" % linea)
        aceptado = None
        while True:
            linea = await self._r.readline()
            if linea in (b"\r\n", b"\n", b""):
                break
            if linea.lower().startswith(b"sec-websocket-accept:"):
                aceptado = linea.split(b":", 1)[1].strip()
        if hashlib is not None and aceptado is not None:
            esperado = binascii.b2a_base64(
                hashlib.sha1(clave.encode() + _GUID).digest()).strip()
            if aceptado != esperado:
                self._cerrar_socket()
                raise ErrorWS("Sec-WebSocket-Accept no coincide")
        self.abierto = True

    async def _enviar(self, opcode, datos):
        if not self.abierto:
            raise ErrorWS("conexión cerrada")
        trama = armar_trama(opcode, datos)
        async with self._candado:
            self._w.write(trama)
            await self._w.drain()

    async def enviar_texto(self, texto):
        await self._enviar(OP_TEXTO, texto.encode())

    async def enviar_binario(self, datos):
        await self._enviar(OP_BINARIO, datos)

    async def recibir(self):
        """Espera un mensaje de texto o binario. Devuelve opcode y datos."""
        while True:
            cab = await self._r.readexactly(2)
            b0, b1 = cab[0], cab[1]
            opcode = b0 & 0x0F
            if not (b0 & 0x80) or opcode == 0x0:
                raise ErrorWS("mensajes fragmentados no soportados")
            if b1 & 0x80:
                raise ErrorWS("el servidor no debe enmascarar")
            n = b1 & 0x7F
            if n == 126:
                n = struct.unpack("!H", await self._r.readexactly(2))[0]
            elif n == 127:
                raise ErrorWS("mensaje demasiado grande")
            if n > self._max:
                raise ErrorWS("mensaje de %d bytes supera el máximo %d" % (n, self._max))
            datos = await self._r.readexactly(n) if n else b""
            if opcode in (OP_TEXTO, OP_BINARIO):
                return opcode, datos
            if opcode == OP_PING:
                await self._enviar(OP_PONG, datos)
            elif opcode == OP_CIERRE:
                # El protocolo pide contestar el cierre con otro cierre antes de colgar.
                try:
                    await self._enviar(OP_CIERRE, datos[:2])
                except Exception:
                    pass
                self.abierto = False
                self._cerrar_socket()
                raise ErrorWS("el servidor cerró la conexión")
            # Un pong se ignora.

    def _cerrar_socket(self):
        self.abierto = False
        if self._w is not None:
            try:
                self._w.close()
            except Exception:
                pass

    async def cerrar(self):
        if self.abierto:
            try:
                await self._enviar(OP_CIERRE, b"")
            except Exception:
                pass
        self._cerrar_socket()
