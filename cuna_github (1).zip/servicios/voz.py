# Voz por turnos de SCRUM-31 parte A. Solo habla uno a la vez, la cuna o la app.
# Es una limitación de la maqueta: el micrófono y el parlante están muy juntos y habría eco.
# Jira pide voz bidireccional. Con turnos se cumple en parte, y así se declara.
#
# Privacidad. El micrófono está apagado por defecto. Solo se enciende con voice.start, que
# llega por la conexión ya autenticada con el token de la cuna. Se apaga con voice.stop,
# al perder la conexión y al reiniciar.

import asyncio
from servicios.tareas import cancelar_y_esperar
import struct

import config
from hal.mic import ErrorMic
from protocolo import mensajes as m

TURNOS = ("cradle", "app")
TIPO_VOZ_CUNA = 1
TIPO_VOZ_APP = 2


class ServicioVoz:
    def __init__(self, gestor, mic, enviar, enviar_bin, ahora_ms, evento=None):
        self._g = gestor
        self._evento = evento      # Función evento tipo, detalle. Puede ser None.
        self._mic = mic
        self._enviar = enviar
        self._enviar_bin = enviar_bin
        self._ahora_ms = ahora_ms
        self.sesion = None
        self.turno = None
        self.descartadas = 0      # Tramas fuera de turno, inválidas o que no cupieron.
        self._seq_tx = 0
        self._t_mic = None
        self._t_turno = None
        self._t_info = None

    # ---------- mensajes de control ----------

    def estado(self):
        return m.voice_state(self.sesion, self.sesion is not None, self.turno,
                             self._mic.activo, self._mic.hz_real(),
                             self.descartadas + self._mic.perdidas, self._ahora_ms())

    async def informar(self):
        await self._enviar(self.estado())

    def _validar(self, msg):
        sid = msg.get("session_id")
        if not isinstance(sid, str) or not sid or len(sid) > 64:
            return "BAD_JSON", "session_id debe ser texto de 1 a 64 caracteres"
        turno = msg.get("turn")
        if msg["type"] == "voice.turn" and turno is None:
            return "BAD_JSON", "falta turn"
        if turno is not None and turno not in TURNOS:
            return "INVALID_RANGE", "turn debe ser cradle o app"
        return None

    async def manejar(self, msg):
        ref = msg.get("id")
        problema = self._validar(msg)
        if problema:
            await self._enviar(m.error(ref, problema[0], problema[1]))
            return
        tipo, sid = msg["type"], msg["session_id"]
        if tipo == "voice.start":
            await self._iniciar(ref, sid, msg.get("turn") or "cradle")
        elif tipo == "voice.turn":
            if self.sesion != sid:
                await self._enviar(m.error(ref, "NO_SESSION", "no hay una sesión con ese session_id"))
                return
            await self._enviar(m.ack(ref))
            await self._cancelar(self._t_turno)
            self._t_turno = asyncio.create_task(self._cambiar_turno(ref, msg["turn"]))
        elif tipo == "voice.stop":
            if self.sesion is not None and self.sesion != sid:
                await self._enviar(m.error(ref, "NO_SESSION", "no hay una sesión con ese session_id"))
                return
            await self._enviar(m.ack(ref))
            await self.terminar(True)

    def _ev(self, tipo, detalle):
        if self._evento:
            self._evento(tipo, detalle)

    async def _iniciar(self, ref, sid, turno):
        if self.sesion is not None:
            if self.sesion == sid:
                await self._enviar(m.ack(ref, True, "already_active"))
                await self.informar()
            else:
                await self._enviar(m.error(ref, "BUSY", "ya hay otra sesión de voz activa"))
            return
        await self._g.entrar_voz()          # Corta la nana, que queda detenida.
        self.sesion, self.turno = sid, turno
        self._seq_tx = 0
        self.descartadas = 0
        try:
            await self._activar_turno(turno, esperar=False)
        except ErrorMic as e:
            self.sesion, self.turno = None, None
            await self._g.salir_voz()
            self._ev("DEVICE_ERROR", "mic_unavailable")
            await self._enviar(m.error(ref, "MIC_UNAVAILABLE", str(e)))
            return
        self._ev("VOICE_STARTED", "session=%s turn=%s" % (sid, turno))
        await self._enviar(m.ack(ref))
        self._t_info = asyncio.create_task(self._bucle_info())
        await self.informar()

    async def _activar_turno(self, turno, esperar):
        """Deja la cuna lista para el turno. Puede lanzar ErrorMic."""
        if turno == "cradle":
            await self._g.voz_silenciar()           # Vacía lo que quedara por sonar.
            if esperar:
                await asyncio.sleep(config.VOZ_GUARDA_MS / 1000)
            self._abrir_mic()
        else:
            self._cerrar_mic()
            await self._g.voz_reproducir()

    async def _cambiar_turno(self, ref, turno):
        self.turno = turno      # Desde ya, las tramas del otro turno se descartan.
        try:
            await self._activar_turno(turno, esperar=True)
        except ErrorMic as e:
            self._ev("DEVICE_ERROR", "mic_unavailable")
            await self._enviar(m.error(ref, "MIC_UNAVAILABLE", str(e)))
        await self.informar()

    async def terminar(self, avisar):
        """Cierra la sesión. Apaga el micrófono y devuelve el audio al reposo."""
        await self._cancelar(self._t_turno)
        await self._cancelar(self._t_info)
        self._t_turno = self._t_info = None
        self._cerrar_mic()
        if self.sesion is not None:
            self._ev("VOICE_STOPPED", "session=%s" % self.sesion)
            self.sesion, self.turno = None, None
            await self._g.salir_voz()
        if avisar:
            await self.informar()

    async def _cancelar(self, tarea):
        await cancelar_y_esperar(tarea)

    async def _bucle_info(self):
        while True:
            await asyncio.sleep(config.VOZ_INFORME_S)
            try:
                await self.informar()
            except Exception:
                pass

    # ---------- micrófono hacia la app ----------

    def _abrir_mic(self):
        self._mic.iniciar()
        if self._t_mic is None:
            self._t_mic = asyncio.create_task(self._bucle_mic())

    def _cerrar_mic(self):
        self._mic.detener()
        if self._t_mic is not None:
            self._t_mic.cancel()
            self._t_mic = None

    async def _bucle_mic(self):
        try:
            while True:
                trama = await self._mic.siguiente_trama()
                cab = struct.pack("!BBHI", 1, TIPO_VOZ_CUNA, self._seq_tx & 0xFFFF,
                                  self._ahora_ms() & 0xFFFFFFFF)
                self._seq_tx += 1
                await self._enviar_bin(cab + trama)
        except asyncio.CancelledError:
            raise
        except Exception:
            # Falló el envío, por ejemplo se cayó la conexión. Se apaga el micrófono.
            self._mic.detener()
            self._t_mic = None

    # ---------- voz de la app hacia el parlante ----------

    def recibir_trama(self, datos):
        """Recibe un mensaje binario de tipo 2, con cabecera de 8 bytes."""
        if len(datos) < 8:
            return
        version, tipo, _seq, _ts = struct.unpack("!BBHI", datos[:8])
        if version != 1 or tipo != TIPO_VOZ_APP:
            return
        if self.sesion is None or self.turno != "app":
            self.descartadas += 1
            return
        if not self._g.encolar_voz(memoryview(datos)[8:]):
            self.descartadas += 1
