import asyncio


async def cancelar_y_esperar(tarea):
    """Cancela una tarea y espera a que termine.

    Antes se hacía `await tarea` dentro de un try que tragaba CancelledError.
    Eso también tragaba la cancelación de quien llamaba, y la sesión nunca
    terminaba. Aquí no se espera la tarea con await. Se revisa cada pocos
    milisegundos si ya terminó. Si cancelan a quien llama, la cancelación
    sube normal desde el sleep.
    """
    if tarea is None:
        return
    tarea.cancel()
    while not tarea.done():
        await asyncio.sleep(0.005)
    try:
        tarea.exception()       # Solo marca el resultado como leído.
    except BaseException:       # Una tarea cancelada lanza CancelledError aquí.
        pass
