# Gestor de audio de la cuna. Atiende SCRUM-30 Nanas.
# Regla central: una sola fuente suena a la vez. Hoy hay dos fuentes de canción:
# el servidor, que manda tramas binarias de tipo 3, y la memoria de la cuna.
# La voz de SCRUM-31 usará este mismo gestor en la etapa 4.

import asyncio
from servicios.tareas import cancelar_y_esperar
import struct

import config
from protocolo import mensajes as m
from servicios.volumen import escalar_pcm16, ganancia_para_volumen

IDLE = "idle"
CANCION = "song"
VOZ = "voice"

TIPO_CANCION = 3
_TRAMA_SILENCIO = bytes(config.AUDIO_TRAMA_BYTES)


class GestorAudio:
    def __init__(self, salida, enviar, ahora_ms, abrir_local, listar_locales, evento=None):
        # salida: objeto con abrir, escribir y cerrar. enviar: corrutina que manda un dict.
        # abrir_local: función que da un archivo abierto o None. listar_locales: ids guardados.
        self._salida = salida
        self._evento = evento      # Función evento tipo, detalle, intervalo_min_ms. Puede ser None.
        self._enviar = enviar
        self._ahora_ms = ahora_ms
        self._abrir_local = abrir_local
        self._listar_locales = listar_locales
        self.modo = IDLE
        self.song_id = None
        self.source = None
        self.volumen = config.AUDIO_VOLUMEN_DEFECTO
        self.ultimo_seq = 0
        self.underruns = 0
        self.descartadas = 0
        self.perdidas = 0
        self._tarea = None
        self._cola = []
        self._cola_voz = []
        self._tarea_voz = None
        self._fin = False
        self._parar = False
        self._gain = 0
        self._gain_obj = 0
        self._paso = 1
        self._seq_esperado = None
        self._buf = bytearray(config.AUDIO_TRAMA_BYTES)

    # ---------- mensajes ----------

    def locales(self):
        return list(self._listar_locales())

    async def anunciar(self):
        await self._enviar(m.audio_state(
            self.modo, self.song_id, self.source, self.volumen, self.ultimo_seq,
            self._ahora_ms(), self.underruns, self.descartadas))

    async def manejar(self, msg):
        tipo = msg.get("type")
        if tipo == "audio.get":
            await self._enviar(m.ack(msg.get("id")))
            await self.anunciar()
            return
        ref = msg.get("id")
        problema = self._validar(msg)
        if problema:
            await self._enviar(m.error(ref, problema[0], problema[1]))
            return
        seq = msg["seq"]
        if seq <= self.ultimo_seq:
            await self._enviar(m.ack(ref, True, "old_seq"))
            await self.anunciar()
            return
        if tipo == "audio.play":
            if self.modo == VOZ:
                await self._enviar(m.error(ref, "BUSY", "hay una sesión de voz activa"))
                return
            if msg["source"] == "server" and getattr(self._salida, "solo_tonos", False):
                await self._enviar(m.error(ref, "UNSUPPORTED", "esta salida solo toca nanas locales"))
                return
            if msg["source"] == "local" and msg["song_id"] not in self.locales():
                await self._enviar(m.error(ref, "UNKNOWN_SONG", "la canción no está en la cuna"))
                return
            self.ultimo_seq = seq
            await self._enviar(m.ack(ref))
            await self._empezar(msg["song_id"], msg["source"])
        elif tipo == "audio.stop":
            self.ultimo_seq = seq
            await self._enviar(m.ack(ref))
            if self.modo == CANCION:
                self._parar = True   # La tarea baja el volumen, termina y avisa.
            else:
                await self.anunciar()
        elif tipo == "audio.volume":
            self.ultimo_seq = seq
            self.volumen = msg["volume"]
            await self._enviar(m.ack(ref))
            if not self._parar:
                self._fijar_objetivo(rapido=False)
            await self.anunciar()

    def _validar(self, msg):
        tipo = msg.get("type")
        seq = msg.get("seq")
        if not m.es_entero(seq) or seq < 0:
            return "BAD_JSON", "seq debe ser un entero mayor o igual a 0"
        if tipo == "audio.play":
            sid = msg.get("song_id")
            if not isinstance(sid, str) or not sid or len(sid) > 64:
                return "BAD_JSON", "song_id debe ser texto de 1 a 64 caracteres"
            if msg.get("source") not in ("server", "local"):
                return "INVALID_RANGE", "source debe ser server o local"
        elif tipo == "audio.volume":
            v = msg.get("volume")
            if not m.es_entero(v):
                return "BAD_JSON", "volume debe ser un entero"
            if v < 0 or v > 100:
                return "INVALID_RANGE", "volume debe estar entre 0 y 100"
        return None

    # ---------- audio del servidor ----------

    def recibir_trama(self, datos):
        """Recibe un mensaje binario completo, con su cabecera de 8 bytes."""
        if len(datos) < 8:
            return
        version, tipo, seq, _ts = struct.unpack("!BBHI", datos[:8])
        if version != 1 or tipo != TIPO_CANCION:
            return  # Los tipos 1 y 2 son de voz. Se atienden en la etapa 4.
        if self.modo != CANCION or self.source != "server" or self._parar:
            self.descartadas += 1
            return
        n = len(datos) - 8
        if n == 0:
            self._fin = True      # Trama sin audio. Marca el final de la canción.
            return
        if n > config.AUDIO_TRAMA_MAX_BYTES or n % 2:
            self.descartadas += 1
            return
        if self._seq_esperado is not None:
            self.perdidas += (seq - self._seq_esperado) & 0xFFFF
        self._seq_esperado = (seq + 1) & 0xFFFF
        if len(self._cola) >= config.AUDIO_COLA_MAX:
            self.descartadas += 1
            return
        self._cola.append(bytearray(memoryview(datos)[8:]))

    def conexion_perdida(self):
        """Si se cae la conexión, la canción del servidor termina cuando se vacíe el búfer."""
        if self.modo == CANCION and self.source == "server":
            self._fin = True

    # ---------- reproducción ----------

    def _fijar_objetivo(self, rapido):
        self._gain_obj = ganancia_para_volumen(self.volumen)
        self._paso = max(1, 256 // config.AUDIO_TRAMAS_RAMPA)

    async def _parar_ya(self):
        if self._tarea is not None:
            t, self._tarea = self._tarea, None
            await cancelar_y_esperar(t)
        self._salida.cerrar()

    def _ev(self, tipo, detalle, min_ms=0):
        if self._evento:
            self._evento(tipo, detalle, min_ms)

    async def _empezar(self, song_id, source):
        if self.modo == CANCION:
            self._ev("SONG_STOPPED", "%s motivo=reemplazada" % self.song_id)
        await self._parar_ya()
        self.modo, self.song_id, self.source = CANCION, song_id, source
        self._cola = []
        self._fin = False
        self._parar = False
        self._seq_esperado = None
        self._gain = 0
        self._fijar_objetivo(rapido=False)
        await self.anunciar()
        self._ev("SONG_STARTED", "%s source=%s" % (song_id, source))
        self._tarea = asyncio.create_task(self._reproducir(song_id, source))

    def _mover_ganancia(self):
        if self._gain < self._gain_obj:
            self._gain = min(self._gain_obj, self._gain + self._paso)
        elif self._gain > self._gain_obj:
            self._gain = max(self._gain_obj, self._gain - self._paso)

    async def _reproducir(self, song_id, source):
        archivo = None
        natural = False
        try:
            if source == "local":
                archivo = self._abrir_local(song_id)
                if archivo is None:
                    await self._terminar(song_id, False, "no_existe")
                    return
            else:
                if not await self._esperar_prebuffer():
                    return
            self._salida.abrir()
            restantes = None   # Tramas que faltan de la bajada de volumen al parar.
            while True:
                if self._parar and restantes is None:
                    restantes = config.AUDIO_TRAMAS_FADE_OUT
                    self._gain_obj = 0
                    self._paso = max(1, -(-self._gain // restantes))
                if restantes is not None:
                    if restantes == 0:
                        break
                    restantes -= 1
                trama = None
                if source == "local":
                    n = archivo.readinto(self._buf)
                    if not n:
                        natural = True
                        break
                    trama, n_bytes = self._buf, n - (n % 2)
                else:
                    if self._cola:
                        trama = self._cola.pop(0)
                        n_bytes = len(trama)
                    elif self._fin:
                        natural = True
                        break
                    else:
                        self.underruns += 1
                        self._ev("AUDIO_UNDERRUN", "song=%s" % song_id, config.EVENTO_UNDERRUN_CADA_MS)
                        await self._salida.escribir(_TRAMA_SILENCIO)
                        continue
                self._mover_ganancia()
                escalar_pcm16(trama, n_bytes // 2, self._gain)
                await self._salida.escribir(memoryview(trama)[:n_bytes])
        finally:
            if archivo is not None:
                archivo.close()
        # Si se canceló la tarea, el finally corre y la excepción sigue de largo.
        await self._terminar(song_id, natural, "natural" if natural else "stop")

    async def _esperar_prebuffer(self):
        espera_ms = 0
        while len(self._cola) < config.AUDIO_PREBUFFER and not self._fin and not self._parar:
            await asyncio.sleep(0.01)
            espera_ms += 10
            if espera_ms > config.AUDIO_TIMEOUT_PREBUFFER_S * 1000:
                await self._terminar(self.song_id, False, "sin_audio")
                return False
        if self._parar and not self._cola:
            await self._terminar(self.song_id, False, "stop")
            return False
        return True

    async def _terminar(self, song_id, natural, motivo="stop"):
        self._ev("SONG_STOPPED", "%s motivo=%s" % (song_id, motivo))
        self._salida.cerrar()
        self.modo, self.source = IDLE, None
        self._tarea = None
        self._cola = []
        self._parar = False
        try:
            if natural:
                await self._enviar(m.audio_ended(song_id, self._ahora_ms()))
            self.song_id = None
            await self.anunciar()
        except Exception:
            pass  # Si no hay conexión, el estado se manda completo al reconectar.

    async def esperar_fin(self):
        """Espera la reproducción en curso. Sirve para las pruebas."""
        t = self._tarea
        if t is not None:
            try:
                await t
            except asyncio.CancelledError:
                pass

    # ---------- voz de la app, SCRUM-31 ----------
    # La voz usa este mismo gestor para que solo una fuente suene a la vez.
    # El gestor no decide los turnos. Eso lo hace ServicioVoz.

    async def entrar_voz(self):
        """Pasa a modo voz. Una canción que suene se corta con bajada de volumen y no vuelve."""
        if self.modo == CANCION:
            self._parar = True
            await self.esperar_fin()
        self.modo, self.song_id, self.source = VOZ, None, "voice"

    async def salir_voz(self):
        await self.voz_silenciar()
        self.modo, self.source = IDLE, None
        await self.anunciar()

    def encolar_voz(self, payload):
        """Guarda una trama de voz de la app. Devuelve False si se descarta."""
        if getattr(self._salida, "solo_tonos", False):
            return False        # La salida por tonos no puede reproducir voz.
        n = len(payload)
        if n == 0 or n % 2 or n > config.AUDIO_TRAMA_MAX_BYTES:
            return False
        if len(self._cola_voz) >= config.VOZ_COLA_MAX:
            return False
        self._cola_voz.append(bytearray(payload))
        return True

    async def voz_reproducir(self):
        """Empieza a sonar la voz de la app. El volumen entra directo, sin subida gradual."""
        await self._detener_voz_tarea()
        self._gain = self._gain_obj = ganancia_para_volumen(self.volumen)
        self._tarea_voz = asyncio.create_task(self._reproducir_voz())

    async def voz_silenciar(self):
        """Corta la voz de la app y vacía lo que estaba en espera."""
        await self._detener_voz_tarea()
        self._cola_voz = []
        self._salida.cerrar()

    async def _detener_voz_tarea(self):
        t = self._tarea_voz
        self._tarea_voz = None
        await cancelar_y_esperar(t)

    async def _reproducir_voz(self):
        self._salida.abrir()
        iniciado = False
        while True:
            hay = len(self._cola_voz)
            if not iniciado and hay >= config.VOZ_PREBUFFER:
                iniciado = True
            if iniciado and hay == 0:
                self.underruns += 1     # Se acabó el audio. Se vuelve a llenar antes de seguir.
                self._ev("AUDIO_UNDERRUN", "voz", config.EVENTO_UNDERRUN_CADA_MS)
                iniciado = False
            if iniciado:
                trama = self._cola_voz.pop(0)
                self._mover_ganancia()
                escalar_pcm16(trama, len(trama) // 2, self._gain)
                await self._salida.escribir(trama)
            else:
                await self._salida.escribir(_TRAMA_SILENCIO)
