# Lógica de la cuna sin tocar hardware directo. Atiende los mensajes del servidor.

import config
from protocolo import mensajes as m
from servicios.luz_servicio import ServicioLuz
from servicios.ws_cliente import OP_TEXTO

# Mensajes de etapas siguientes. Hoy se responden con UNSUPPORTED.
_VOZ = ("voice.start", "voice.turn", "voice.stop")
_AUDIO = ("audio.play", "audio.stop", "audio.volume", "audio.get")


class CunaApp:
    def __init__(self, cliente, luz, reloj, device_id, token, audio=None, voz=None, evento=None):
        self._cliente = cliente
        self._reloj = reloj
        self._device_id = device_id
        self._token = token
        self.voz = voz       # ServicioVoz o None. Sin voz, voice.* da UNSUPPORTED.
        self.audio = audio   # GestorAudio o None. Sin audio, las órdenes dan UNSUPPORTED.
        self.servicio_luz = ServicioLuz(luz, self.enviar_json, reloj.ahora_ms, evento)

    async def enviar_json(self, msg):
        await self._cliente.enviar_texto(m.codificar(msg))

    def caps(self):
        # Solo se declara lo que esta etapa ya hace.
        locales = self.audio.locales() if self.audio else []
        tonos = bool(self.audio) and getattr(self.audio._salida, "solo_tonos", False)
        caps = {"light": True, "audio_out_hz": config.AUDIO_RATE_HZ, "audio_in_hz": config.MIC_RATE_HZ,
                "local_songs": locales, "voice": self.voz is not None}
        if tonos:
            # Salida por PWM: solo nanas locales como notas. No hay voz de la app ni canciones del servidor.
            caps["audio_out_mode"] = "tones"
            caps["voice_playback"] = False
            caps["server_songs"] = False
        return caps

    async def saludar(self):
        """Manda hello, espera welcome y deja la hora lista. Falla con ErrorWS o ValueError."""
        import asyncio
        await self.enviar_json(m.hello(self._device_id, self._token, config.VERSION_FW,
                                       self.caps(), self._reloj.uptime_ms()))
        opcode, datos = await asyncio.wait_for(self._cliente.recibir(), config.TIMEOUT_WELCOME_S)
        if opcode != OP_TEXTO:
            raise ValueError("se esperaba welcome en texto")
        msg, falla = m.parsear(datos.decode())
        if falla:
            raise ValueError("welcome inválido: %s" % falla[0])
        if msg.get("type") == "error":
            raise ValueError("el servidor rechazó el hello: %s" % msg.get("code"))
        if msg.get("type") != "welcome":
            raise ValueError("se esperaba welcome y llegó %s" % msg.get("type"))
        servidor_ms = msg.get("server_time_ms")
        if isinstance(servidor_ms, int):
            self._reloj.sincronizar_servidor(servidor_ms)
        await self.servicio_luz.anunciar("boot")
        if self.audio:
            await self.audio.anunciar()
        if self.voz:
            await self.voz.informar()

    async def despachar(self, opcode, datos):
        """Atiende un mensaje recibido."""
        if opcode != OP_TEXTO:
            if len(datos) >= 2 and datos[1] == 2:
                if self.voz:
                    self.voz.recibir_trama(datos)
            elif self.audio:
                self.audio.recibir_trama(datos)
            return
        msg, falla = m.parsear(datos.decode())
        if falla:
            await self.enviar_json(m.error(None, falla[0], falla[1]))
            return
        tipo = msg["type"]
        if tipo in ("light.set", "light.get"):
            await self.servicio_luz.manejar(msg)
        elif tipo in _AUDIO and self.audio:
            await self.audio.manejar(msg)
        elif tipo in _VOZ and self.voz:
            await self.voz.manejar(msg)
        elif tipo in _AUDIO or tipo in _VOZ:
            await self.enviar_json(m.error(msg.get("id"), "UNSUPPORTED", "función aún no disponible"))
        # Otros tipos se ignoran en silencio.

    async def enviar_status(self, rssi, free_ram):
        r = self._reloj
        await self.enviar_json(m.status(r.uptime_ms() // 1000, rssi, free_ram,
                                        config.VERSION_FW, r.sincronizado))
