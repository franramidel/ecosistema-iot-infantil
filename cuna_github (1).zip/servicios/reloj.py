# Reloj de la cuna. Da la hora en milisegundos desde 1970, hora universal.
# Zona horaria America/Costa_Rica, UTC-6 sin horario de verano. La cuna no convierte zonas.
# El servidor y la app son los que muestran la hora local.
# Orden: primero NTP. Si falla, la hora que manda el servidor en welcome.

import time

import config

try:
    _mono_ms = time.ticks_ms        # Solo existe en MicroPython.
    _MICRO = True
except AttributeError:
    _MICRO = False


def _mono():
    if _MICRO:
        return time.ticks_ms()
    return int(time.monotonic() * 1000)


class Reloj:
    def __init__(self):
        self.sincronizado = False
        self._base_epoch_ms = 0
        self._base_mono = 0
        self._inicio_mono = _mono()

    def uptime_ms(self):
        if _MICRO:
            return time.ticks_diff(_mono(), self._inicio_mono)
        return _mono() - self._inicio_mono

    def fijar(self, epoch_ms):
        self._base_epoch_ms = epoch_ms
        self._base_mono = _mono()
        self.sincronizado = True

    def ahora_ms(self):
        if not self.sincronizado:
            return 0
        if _MICRO:
            return self._base_epoch_ms + time.ticks_diff(_mono(), self._base_mono)
        return self._base_epoch_ms + (_mono() - self._base_mono)

    def sincronizar_ntp(self):
        """Intenta NTP. Devuelve True si funcionó."""
        try:
            import ntptime
            ntptime.settime()
        except Exception:
            return False
        # En rp2 la época de time.time es el año 2000. Se corrige a 1970.
        offset = config.SEGUNDOS_EPOCA_2000_A_1970 if time.gmtime(0)[0] == 2000 else 0
        self.fijar((time.time() + offset) * 1000)
        return True

    def sincronizar_servidor(self, epoch_ms):
        if not self.sincronizado:
            self.fijar(epoch_ms)
