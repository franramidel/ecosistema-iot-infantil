# Supervisor de reconexión. Repite sesiones para siempre, con esperas crecientes.
# Las esperas siguen el contrato: 1, 2, 4, 8, 16 y 30 segundos, y después cada 30.
# La cuenta de esperas vuelve a empezar cuando una sesión llega a welcome.

import asyncio

import config


async def supervisar(una_sesion, estado, esperas=None, dormir=None, avisar=None):
    """una_sesion es una corrutina sin argumentos que dura mientras haya conexión.
    estado es un dict con la clave paso, que la sesión pone en 0 al llegar a welcome."""
    esperas = esperas or config.ESPERAS_RECONEXION_S
    dormir = dormir or asyncio.sleep
    while True:
        try:
            await una_sesion()
        except asyncio.CancelledError:
            raise
        except Exception as e:
            if avisar:
                avisar("sesión terminada: %r" % (e,))
        espera = esperas[min(estado["paso"], len(esperas) - 1)]
        estado["paso"] += 1
        await dormir(espera)
