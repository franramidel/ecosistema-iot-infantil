# Puente entre los servicios y la conexión actual. La conexión puede caer y volver,
# pero la luz y el audio siguen vivos. Los servicios mandan por aquí y el enlace
# descarta el mensaje si no hay conexión abierta.

from protocolo import mensajes as m


class Enlace:
    def __init__(self):
        self.cliente = None

    async def enviar_json(self, msg):
        c = self.cliente
        if c is not None and c.abierto:
            await c.enviar_texto(m.codificar(msg))

    async def enviar_binario(self, datos):
        c = self.cliente
        if c is not None and c.abierto:
            await c.enviar_binario(datos)
