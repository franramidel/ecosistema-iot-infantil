# Una sesión de la cuna con el servidor, de principio a fin. Aquí se une todo: la conexión,
# el saludo, las órdenes, el latido, los eventos y la limpieza al caerse.
# Las piezas de hardware llegan ya armadas. Así esta parte se prueba sin Pico.

import asyncio

import config
from servicios.cuna_app import CunaApp
from servicios.ws_cliente import ClienteWS


async def latido(app, leer_estado):
    """Manda status al conectar y luego cada 30 segundos."""
    while True:
        rssi, free_ram = leer_estado()
        await app.enviar_status(rssi, free_ram)
        await asyncio.sleep(config.LATIDO_S)


class Cuna:
    def __init__(self, luz, audio, voz, reloj, enlace, registro, host, puerto, device_id, token,
                 leer_estado=lambda: (None, 0), asegurar_red=None, estado=None, crear_cliente=ClienteWS):
        self.luz, self.audio, self.voz = luz, audio, voz
        self.reloj, self.enlace, self.registro = reloj, enlace, registro
        self._host, self._puerto = host, puerto
        self._device_id, self._token = device_id, token
        self._leer_estado = leer_estado
        self._asegurar_red = asegurar_red      # Corrutina que deja el Wi-Fi listo o falla.
        self._crear_cliente = crear_cliente
        self.estado = estado if estado is not None else {"paso": 0}
        self.sesiones = 0                      # Cuántas veces llegó a welcome. Sirve para pruebas.

    async def una_sesion(self):
        if self._asegurar_red is not None:
            await self._asegurar_red()
        cliente = self._crear_cliente(self._host, self._puerto, config.WS_RUTA, config.WS_MAX_PAYLOAD)
        app = CunaApp(cliente, self.luz, self.reloj, self._device_id, self._token,
                      self.audio, self.voz, self.registro.evento)
        tareas = []
        await cliente.conectar()
        self.enlace.cliente = cliente
        try:
            await app.saludar()
            self.estado["paso"] = 0           # Conectó bien. La cuenta de esperas vuelve a empezar.
            self.sesiones += 1
            tareas.append(asyncio.create_task(latido(app, self._leer_estado)))
            tareas.append(asyncio.create_task(self.registro.emisor(self.enlace.enviar_json)))
            self.registro.pendiente()          # Manda lo que se acumuló sin conexión.
            while True:
                opcode, datos = await asyncio.wait_for(
                    cliente.recibir(), config.TIMEOUT_SIN_MENSAJES_S)
                await app.despachar(opcode, datos)
        finally:
            for t in tareas:
                t.cancel()
            self.enlace.cliente = None
            try:
                await self.voz.terminar(False)   # Sin conexión el micrófono se apaga siempre.
            except Exception:
                pass
            self.audio.conexion_perdida()        # Una canción del servidor termina al vaciarse el búfer.
            await cliente.cerrar()
