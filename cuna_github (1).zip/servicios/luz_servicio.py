# Atiende las órdenes light.set y light.get de SCRUM-29.

import asyncio

import config
from protocolo import mensajes as m


class ServicioLuz:
    def __init__(self, luz, enviar, ahora_ms, evento=None):
        # enviar es una corrutina que manda un dict como JSON.
        # ahora_ms es una función que da la hora en milisegundos.
        self._luz = luz
        self._evento = evento      # Función evento tipo, detalle. Puede ser None.
        self._enviar = enviar
        self._ahora_ms = ahora_ms
        self.ultimo_seq = 0
        self._tarea = None

    async def anunciar(self, causa):
        """Manda el estado actual. Se usa al conectar."""
        on, brillo = self._luz.estado()
        await self._enviar(m.light_state(self.ultimo_seq, on, brillo, causa, self._ahora_ms()))

    async def manejar(self, msg):
        tipo = msg.get("type")
        if tipo == "light.set":
            await self._set(msg)
        elif tipo == "light.get":
            await self._get(msg)

    async def _get(self, msg):
        await self._enviar(m.ack(msg.get("id")))
        await self.anunciar("command")

    def _validar_set(self, msg):
        """Devuelve None si es válido. Si no, un par codigo, detalle."""
        seq, on = msg.get("seq"), msg.get("on")
        if not m.es_entero(seq) or seq < 0:
            return "BAD_JSON", "seq debe ser un entero mayor o igual a 0"
        if not isinstance(on, bool):
            return "BAD_JSON", "on debe ser verdadero o falso"
        brillo = msg.get("brightness")
        if brillo is not None:
            if not m.es_entero(brillo):
                return "BAD_JSON", "brightness debe ser un entero"
            if brillo < 0 or brillo > 100:
                return "INVALID_RANGE", "brightness debe estar entre 0 y 100"
        fade = msg.get("fade_ms")
        if fade is not None:
            if not m.es_entero(fade):
                return "BAD_JSON", "fade_ms debe ser un entero"
            if fade < 0 or fade > config.LUZ_FADE_MAX_MS:
                return "INVALID_RANGE", "fade_ms debe estar entre 0 y %d" % config.LUZ_FADE_MAX_MS
        return None

    async def _set(self, msg):
        ref = msg.get("id")
        problema = self._validar_set(msg)
        if problema:
            await self._enviar(m.error(ref, problema[0], problema[1]))
            return
        seq = msg["seq"]
        if seq <= self.ultimo_seq:
            # Orden vieja o repetida. No se aplica.
            await self._enviar(m.ack(ref, True, "old_seq"))
            await self.anunciar("command")
            return
        self.ultimo_seq = seq
        await self._enviar(m.ack(ref))
        fade = msg.get("fade_ms")
        if fade is None:
            fade = config.LUZ_FADE_DEFECTO_MS
        # Una orden nueva corta la transición anterior.
        if self._tarea is not None:
            self._tarea.cancel()
        self._tarea = asyncio.create_task(
            self._aplicar(msg["on"], msg.get("brightness"), fade, seq))

    async def _aplicar(self, encender, brillo, fade, seq):
        await self._luz.ir_a(encender, brillo, fade)
        on, nivel = self._luz.estado()
        if self._evento:
            self._evento("LIGHT_CHANGED", "on=%s brightness=%d cause=command" % (
                "true" if on else "false", nivel))
        try:
            await self._enviar(m.light_state(seq, on, nivel, "command", self._ahora_ms()))
        except Exception:
            # La conexión cayó durante la transición. La luz ya quedó bien. Al reconectar
            # se manda el estado completo con anunciar.
            pass

    async def esperar_fin(self):
        """Espera la transición en curso. Sirve para las pruebas."""
        if self._tarea is not None:
            try:
                await self._tarea
            except asyncio.CancelledError:
                pass
