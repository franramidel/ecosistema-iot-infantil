# Volumen por software. Escala muestras de 16 bits con signo, en el mismo búfer.
# La ganancia va en punto fijo con 8 bits de fracción. 256 vale 1,0.

import config

try:
    import micropython
    _rapido = micropython.viper
    _VIPER = True
except ImportError:
    # En una PC normal no existe viper. Se usa el mismo código sin compilar.
    def _rapido(f):
        return f

    def ptr16(obj):
        return memoryview(obj).cast("B").cast("H")
    _VIPER = False


@_rapido
def _escalar(datos, n: int, ganancia: int):
    p = ptr16(datos)
    for i in range(n):
        # La documentación no dice si ptr16 es con o sin signo. Este código sirve en ambos.
        s = int(p[i]) & 0xFFFF
        if s >= 0x8000:
            s -= 0x10000
        s = (s * ganancia) >> 8
        p[i] = s & 0xFFFF


def escalar_pcm16(datos, n_muestras, ganancia_q8):
    """Multiplica en sitio n_muestras muestras de datos, que debe ser bytearray."""
    if ganancia_q8 == 256:
        return
    _escalar(datos, n_muestras, ganancia_q8)


def ganancia_para_volumen(volumen):
    """De un volumen de 0 a 100 a ganancia q8. Curva cuadrática y tope de configuración."""
    if volumen <= 0:
        return 0
    g = (volumen / 100) ** 2 * config.AUDIO_GANANCIA_MAX
    return int(256 * g)
