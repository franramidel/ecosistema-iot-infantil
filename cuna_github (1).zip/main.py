# Arranque de la cuna. Esta parte toca hardware real.
# Estado: IMPLEMENTADO NO PROBADO EN HARDWARE.

import asyncio
import gc
import os

import network
from machine import PWM, Pin, WDT

import config
from hal.audio_out import SalidaI2S
from hal.audio_tonos import SalidaTonos
from hal.luz import Luz
from hal.mic import crear_microfono
from servicios.enlace import Enlace
from servicios.eventos import Registro
from servicios.gestor_audio import GestorAudio
from servicios.reloj import Reloj
from servicios.sesion import Cuna
from servicios.supervisor import supervisar
from servicios.voz import ServicioVoz

try:
    import secrets
except ImportError:
    raise SystemExit("Falta secrets.py. Copia secrets_example.py y llénalo.")


def listar_locales():
    try:
        return [n[:-4] for n in os.listdir(config.RUTA_NANAS) if n.endswith(".pcm")]
    except OSError:
        return []


def abrir_local(song_id):
    try:
        return open("%s/%s.pcm" % (config.RUTA_NANAS, song_id), "rb")
    except OSError:
        return None


async def alimentar_wdt(wdt):
    # Si el bucle de asyncio se traba, esto deja de correr y el perro reinicia la Pico.
    while True:
        wdt.feed()
        await asyncio.sleep(config.WDT_ALIMENTAR_S)


async def principal():
    wdt = WDT(timeout=config.WDT_MS)
    asyncio.create_task(alimentar_wdt(wdt))
    wlan = network.WLAN(network.STA_IF)

    async def asegurar_red():
        if wlan.isconnected():
            return
        wlan.active(True)
        wlan.connect(secrets.WIFI_SSID, secrets.WIFI_CLAVE)
        for _ in range(20):
            if wlan.isconnected():
                return
            await asyncio.sleep(1)
        raise OSError("sin Wi-Fi")

    def leer_estado():
        gc.collect()
        # El rssi se deja en None. No confirmé en la documentación cómo leerlo.
        return None, gc.mem_free()

    reloj = Reloj()
    registro = Registro(reloj.ahora_ms, reloj.uptime_ms, lambda: reloj.sincronizado)
    enlace = Enlace()
    # La luz y el audio viven aparte de la conexión. Si el Wi-Fi cae, siguen con su estado.
    luz = Luz(PWM(Pin(config.PIN_LUZ)))
    salida = SalidaTonos() if config.AUDIO_SALIDA == "tonos" else SalidaI2S()
    audio = GestorAudio(salida, enlace.enviar_json, reloj.ahora_ms,
                        abrir_local, listar_locales, registro.evento)
    voz = ServicioVoz(audio, crear_microfono(), enlace.enviar_json, enlace.enviar_binario,
                      reloj.ahora_ms, registro.evento)
    cuna = Cuna(luz, audio, voz, reloj, enlace, registro, secrets.SERVIDOR_HOST,
                secrets.SERVIDOR_PUERTO, secrets.DEVICE_ID, secrets.TOKEN,
                leer_estado, asegurar_red)
    registro.evento("DEVICE_BOOT", "fw=%s" % config.VERSION_FW)

    async def una_sesion():
        if not reloj.sincronizado:
            reloj.sincronizar_ntp()
        await cuna.una_sesion()

    await supervisar(una_sesion, cuna.estado, avisar=print)


asyncio.run(principal())
