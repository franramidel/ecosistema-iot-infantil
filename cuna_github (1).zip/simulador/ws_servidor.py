# Servidor WebSocket mínimo con solo la biblioteca estándar de Python.
# Sirve para el simulador. No es un servidor para producción.
# Implementa lo justo del RFC 6455: apretón de manos, texto, binario, ping, pong, cierre
# y mensajes fragmentados. Sin compresión y sin TLS.
# Su forma imita lo básico de la librería websockets, para que el simulador y las pruebas
# se lean igual: recv, send, close, request.path y async for.

import asyncio
import base64
import hashlib
import struct

_GUID = b"258EAFA5-E914-47DA-95CA-C5AB0DC85B11"


class ConnectionClosed(Exception):
    pass


class _Peticion:
    def __init__(self, path):
        self.path = path


class Conexion:
    def __init__(self, reader, writer, path, max_payload):
        self._r = reader
        self._w = writer
        self._max = max_payload
        self._candado = asyncio.Lock()
        self.request = _Peticion(path)
        self.cerrada = False

    async def _enviar_trama(self, opcode, datos):
        if self.cerrada:
            raise ConnectionClosed("conexión cerrada")
        n = len(datos)
        if n < 126:
            cab = struct.pack("!BB", 0x80 | opcode, n)
        elif n < 65536:
            cab = struct.pack("!BBH", 0x80 | opcode, 126, n)
        else:
            cab = struct.pack("!BBQ", 0x80 | opcode, 127, n)
        async with self._candado:
            try:
                self._w.write(cab + datos)
                await self._w.drain()
            except (ConnectionError, OSError):
                self.cerrada = True
                raise ConnectionClosed("se perdió la conexión")

    async def send(self, mensaje):
        if isinstance(mensaje, str):
            await self._enviar_trama(0x1, mensaje.encode())
        else:
            await self._enviar_trama(0x2, bytes(mensaje))

    async def escribir_crudo(self, datos):
        """Escribe bytes tal cual, sin formato. Sirve para probar cómo reacciona la cuna a basura."""
        self._w.write(datos)
        await self._w.drain()

    async def _leer_trama(self):
        try:
            cab = await self._r.readexactly(2)
            b0, b1 = cab
            if not (b1 & 0x80):
                await self.close(1002, "el cliente debe enmascarar")
                raise ConnectionClosed("trama sin máscara")
            n = b1 & 0x7F
            if n == 126:
                n = struct.unpack("!H", await self._r.readexactly(2))[0]
            elif n == 127:
                n = struct.unpack("!Q", await self._r.readexactly(8))[0]
            if n > self._max:
                await self.close(1009, "mensaje demasiado grande")
                raise ConnectionClosed("mensaje demasiado grande")
            mascara = await self._r.readexactly(4)
            datos = await self._r.readexactly(n) if n else b""
        except (asyncio.IncompleteReadError, ConnectionError, OSError):
            self.cerrada = True
            raise ConnectionClosed("el cliente cerró sin avisar")
        if n:
            clave = (mascara * (n // 4 + 1))[:n]
            datos = (int.from_bytes(datos, "little") ^ int.from_bytes(clave, "little")).to_bytes(n, "little")
        return b0 & 0x80, b0 & 0x0F, datos

    async def recv(self):
        """Devuelve un mensaje completo, str si es texto y bytes si es binario."""
        acumulado, tipo = b"", None
        while True:
            fin, opcode, datos = await self._leer_trama()
            if opcode == 0x8:
                self.cerrada = True
                try:
                    self._w.write(struct.pack("!BB", 0x88, 0))
                    await self._w.drain()
                except Exception:
                    pass
                raise ConnectionClosed("el cliente cerró")
            if opcode == 0x9:
                await self._enviar_trama(0xA, datos)
                continue
            if opcode == 0xA:
                continue
            if opcode in (0x1, 0x2):
                tipo, acumulado = opcode, datos
            elif opcode == 0x0 and tipo is not None:
                acumulado += datos
            else:
                await self.close(1002, "trama inesperada")
                raise ConnectionClosed("trama inesperada")
            if len(acumulado) > self._max:
                await self.close(1009, "mensaje demasiado grande")
                raise ConnectionClosed("mensaje demasiado grande")
            if fin:
                return acumulado.decode() if tipo == 0x1 else acumulado

    async def close(self, codigo=1000, razon=""):
        if not self.cerrada:
            self.cerrada = True
            try:
                self._w.write(struct.pack("!BBH", 0x88, 2 + len(razon.encode()), codigo) + razon.encode())
                await self._w.drain()
            except Exception:
                pass
        try:
            self._w.close()
        except Exception:
            pass

    def abortar(self):
        """Corta la conexión sin enviar nada. Imita una caída del Wi-Fi."""
        self.cerrada = True
        try:
            self._w.transport.abort()
        except Exception:
            pass

    def __aiter__(self):
        return self

    async def __anext__(self):
        try:
            return await self.recv()
        except ConnectionClosed:
            raise StopAsyncIteration


class ServidorWS:
    def __init__(self, manejador, max_payload):
        self._manejador = manejador
        self._max = max_payload
        self._server = None
        self._conexiones = set()

    @property
    def sockets(self):
        return self._server.sockets

    async def _atender(self, reader, writer):
        try:
            linea = await asyncio.wait_for(reader.readline(), 5)
            partes = linea.decode(errors="replace").split()
            cabeceras = {}
            while True:
                l = await asyncio.wait_for(reader.readline(), 5)
                if l in (b"\r\n", b"\n", b""):
                    break
                k, _, v = l.decode(errors="replace").partition(":")
                cabeceras[k.strip().lower()] = v.strip()
            clave = cabeceras.get("sec-websocket-key")
            if (len(partes) < 3 or partes[0] != "GET" or "websocket" not in cabeceras.get("upgrade", "").lower()
                    or not clave or cabeceras.get("sec-websocket-version") != "13"):
                writer.write(b"HTTP/1.1 400 Bad Request\r\nConnection: close\r\nContent-Length: 0\r\n\r\n")
                await writer.drain()
                return
            acepta = base64.b64encode(hashlib.sha1(clave.encode() + _GUID).digest()).decode()
            writer.write(("HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\n"
                          "Connection: Upgrade\r\nSec-WebSocket-Accept: %s\r\n\r\n" % acepta).encode())
            await writer.drain()
            conn = Conexion(reader, writer, partes[1], self._max)
            self._conexiones.add(conn)
            try:
                await self._manejador(conn)
            except ConnectionClosed:
                pass
            finally:
                self._conexiones.discard(conn)
                await conn.close()
        except (asyncio.TimeoutError, ConnectionError, OSError):
            pass
        finally:
            try:
                writer.close()
            except Exception:
                pass

    def close(self):
        self._server.close()
        for c in list(self._conexiones):
            c.abortar()

    async def wait_closed(self):
        await self._server.wait_closed()

    async def __aenter__(self):
        return self

    async def __aexit__(self, *a):
        self.close()
        await self.wait_closed()


async def servir(manejador, host, puerto, max_payload=65536):
    s = ServidorWS(manejador, max_payload)
    s._server = await asyncio.start_server(s._atender, host, puerto)
    return s
