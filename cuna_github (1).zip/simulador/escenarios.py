# Escenarios automáticos para probar la cuna contra el servidor simulado.
# Sirve igual con la cuna real (la Pico) y con la cuna de software de las pruebas.
# Un PASS aquí solo prueba que la cuna cumple el contrato. NO prueba que la luz
# se vea ni que el sonido se oiga: eso lo confirma una persona frente al hardware.

import asyncio
import struct
import time

PCM_TONO = None


def _tono(ms=1000, hz=440, amp=6000):
    """Un tono de prueba PCM16 mono a 16 kHz, hecho a mano para no depender de archivos."""
    import math
    n = 16 * ms
    return b"".join(struct.pack("<h", int(amp * math.sin(2 * math.pi * hz * i / 16000))) for i in range(n))


class Corrida:
    def __init__(self, srv, imprimir=print, humano=True, con_corte=False):
        self.srv = srv
        self.imprimir = imprimir
        self.humano = humano
        self.con_corte = con_corte
        self.resultados = []          # (nombre, ok, detalle)
        self.para_humano = []         # Cosas que solo una persona puede confirmar.

    # Ayudas ---------------------------------------------------------------
    async def espera(self, pred, timeout=4):
        """Espera un mensaje recibido que cumpla pred. Mira todo lo recibido, no solo lo nuevo."""
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            for m in self.srv.recibidos:
                if pred(m):
                    return m
            await asyncio.sleep(0.02)
        raise AssertionError("no llegó lo esperado en %.1f s" % timeout)

    def desde(self):
        return len(self.srv.recibidos)

    async def nuevo(self, pred, marca, timeout=4):
        fin = time.monotonic() + timeout
        while time.monotonic() < fin:
            for m in self.srv.recibidos[marca:]:
                if pred(m):
                    return m
            await asyncio.sleep(0.02)
        raise AssertionError("no llegó lo esperado en %.1f s" % timeout)

    async def paso(self, nombre, coro, humano=None):
        try:
            detalle = await coro
            self.resultados.append((nombre, True, detalle or ""))
            self.imprimir("PASS  %s%s" % (nombre, (" · " + detalle) if detalle else ""))
        except Exception as e:
            self.resultados.append((nombre, False, str(e) or type(e).__name__))
            self.imprimir("FAIL  %s · %s" % (nombre, str(e) or type(e).__name__))
        if humano and self.humano:
            self.para_humano.append(humano)

    # Pasos ----------------------------------------------------------------
    async def s_hello(self):
        h = self.srv.hello
        assert h and h["type"] == "hello", "no llegó hello"
        for k in ("device_id", "fw", "caps"):
            assert k in h, "al hello le falta " + k
        return "fw=%s, caps=%s" % (h["fw"], h["caps"])

    async def s_estado_inicial(self):
        m = self.desde()
        await self.srv.mandar({"v": 1, "type": "light.get", "id": "e-lg"})
        await self.srv.mandar({"v": 1, "type": "audio.get", "id": "e-ag"})
        l = await self.nuevo(lambda x: x["type"] == "light.state", m)
        a = await self.nuevo(lambda x: x["type"] == "audio.state", m)
        return "luz on=%s brillo=%s, audio %s vol=%s" % (l["on"], l["brightness"], a["mode"], a["volume"])

    async def s_luz(self):
        m = self.desde()
        await self.srv.light_set(True, 40, fade_ms=300, seq=101)
        ack = await self.nuevo(lambda x: x["type"] == "ack", m)
        est = await self.nuevo(lambda x: x["type"] == "light.state" and x["brightness"] == 40, m)
        assert est["on"] is True, "no quedó encendida"
        await asyncio.sleep(0.5)
        await self.srv.light_set(False, fade_ms=300, seq=102)
        await self.nuevo(lambda x: x["type"] == "light.state" and x["on"] is False, m)
        return "ack y estado correctos al encender y apagar"

    async def s_luz_errores(self):
        m = self.desde()
        await self.srv.light_set(True, 200, seq=103, validar_salida=False)
        e = await self.nuevo(lambda x: x["type"] == "error", m)
        assert e["code"] == "INVALID_RANGE", "esperaba INVALID_RANGE y llegó " + e["code"]
        m = self.desde()
        await self.srv.light_set(True, 10, seq=103)               # seq repetido
        await asyncio.sleep(0.4)
        nuevos = self.srv.recibidos[m:]
        assert not any(x["type"] == "light.state" and x.get("cause") == "command" for x in nuevos), \
            "obedeció una orden con seq viejo"
        return "rango inválido rechazado y seq viejo ignorado"

    async def s_nana_local(self):
        m = self.desde()
        await self.srv.audio_volume(40)
        await self.srv.audio_play("nana-1", "local")
        a = await self.nuevo(lambda x: x["type"] == "audio.state" and x["mode"] == "song", m)
        assert a["song_id"] == "nana-1"
        await asyncio.sleep(1.5)
        m = self.desde()
        await self.srv.audio_stop()
        await self.nuevo(lambda x: x["type"] == "audio.state" and x["mode"] == "idle", m)
        return "arrancó, quedó en modo song y paró con audio.stop"

    async def s_audio_errores(self):
        m = self.desde()
        await self.srv.audio_play("no-existe", "local")
        e = await self.nuevo(lambda x: x["type"] == "error", m)
        assert e["code"] == "UNKNOWN_SONG", "llegó " + e["code"]
        return "UNKNOWN_SONG"

    async def s_cancion_servidor(self):
        m = self.desde()
        await self.srv.audio_play("tono", "server")
        await self.nuevo(lambda x: x["type"] == "audio.state", m)
        await self.srv.transmitir(_tono(1500))
        fin = await self.nuevo(lambda x: x["type"] == "audio.ended", m, timeout=6)
        return "audio.ended natural, song_id=%s" % fin["song_id"]

    async def s_voz(self):
        m = self.desde()
        n0 = len(self.srv.voz_cuna)
        await self.srv.voice_start("esc-1", "cradle")
        v = await self.nuevo(lambda x: x["type"] == "voice.state" and x["active"], m)
        await asyncio.sleep(2.0)
        recibidas = len(self.srv.voz_cuna) - n0
        seqs = [t[0] for t in self.srv.voz_cuna[n0:]]
        assert recibidas > 0, "el micrófono no mandó tramas (¿está conectado?)"
        saltos = sum(1 for a, b in zip(seqs, seqs[1:]) if (b - a) & 0xFFFF != 1)
        await self.srv.voice_turn("app")
        await self.nuevo(lambda x: x["type"] == "voice.state" and x.get("turn") == "app", m)
        await self.srv.mandar_voz(_tono(800))
        await asyncio.sleep(0.4)
        m2 = self.desde()
        await self.srv.voice_stop()
        await self.nuevo(lambda x: x["type"] == "voice.state" and not x["active"], m2)
        hz = v.get("mic_hz_real")
        return "%d tramas del micrófono, %d saltos de seq, mic_hz_real=%s" % (recibidas, saltos, hz)

    async def s_voz_y_nana(self):
        m = self.desde()
        await self.srv.audio_play("nana-1", "local")
        await self.nuevo(lambda x: x["type"] == "audio.state" and x["mode"] == "song", m)
        await self.srv.voice_start("esc-2")
        await self.nuevo(lambda x: x["type"] == "voice.state" and x["active"], m)
        a = [x for x in self.srv.recibidos[m:] if x["type"] == "audio.state"][-1]
        assert a["mode"] != "song", "la nana siguió sonando durante la voz"
        await self.srv.voice_stop()
        await asyncio.sleep(0.5)
        a = self.srv.recibidos[-1]
        m2 = self.desde()
        await self.srv.mandar({"v": 1, "type": "audio.get", "id": "vn-ag"})
        a = await self.nuevo(lambda x: x["type"] == "audio.state", m2)
        assert a["mode"] == "idle", "la nana volvió sola tras la voz (modo %s)" % a["mode"]
        return "la voz cortó la nana y esta no volvió sola"

    async def s_mensajes_malos(self):
        m = self.desde()
        await self.srv.conexion.send("esto no es json")
        e = await self.nuevo(lambda x: x["type"] == "error", m)
        assert e["code"] == "BAD_JSON", "llegó " + e["code"]
        m = self.desde()
        await self.srv.mandar({"v": 9, "type": "light.get", "id": "bv"}, validar_salida=False)
        e = await self.nuevo(lambda x: x["type"] == "error", m)
        assert e["code"] == "BAD_VERSION", "llegó " + e["code"]
        return "BAD_JSON y BAD_VERSION"

    async def s_latido(self):
        m = self.desde()
        await self.srv.mandar({"v": 1, "type": "light.get", "id": "st"})
        s = [x for x in self.srv.recibidos if x["type"] == "status"]
        assert s, "la cuna no ha mandado status"
        return "último status: rssi=%s, free_ram=%s, uptime_s=%s" % (
            s[-1].get("rssi"), s[-1].get("free_ram"), s[-1].get("uptime_s"))

    async def s_reconexion(self):
        n = self.srv.n_hello
        self.srv.cortar()
        await self.srv.esperar_hello(n + 1, timeout=75)
        await asyncio.sleep(0.5)
        return "la cuna volvió a conectar sola (conexión número %d)" % self.srv.n_hello

    # Corrida --------------------------------------------------------------
    async def correr(self):
        await self.paso("hello con token válido", self.s_hello())
        await self.paso("estado inicial de luz y audio", self.s_estado_inicial())
        await self.paso("luz: encender, apagar, ack y estado", self.s_luz(),
                        "Al encender se debe ver la luz subir al 40 por ciento en unos 0,3 s y luego apagarse.")
        await self.paso("luz: rango inválido y seq viejo", self.s_luz_errores())
        await self.paso("nana local: play, stop", self.s_nana_local(),
                        "Debe oírse la nana 1 con volumen bajo durante unos 1,5 s y cortarse sin chasquido fuerte.")
        await self.paso("audio: canción desconocida", self.s_audio_errores())
        await self.paso("canción desde el servidor, fin natural", self.s_cancion_servidor(),
                        "Debe oírse un tono de 440 Hz de 1,5 s sin cortes.")
        await self.paso("voz por turnos con micrófono", self.s_voz(),
                        "Hablar cerca del micrófono durante los 2 s. Luego debe oírse un tono corto por el parlante.")
        await self.paso("voz corta la nana", self.s_voz_y_nana())
        await self.paso("mensajes mal formados", self.s_mensajes_malos())
        await self.paso("status periódico", self.s_latido())
        if self.con_corte:
            await self.paso("corte de conexión y reconexión", self.s_reconexion())
        if self.srv.problemas:
            self.resultados.append(("cumple el contrato al hablar con el servidor", False, "; ".join(self.srv.problemas[:3])))
            self.imprimir("FAIL  la cuna mandó mensajes fuera del contrato: %s" % self.srv.problemas[:3])
        else:
            self.resultados.append(("cumple el contrato al hablar con el servidor", True, ""))
            self.imprimir("PASS  todo lo que mandó la cuna cumple el contrato")
        return self.resultados

    def resumen(self):
        ok = sum(1 for _, b, _ in self.resultados if b)
        lineas = ["", "Resultado: %d de %d pasos pasaron." % (ok, len(self.resultados)),
                  "Esto es una prueba con SERVIDOR SIMULADO. No es integración con el servidor real."]
        if self.para_humano:
            lineas.append("Una persona debe confirmar frente al hardware:")
            lineas += ["  - " + t for t in self.para_humano]
        return "\n".join(lineas)
