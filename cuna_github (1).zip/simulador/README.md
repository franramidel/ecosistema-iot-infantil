# Simulador del servidor

Este simulador hace de servidor para probar la cuna sin el servidor real de Jan Carlo. No es un segundo backend. No tiene base de datos, ni cuentas, ni autenticación propia. Solo revisa un token, manda órdenes y comprueba que lo que llega cumple el contrato.

Solo necesita Python 3.10 o más nuevo. No hay que instalar nada. La librería websockets es opcional y solo la usa la prueba de compatibilidad tests/test_interop.py.

## Correrlo en tu PC

Desde la carpeta cuna.

    python3 -m simulador.servidor_sim --host 0.0.0.0 --puerto 8080 --token TOKEN_DE_PRUEBA

Usa 0.0.0.0 para que la Pico lo alcance por el Wi-Fi. En secrets.py de la cuna pon la IP de tu PC, el puerto 8080 y el mismo token. Tu PC y la Pico deben estar en la misma red. Revisa que el firewall deje pasar el puerto 8080.

## Órdenes de la consola

| Escribe | Qué hace |
| --- | --- |
| on 40 | Enciende la luz al 40 por ciento |
| off | Apaga la luz |
| get | Pide el estado de la luz |
| vol 40 | Pone el volumen de 0 a 100 |
| play local nana-1 | Suena una nana guardada en la cuna |
| play server assets/nana-1.pcm | El simulador manda la nana por la red |
| stop | Detiene el audio |
| voz start | Inicia la voz con turno de la cuna. Se enciende el micrófono |
| voz turno app | Pasa el turno a la app |
| voz decir assets/nana-1.pcm | Manda voz de la app a la cuna |
| voz stop | Termina la voz y guarda voz_cuna.wav |

Todo lo que manda la cuna se imprime con una flecha. Si la cuna manda algo fuera del contrato, el simulador lo anota en la lista de problemas.

## Escenario automático

    python3 -m simulador.servidor_sim --puerto 8080 --escenario completo

Espera a que la cuna se conecte, corre 12 pasos y termina con código 0 si todo pasó. Con --escenario con-corte agrega un paso que corta la conexión y comprueba que la cuna vuelve sola. Ese paso puede tardar hasta un minuto si la cuna está en una espera larga.

Un PASS solo dice que la cuna cumple el contrato. No dice que la luz se vea ni que el sonido se oiga. Al final el escenario imprime qué debe confirmar una persona.

## Probar sin la Pico

Para ver el simulador funcionar sin hardware hay una cuna hecha solo de software. En una terminal.

    python3 -m simulador.servidor_sim --puerto 8080 --escenario con-corte

En otra terminal.

    python3 -m simulador.cuna_software --puerto 8080

Esta cuna de software no suena, no enciende luz y su micrófono es un valor fijo.

## Pruebas automáticas

    python3 -m unittest discover -s tests -t . -v

## Qué es una prueba con simulador y qué no

Una prueba con este simulador valida el formato de los mensajes, el orden de las respuestas y el manejo de errores. No valida el servidor real, la app, el Wi-Fi de tu casa ni el hardware. Cuando Jan Carlo tenga su servidor, hay que repetir los pasos con él. La lista está en ETAPA5_integracion.md, sección 6.
