# Simulador del servidor de Jan Carlo, solo para probar la cuna sin su servidor real.
# NO es el servidor real. Valida el token, manda welcome y registra lo que llega.
# Se corre en tu PC con Python 3. No necesita instalar nada, usa solo la biblioteca estándar.
#   python3 simulador/servidor_sim.py --host 0.0.0.0 --puerto 8080 --token TOKEN_DE_PRUEBA
# Después escribe órdenes en la consola, por ejemplo:
#   on 40      enciende al 40 por ciento
#   off        apaga
#   get        pide el estado
#   play local nana-1          suena una nana guardada en la cuna
#   play server assets/nana-1.pcm   el simulador manda la nana por la red
#   stop       detiene el audio
#   vol 40     pone el volumen de 0 a 100
#   voz start          inicia la voz, turno de la cuna, se enciende el micrófono
#   voz turno app      cambia el turno a la app. Luego voz decir assets/nana-1.pcm
#   voz stop           termina la voz y guarda voz_cuna.wav con lo que oyó la cuna

import argparse
import asyncio
import json
import struct
import time
import wave

from simulador.validar import validar, validar_trama
from simulador.ws_servidor import ConnectionClosed, servir

RUTA = "/ws/cuna"


class ServidorSim:
    def __init__(self, token):
        self.token = token
        self.recibidos = []          # Todo lo que mandó la cuna, ya como dict.
        self.conexion = None
        self.seq = 0
        self.hello = None
        self.voz_cuna = []            # Tramas de voz tipo 1 recibidas: seq, ts, audio.
        self.session = None
        self.n_hello = 0              # Cuántas veces se conectó una cuna.
        self._cola = asyncio.Queue()
        self.rechazar_token = False
        self.problemas = []           # Todo lo que la cuna mandó fuera del contrato.

    async def manejador(self, ws):
        if ws.request.path != RUTA:
            await ws.close(1008, "ruta inválida")
            return
        primero = json.loads(await ws.recv())
        self._revisar(primero)
        if primero.get("type") != "hello" or primero.get("token") != self.token:
            await ws.send(json.dumps({"v": 1, "type": "error", "ref": None,
                                      "code": "UNAUTHORIZED", "detail": "token inválido"}))
            await ws.close()
            return
        self.hello = primero
        self.conexion = ws
        self.n_hello += 1
        await ws.send(json.dumps({"v": 1, "type": "welcome",
                                  "server_time_ms": int(time.time() * 1000), "heartbeat_s": 30}))
        try:
            async for crudo in ws:
                if isinstance(crudo, bytes):
                    self.problemas += ["trama: " + p for p in validar_trama(crudo, "cuna")]
                    if len(crudo) >= 8 and crudo[1] == 1:
                        _v, _t, seq, ts = struct.unpack("!BBHI", crudo[:8])
                        self.voz_cuna.append((seq, ts, crudo[8:]))
                    continue
                msg = json.loads(crudo)
                self._revisar(msg)
                self.recibidos.append(msg)
                self._cola.put_nowait(msg)
        except ConnectionClosed:
            pass  # La cuna se fue sin cerrar bien. Es normal si se le va el Wi-Fi.
        finally:
            self.conexion = None

    def cortar(self):
        """Corta la conexión sin avisar, como si se cayera el Wi-Fi."""
        if self.conexion is not None:
            self.conexion.abortar()

    async def esperar_hello(self, n, timeout=5):
        """Espera hasta que la cuna se haya conectado n veces en total."""
        fin = time.monotonic() + timeout
        while self.n_hello < n:
            if time.monotonic() > fin:
                raise asyncio.TimeoutError("la cuna no llegó a la conexión %d" % n)
            await asyncio.sleep(0.01)

    def _revisar(self, msg):
        self.problemas += validar(msg, "cuna")

    async def esperar(self, tipo, timeout=3):
        """Espera el siguiente mensaje del tipo dado. Útil en pruebas."""
        fin = time.monotonic() + timeout
        while True:
            resto = fin - time.monotonic()
            if resto <= 0:
                raise asyncio.TimeoutError("no llegó " + tipo)
            msg = await asyncio.wait_for(self._cola.get(), resto)
            if msg.get("type") == tipo:
                return msg

    async def mandar(self, msg, validar_salida=True):
        """Manda un mensaje a la cuna. Revisa que el propio simulador cumpla el contrato."""
        if validar_salida:
            p = validar(msg, "servidor")
            if p:
                raise ValueError("el simulador iba a mandar un mensaje fuera del contrato: %s" % p)
        await self.conexion.send(json.dumps(msg))

    async def audio_play(self, song_id, source):
        self.seq += 1
        await self.mandar({"v": 1, "type": "audio.play", "id": "r-%d" % self.seq,
                           "seq": self.seq, "song_id": song_id, "source": source})

    async def audio_stop(self):
        self.seq += 1
        await self.mandar({"v": 1, "type": "audio.stop", "id": "r-%d" % self.seq, "seq": self.seq})

    async def audio_volume(self, volumen):
        self.seq += 1
        await self.mandar({"v": 1, "type": "audio.volume", "id": "r-%d" % self.seq,
                           "seq": self.seq, "volume": volumen})

    async def transmitir(self, pcm, ritmo=1.0, adelanto_ms=500, fin=True):
        """Manda audio de tipo 3 en tramas de 20 ms a ritmo real, como pide el contrato.
        Puede adelantar hasta 500 ms al empezar. ritmo mayor que 1 va más rápido, solo para pruebas."""
        tam = 640
        seq, t0, enviado_ms = 0, time.monotonic(), 0
        for i in range(0, len(pcm), tam):
            # Se manda cuando el reloj de la canción alcanza este instante menos el adelanto.
            espera = (enviado_ms - adelanto_ms) / 1000 / ritmo - (time.monotonic() - t0)
            if espera > 0:
                await asyncio.sleep(espera)
            cab = struct.pack("!BBHI", 1, 3, seq & 0xFFFF, enviado_ms)
            await self.conexion.send(cab + pcm[i:i + tam])
            seq += 1
            enviado_ms += 20
        if fin:
            await self.conexion.send(struct.pack("!BBHI", 1, 3, seq & 0xFFFF, enviado_ms))

    async def voice_start(self, session_id="s-1", turno="cradle"):
        self.session = session_id
        await self.mandar({"v": 1, "type": "voice.start", "id": "v-start", "session_id": session_id, "turn": turno})

    async def voice_turn(self, turno):
        await self.mandar({"v": 1, "type": "voice.turn", "id": "v-turn", "session_id": self.session, "turn": turno})

    async def voice_stop(self):
        await self.mandar({"v": 1, "type": "voice.stop", "id": "v-stop", "session_id": self.session})

    async def mandar_voz(self, pcm, ritmo=1.0):
        """Manda voz de la app, tipo 2, 16 kHz, tramas de 20 ms a ritmo real."""
        t0, seq = time.monotonic(), 0
        for i in range(0, len(pcm), 640):
            espera = seq * 0.02 / ritmo - (time.monotonic() - t0)
            if espera > 0:
                await asyncio.sleep(espera)
            await self.conexion.send(struct.pack("!BBHI", 1, 2, seq & 0xFFFF, seq * 20) + pcm[i:i + 640])
            seq += 1

    def guardar_wav(self, ruta):
        """Guarda lo que mandó el micrófono de la cuna, 8 kHz, para escucharlo en la PC."""
        with wave.open(ruta, "wb") as w:
            w.setnchannels(1)
            w.setsampwidth(2)
            w.setframerate(8000)
            w.writeframes(b"".join(t[2] for t in self.voz_cuna))
        return len(self.voz_cuna)

    async def light_set(self, encender, brillo=None, fade_ms=None, seq=None, validar_salida=True):
        self.seq = seq if seq is not None else self.seq + 1
        msg = {"v": 1, "type": "light.set", "id": "r-%d" % self.seq, "seq": self.seq, "on": encender}
        if brillo is not None:
            msg["brightness"] = brillo
        if fade_ms is not None:
            msg["fade_ms"] = fade_ms
        await self.mandar(msg, validar_salida)
        return msg


async def consola(srv):
    loop = asyncio.get_running_loop()
    while True:
        linea = (await loop.run_in_executor(None, input, "> ")).split()
        if not linea or srv.conexion is None:
            print("no hay cuna conectada" if srv.conexion is None else "")
            continue
        if linea[0] == "on":
            await srv.light_set(True, int(linea[1]) if len(linea) > 1 else None)
        elif linea[0] == "off":
            await srv.light_set(False)
        elif linea[0] == "get":
            await srv.mandar({"v": 1, "type": "light.get", "id": "g"})
        elif linea[0] == "play" and len(linea) > 2 and linea[1] == "local":
            await srv.audio_play(linea[2], "local")
        elif linea[0] == "play" and len(linea) > 2 and linea[1] == "server":
            # play server ruta/al/archivo.pcm   Archivo PCM de 16 bits, mono, 16 kHz.
            await srv.audio_play(linea[2].split("/")[-1], "server")
            asyncio.create_task(srv.transmitir(open(linea[2], "rb").read()))
        elif linea[0] == "stop":
            await srv.audio_stop()
        elif linea[0] == "voz" and len(linea) > 1:
            # voz start [cradle|app]   voz turno app|cradle   voz stop   voz decir archivo.pcm
            if linea[1] == "start":
                await srv.voice_start("s-1", linea[2] if len(linea) > 2 else "cradle")
            elif linea[1] == "turno" and len(linea) > 2:
                await srv.voice_turn(linea[2])
            elif linea[1] == "stop":
                await srv.voice_stop()
                print("tramas del micrófono:", srv.guardar_wav("voz_cuna.wav"), "guardadas en voz_cuna.wav")
            elif linea[1] == "decir" and len(linea) > 2:
                asyncio.create_task(srv.mandar_voz(open(linea[2], "rb").read()))
        elif linea[0] == "vol" and len(linea) > 1:
            await srv.audio_volume(int(linea[1]))


async def principal():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--puerto", type=int, default=8080)
    ap.add_argument("--token", default="TOKEN_DE_PRUEBA")
    ap.add_argument("--escenario", choices=["completo", "con-corte"],
                    help="corre las pruebas automáticas apenas la cuna se conecte, imprime PASS o FAIL y termina")
    a = ap.parse_args()
    srv = ServidorSim(a.token)

    if a.escenario:
        from simulador.escenarios import Corrida
        async with await servir(srv.manejador, a.host, a.puerto):
            print("Esperando a la cuna en %s:%d%s ..." % (a.host, a.puerto, RUTA))
            await srv.esperar_hello(1, timeout=600)
            await asyncio.sleep(1.0)
            c = Corrida(srv, con_corte=(a.escenario == "con-corte"))
            res = await c.correr()
            print(c.resumen())
            raise SystemExit(0 if all(b for _, b, _ in res) else 1)

    async def imprimir():
        while True:
            print("<-", await srv._cola.get())
    async with await servir(srv.manejador, a.host, a.puerto):
        print("Simulador escuchando en %s:%d%s" % (a.host, a.puerto, RUTA))
        await asyncio.gather(imprimir(), consola(srv))


if __name__ == "__main__":
    asyncio.run(principal())
