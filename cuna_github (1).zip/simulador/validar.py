# Validador de los mensajes del contrato, versión 1. Ver CONTRATO.md.
# Sirve para el simulador y para Jan Carlo. Con él se puede revisar que el servidor real
# mande mensajes correctos a la cuna, y que la cuna mande lo que el contrato dice.
# Solo usa la biblioteca estándar. No habla con la cuna ni con el servidor, solo revisa.

ERRORES = ("BAD_JSON", "BAD_VERSION", "UNAUTHORIZED", "INVALID_RANGE", "UNKNOWN_SONG", "BUSY",
           "UNSUPPORTED", "AUDIO_UNDERRUN", "MIC_UNAVAILABLE", "NO_SESSION", "INTERNAL")


def _entero(x):
    return isinstance(x, int) and not isinstance(x, bool)


def _rango(minimo, maximo):
    return lambda x: _entero(x) and minimo <= x <= maximo


def _texto(maximo=None):
    return lambda x: isinstance(x, str) and (maximo is None or len(x) <= maximo)


def _uno_de(*valores):
    return lambda x: x in valores


def _o_nulo(f):
    return lambda x: x is None or f(x)


BOOL = lambda x: isinstance(x, bool)
DICT = lambda x: isinstance(x, dict)
ENTERO = _entero
TEXTO = _texto()
ID = _o_nulo(_texto())
SEQ = lambda x: _entero(x) and x >= 0
PORCENTAJE = _rango(0, 100)

# nombre: (obligatorios, opcionales)
DE_CUNA = {
    "hello": ({"device_id": TEXTO, "token": TEXTO, "fw": TEXTO, "caps": DICT, "uptime_ms": ENTERO}, {}),
    "ack": ({"ref": ID, "ok": BOOL}, {"ignored": TEXTO}),
    "error": ({"ref": ID, "code": _uno_de(*ERRORES), "detail": TEXTO}, {}),
    "light.state": ({"seq": SEQ, "on": BOOL, "brightness": PORCENTAJE,
                     "cause": _uno_de("command", "boot", "local"), "ts": ENTERO}, {}),
    "audio.state": ({"mode": _uno_de("idle", "song", "voice"), "song_id": _o_nulo(TEXTO),
                     "source": _o_nulo(_uno_de("server", "local", "voice")), "volume": PORCENTAJE,
                     "seq": SEQ, "ts": ENTERO}, {"underruns": SEQ, "dropped_frames": SEQ}),
    "audio.ended": ({"song_id": TEXTO, "ts": ENTERO}, {}),
    "voice.state": ({"session_id": _o_nulo(TEXTO), "active": BOOL, "turn": _o_nulo(_uno_de("cradle", "app")),
                     "mic_active": BOOL, "mic_hz_real": SEQ, "dropped_frames": SEQ, "ts": ENTERO}, {}),
    "status": ({"uptime_s": SEQ, "rssi": _o_nulo(ENTERO), "free_ram": SEQ, "fw": TEXTO, "synced": BOOL}, {}),
    "event": ({"event_id": _texto(64), "event_type": _texto(50), "severity": _uno_de("info"),
               "detail": TEXTO, "ts": SEQ, "uptime_ms": SEQ, "synced": BOOL, "dropped_before": SEQ}, {}),
}

DEL_SERVIDOR = {
    "welcome": ({"server_time_ms": SEQ, "heartbeat_s": _rango(1, 3600)}, {}),
    "error": ({"ref": ID, "code": _uno_de(*ERRORES), "detail": TEXTO}, {}),
    "light.set": ({"id": TEXTO, "seq": SEQ, "on": BOOL},
                  {"brightness": PORCENTAJE, "fade_ms": _rango(0, 10000)}),
    "light.get": ({"id": TEXTO}, {}),
    "audio.play": ({"id": TEXTO, "seq": SEQ, "song_id": _texto(64), "source": _uno_de("server", "local")}, {}),
    "audio.stop": ({"id": TEXTO, "seq": SEQ}, {}),
    "audio.volume": ({"id": TEXTO, "seq": SEQ, "volume": PORCENTAJE}, {}),
    "audio.get": ({"id": TEXTO}, {}),
    "voice.start": ({"id": TEXTO, "session_id": _texto(64)}, {"turn": _uno_de("cradle", "app")}),
    "voice.turn": ({"id": TEXTO, "session_id": _texto(64), "turn": _uno_de("cradle", "app")}, {}),
    "voice.stop": ({"id": TEXTO, "session_id": _texto(64)}, {}),
}


def validar(msg, origen):
    """Revisa un mensaje JSON ya leído. origen es cuna o servidor.
    Devuelve una lista de problemas. Vacía quiere decir que cumple el contrato."""
    tabla = DE_CUNA if origen == "cuna" else DEL_SERVIDOR
    if not isinstance(msg, dict):
        return ["el mensaje no es un objeto JSON"]
    problemas = []
    if msg.get("v") != 1:
        problemas.append("v debe ser 1")
    tipo = msg.get("type")
    if tipo not in tabla:
        return problemas + ["type desconocido para %s: %r" % (origen, tipo)]
    obligatorios, opcionales = tabla[tipo]
    for campo, ok in obligatorios.items():
        if campo not in msg:
            problemas.append("%s: falta %s" % (tipo, campo))
        elif not ok(msg[campo]):
            problemas.append("%s: valor inválido en %s: %r" % (tipo, campo, msg[campo]))
    for campo, ok in opcionales.items():
        if campo in msg and not ok(msg[campo]):
            problemas.append("%s: valor inválido en %s: %r" % (tipo, campo, msg[campo]))
    conocidos = set(obligatorios) | set(opcionales) | {"v", "type"}
    extra = sorted(set(msg) - conocidos)
    if extra:
        problemas.append("%s: campos que el contrato no define: %s" % (tipo, ", ".join(extra)))
    return problemas


def validar_trama(datos, origen):
    """Revisa un mensaje binario de audio. La cuna manda tipo 1. El servidor manda 2 y 3."""
    if len(datos) < 8:
        return ["trama de menos de 8 bytes"]
    version, tipo, _seq, _ts = datos[0], datos[1], datos[2:4], datos[4:8]
    problemas = []
    if version != 1:
        problemas.append("versión de trama %d, se esperaba 1" % version)
    permitidos = (1,) if origen == "cuna" else (2, 3)
    if tipo not in permitidos:
        problemas.append("tipo de trama %d no permitido desde %s" % (tipo, origen))
    audio = len(datos) - 8
    if audio % 2:
        problemas.append("el audio tiene un número impar de bytes")
    if audio > 1280:
        problemas.append("el audio supera 1280 bytes")
    if tipo in (1, 2) and audio == 0:
        problemas.append("una trama de voz no puede venir vacía")
    return problemas
