# Una cuna hecha solo de software, con hardware falso. Sirve para probar el simulador
# sin la Pico. NO es la cuna real: no suena, no enciende luz, el micrófono es un tono.
#   python3 -m simulador.cuna_software --puerto 8080 --token TOKEN_DE_PRUEBA
import argparse
import asyncio

from tests.banco import Banco


async def principal():
    ap = argparse.ArgumentParser()
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--puerto", type=int, default=8080)
    ap.add_argument("--token", default="TOKEN_DE_PRUEBA")
    a = ap.parse_args()
    b = await Banco().abrir(puerto=0)
    b.servidor.close()                      # Esta cuna no necesita su propio servidor.
    b.cuna._host, b.cuna._puerto, b.cuna._token = a.host, a.puerto, a.token
    b.archivos.canciones["nana-1"] = bytes(640 * 200)

    async def mic():
        while True:
            b.mic.poner(b"\x10\x00" * 160)
            await asyncio.sleep(0.02)
    asyncio.create_task(mic())

    async def dormir(s):
        print("cuna de software: reconectando en %s s" % s)
        await asyncio.sleep(min(s, 2))
    from servicios.supervisor import supervisar
    await supervisar(b.cuna.una_sesion, b.cuna.estado, dormir=dormir, avisar=lambda e: print("cuna de software:", e))


if __name__ == "__main__":
    asyncio.run(principal())
